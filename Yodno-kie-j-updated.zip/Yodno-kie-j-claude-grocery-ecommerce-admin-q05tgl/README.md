# CK & J Grocery — Online Ordering + Admin

Online store and back office for **CK & J Wet and Dry Goods Trading Corporation**.
One small Node.js app: storefront, admin panel and database (SQLite) together. No build step.

## Run it

```bash
npm install
npm start          # http://localhost:3000   (admin: http://localhost:3000/admin)
```

Needs **Node.js 22.13 or newer**.

Sign in at `/admin` — or tap **Admin** in the store footer or on the welcome screen — with username
**Admin** and the default password **Admin123**. Change the password in
Admin → Security before the store goes live (the dashboard reminds you until you do).

Forgot the password? Run `npm run reset-admin` on the server to get a new temporary one.

## What customers can do

- Browse products by category, search, add to cart
- Check out for **delivery or pickup**
- Pay by **cash**, or by **QR code / account number** (GCash, bank…) and send the reference number + receipt screenshot
- **Track an order** with the tracking code (e.g. `CKJ-AB12CD`)
- Earn and spend **loyalty points** with an automatic loyalty card
- Send a **support message** and read the store's reply with a message code

## What the admin can do

| Page | What it is for |
|---|---|
| Dashboard | Today's sales, new orders, payments to verify, low stock |
| Orders | Confirm → prepare → deliver → complete, verify payments, print receipts |
| Products | Products, categories, prices, stock, photos |
| Customers | Customer details, order history, what they mostly order, notes, CSV export |
| Loyalty cards | Earning rules, card design, points, printable cards with QR |
| Sales reports | Any date range: by day, product, category, payment method, QR source; CSV export |
| Messages | Customer support inbox with replies |
| Design & branding | Theme, colours, fonts, logo, hero, sections, all text — with live preview |
| Payment methods | Account numbers and payment QR images |
| QR codes | Store QR + tracked QR codes for flyers/posters (scans, orders, sales) |
| Store settings | Open/closed, delivery fee, minimum order, contact details |
| Security | Password, two-step sign-in, signed-in devices, sign-in log |

## Admin security

- Username + password sign-in; password hashed with scrypt; strength rules on change
- Optional two-step sign-in (authenticator app, TOTP)
- 5 wrong passwords locks that device out (15 min, doubling each time)
- HttpOnly + SameSite=Strict session cookie, 2-hour idle timeout, CSRF token on every change
- Strict Content-Security-Policy, upload type checks, rate limits on public forms

## Putting it online

Everything the store saves lives in the `data/` folder (database, uploaded images).
**Host it somewhere with a persistent disk** and back that folder up.

- **Docker / VPS:** `docker build -t ckj . && docker run -d -p 3000:3000 -v ckj-data:/app/data -e TRUST_PROXY=1 ckj`
- **Render:** `render.yaml` is included (web service + 1 GB disk).
- **Railway:** New Project → Deploy from GitHub repo → pick this repository and branch. Then add a **Volume** to the service (mount path `/data`); the app finds it automatically. Generate a domain under Settings → Networking.

Environment variables (all optional):

| Variable | Meaning |
|---|---|
| `PORT` | Port to listen on (default 3000) |
| `DATA_DIR` | Where to keep the database and uploads (default `./data`) |
| `ADMIN_USERNAME` | First-time admin username (default `Admin`) |
| `ADMIN_PASSWORD` | First-time admin password instead of the default |
| `TRUST_PROXY` | Set to `1` when running behind a reverse proxy / HTTPS load balancer |

Always serve it over **HTTPS** in production.

## Project layout

```
server.js            routes: store API, admin API, pages
server/db.js         database schema, default settings, sample products
server/security.js   passwords, sessions, 2FA, rate limits, security headers
public/              storefront (index.html, store.css, store.js)
public/admin/        admin panel
public/shared/       theme engine shared by server and browser
```
