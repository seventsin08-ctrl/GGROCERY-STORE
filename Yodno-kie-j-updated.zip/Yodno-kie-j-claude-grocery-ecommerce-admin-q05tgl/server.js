'use strict';
const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const QRCode = require('qrcode');
const Theme = require('./public/shared/theme.js');
const { db, tx, getSetting, setSetting, DEFAULTS, UPLOAD_DIR, PROOF_DIR } = require('./server/db');
const sec = require('./server/security');

const PORT = Number(process.env.PORT) || 3000;
const PUBLIC = path.join(__dirname, 'public');
const app = express();
app.disable('x-powered-by');
const behindProxy = process.env.TRUST_PROXY || (process.env.RENDER || process.env.RAILWAY_ENVIRONMENT || process.env.FLY_APP_NAME || process.env.DYNO ? '1' : '');
if (behindProxy) app.set('trust proxy', /^\d+$/.test(behindProxy) ? Number(behindProxy) : behindProxy);

/* ---------------- helpers ---------------- */
class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = (msg, status = 400) => new HttpError(status, msg);
const nowIso = () => new Date().toISOString();
const round2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const S = (v, max = 200) => (v == null ? '' : String(v)).replace(/\u0000/g, '').trim().slice(0, max);
const N = (v, d = 0) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
const I = (v, d = 0) => Math.trunc(N(v, d));
const B = (v) => (v === true || v === 1 || v === '1' || v === 'true' ? 1 : 0);
const wrap = (fn) => (req, res, next) => { try { const r = fn(req, res, next); if (r && r.catch) r.catch(next); } catch (e) { next(e); } };
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const IMG_RE = /^\/(uploads|assets)\/[\w.\-]+$/;
const img = (v) => (typeof v === 'string' && IMG_RE.test(v) ? v : '');
const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const randCode = (n) => Array.from(crypto.randomBytes(n), (b) => ALPHA[b % 32]).join('');
const randDigits = (n) => Array.from(crypto.randomBytes(n), (b) => String(b % 10)).join('');

function normPhone(v) {
  let d = S(v, 30).replace(/\D/g, '');
  if (d.length === 12 && d.startsWith('63')) d = '0' + d.slice(2);
  if (d.length === 10 && d.startsWith('9')) d = '0' + d;
  return d.length >= 7 && d.length <= 15 ? d : '';
}
function newCardNo() {
  for (;;) { const c = '8' + randDigits(11); if (!db.prepare('SELECT 1 FROM customers WHERE card_no = ?').get(c)) return c; }
}
function tzMod() { return `${Math.round(N(getSetting('site').brand.utcOffset, 8) * 60)} minutes`; }
function localToday(offsetDays = 0) {
  const off = N(getSetting('site').brand.utcOffset, 8);
  return new Date(Date.now() + off * 3600e3 + offsetDays * 86400e3).toISOString().slice(0, 10);
}
function saveDataUrl(dataUrl, dir, maxBytes = 5 * 1024 * 1024) {
  const m = /^data:image\/(png|jpeg|webp|gif);base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''));
  if (!m) throw bad('Please upload a PNG, JPG, WEBP or GIF image.');
  const buf = Buffer.from(m[2], 'base64');
  if (!buf.length || buf.length > maxBytes) throw bad('Image is too large (max 5 MB).');
  const hex = buf.subarray(0, 12).toString('hex');
  const ok = { png: hex.startsWith('89504e47'), jpeg: hex.startsWith('ffd8ff'), gif: hex.startsWith('474946'), webp: hex.startsWith('52494646') && hex.slice(16, 24) === '57454250' }[m[1]];
  if (!ok) throw bad('That file is not a valid image.');
  const name = crypto.randomBytes(12).toString('hex') + '.' + (m[1] === 'jpeg' ? 'jpg' : m[1]);
  fs.writeFileSync(path.join(dir, name), buf);
  return name;
}
const csvCell = (v) => { let s = v == null ? '' : String(v); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
function sendCsv(res, name, header, rows) {
  res.set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="${name}"` });
  res.send('﻿' + [header, ...rows].map((r) => r.map(csvCell).join(',')).join('\r\n'));
}

/* ---------------- middleware ---------------- */
app.use(sec.securityHeaders);
app.use(express.json({ limit: '8mb' }));

/* ---------------- pages & static ---------------- */
const tpl = (file) => fs.readFileSync(path.join(PUBLIC, file), 'utf8');
function storePage(req, res) {
  const site = getSetting('site');
  const html = tpl('index.html')
    .replace(/{{TITLE}}/g, esc(site.brand.short || site.brand.name))
    .replace(/{{DESC}}/g, esc(site.brand.tagline))
    .replace(/{{ICON}}/g, esc(img(site.brand.logo) || '/assets/logo.jpg'));
  res.set('Cache-Control', 'no-cache').type('html').send(html);
}
app.get('/', storePage);
app.get('/theme.css', (req, res) => res.set('Cache-Control', 'no-cache').type('css').send(Theme.css(getSetting('site').theme)));
app.get(['/admin', '/admin/'], (req, res) => res.set({ 'Cache-Control': 'no-store', 'X-Robots-Tag': 'noindex, nofollow' }).type('html').send(tpl('admin/index.html')));
app.get('/q/:slug', (req, res) => {
  const slug = S(req.params.slug, 60);
  const r = db.prepare('UPDATE qr_campaigns SET scans = scans + 1 WHERE slug = ?').run(slug);
  res.redirect(302, r.changes ? '/?src=' + encodeURIComponent(slug) : '/');
});
app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '30d', index: false, dotfiles: 'deny' }));
app.use(express.static(PUBLIC, { index: false, dotfiles: 'deny', maxAge: 0 }));

/* ================= PUBLIC API ================= */
const pub = express.Router();
const limitRead = sec.rateLimit(120, 60e3);
const limitTrack = sec.rateLimit(30, 60e3, 'Too many lookups. Please wait a minute.');
const limitOrder = sec.rateLimit(12, 10 * 60e3, 'Too many orders from this device. Please wait a few minutes.');
const limitMsg = sec.rateLimit(6, 10 * 60e3, 'Too many messages. Please wait a few minutes.');

function publicPayments() {
  return db.prepare('SELECT id, name, type, account_name, account_number, qr_image, instructions FROM payment_methods WHERE enabled = 1 ORDER BY sort, id').all();
}
pub.get('/store', limitRead, (req, res) => {
  const loy = getSetting('loyalty');
  res.set('Cache-Control', 'no-store').json({
    site: getSetting('site'),
    loyalty: { enabled: !!loy.enabled, name: loy.name, pesoPerPoint: loy.pesoPerPoint, pointValue: loy.pointValue, minRedeem: loy.minRedeem, cardBg: loy.cardBg, cardBg2: loy.cardBg2, cardFg: loy.cardFg },
    categories: db.prepare('SELECT id, name, emoji FROM categories WHERE id IN (SELECT category_id FROM products WHERE active = 1) ORDER BY sort, id').all(),
    products: db.prepare('SELECT id, name, description, category_id, price, compare_price, unit, stock, image, emoji, featured FROM products WHERE active = 1 ORDER BY sort, id').all(),
    payments: publicPayments()
  });
});

function trackView(o) {
  const pm = o.payment_method_id ? db.prepare('SELECT id, name, type, account_name, account_number, qr_image, instructions FROM payment_methods WHERE id = ?').get(o.payment_method_id) : null;
  return {
    code: o.code, status: o.status, fulfillment: o.fulfillment, firstName: o.name.split(/\s+/)[0], created: o.created, updated: o.updated,
    history: JSON.parse(o.history || '[]').map((h) => ({ status: h.status, ts: h.ts, note: h.public ? h.note : '' })),
    items: db.prepare('SELECT name, unit, price, qty FROM order_items WHERE order_id = ?').all(o.id),
    subtotal: o.subtotal, deliveryFee: o.delivery_fee, discount: o.discount, total: o.total,
    paymentName: o.payment_name, paymentType: o.payment_type, paymentStatus: o.payment_status, paymentRef: o.payment_ref ? '••' + o.payment_ref.slice(-4) : '',
    payment: o.payment_type !== 'cod' ? pm : null, pointsEarned: o.points_earned, pointsRedeemed: o.points_redeemed
  };
}
const findOrder = (code) => db.prepare('SELECT * FROM orders WHERE code = ?').get(S(code, 30).toUpperCase().replace(/\s+/g, ''));

const Delivery = require('./public/shared/delivery');
pub.post('/orders', limitOrder, wrap((req, res) => {
  const site = getSetting('site'), loy = getSetting('loyalty'), b = req.body || {};
  if (!site.order.accepting) throw bad(site.order.closedMessage || 'Ordering is currently closed.');
  const name = S(b.name, 80), phone = normPhone(b.phone), notes = S(b.notes, 500), address = S(b.address, 300);
  const fulfillment = b.fulfillment === 'pickup' ? 'pickup' : 'delivery';
  if (name.length < 2) throw bad('Please enter your name.');
  if (!phone) throw bad('Please enter a valid mobile number.');
  if (fulfillment === 'delivery' && !site.order.delivery) throw bad('Delivery is not available right now.');
  if (fulfillment === 'pickup' && !site.order.pickup) throw bad('Pickup is not available right now.');
  if (fulfillment === 'delivery' && address.length < 5) throw bad('Please enter your delivery address.');
  const dist = fulfillment === 'delivery' ? Delivery.distance(site.order, b.lat, b.lng) : null;
  if (fulfillment === 'delivery' && Delivery.active(site.order) && dist == null) throw bad('Please tap “Use my location” so we can work out your delivery fee, or choose store pickup.');
  if (Delivery.tooFar(site.order, dist)) throw bad(`Sorry, we only deliver within ${site.order.maxKm} km of the store. Please choose store pickup.`);
  if (!Array.isArray(b.items) || !b.items.length || b.items.length > 100) throw bad('Your cart is empty.');
  const pm = db.prepare('SELECT * FROM payment_methods WHERE id = ? AND enabled = 1').get(I(b.paymentMethodId));
  if (!pm) throw bad('Please choose a payment method.');

  const result = tx(() => {
    const merged = new Map();
    for (const it of b.items) { const id = I(it && it.id), q = I(it && it.qty); if (id > 0 && q > 0) merged.set(id, (merged.get(id) || 0) + q); }
    if (!merged.size) throw bad('Your cart is empty.');
    const lines = []; let subtotal = 0;
    for (const [id, qty] of merged) {
      const p = db.prepare('SELECT p.*, c.name AS category FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE p.id = ? AND p.active = 1').get(id);
      if (!p) throw bad('An item in your cart is no longer available. Please review your cart.', 409);
      if (qty > 999) throw bad(`Quantity for ${p.name} is too large.`);
      if (p.stock != null && p.stock < qty) throw bad(p.stock > 0 ? `Only ${p.stock} left of ${p.name}.` : `${p.name} is out of stock.`, 409);
      lines.push({ p, qty }); subtotal += p.price * qty;
    }
    subtotal = round2(subtotal);
    if (site.order.minOrder > 0 && subtotal < site.order.minOrder) throw bad(`Minimum order is ${site.brand.currency}${site.order.minOrder}.`);
    const fee = fulfillment === 'delivery' ? Delivery.fee(site.order, subtotal, dist) : 0;

    // customer + loyalty
    let cust = db.prepare('SELECT * FROM customers WHERE phone = ?').get(phone);
    const now = nowIso();
    let isNew = false;
    if (!cust) {
      const bonus = loy.enabled ? Math.max(0, I(loy.signupBonus)) : 0;
      const id = db.prepare('INSERT INTO customers (name, phone, address, card_no, points, created) VALUES (?,?,?,?,?,?)').run(name, phone, address, newCardNo(), bonus, now).lastInsertRowid;
      if (bonus) db.prepare('INSERT INTO loyalty_tx (customer_id, delta, reason, ts) VALUES (?,?,?,?)').run(id, bonus, 'Welcome bonus', now);
      cust = db.prepare('SELECT * FROM customers WHERE id = ?').get(id); isNew = true;
    } else {
      db.prepare('UPDATE customers SET name = ?, address = CASE WHEN ? <> \'\' THEN ? ELSE address END WHERE id = ?').run(name, address, address, cust.id);
    }
    let redeem = 0, discount = 0;
    const want = I(b.redeemPoints);
    if (loy.enabled && want > 0 && !isNew) {
      if (S(b.cardNo, 30).replace(/\D/g, '') !== cust.card_no) throw bad('Loyalty card number does not match this mobile number.');
      const value = Math.max(0.01, N(loy.pointValue, 1));
      redeem = Math.min(want, cust.points, Math.floor(subtotal / value));
      if (redeem < Math.max(1, I(loy.minRedeem))) throw bad(`You need at least ${loy.minRedeem} points to redeem.`);
      discount = round2(redeem * value);
    }
    const total = round2(subtotal + fee - discount);
    const earn = loy.enabled && N(loy.pesoPerPoint) > 0 ? Math.floor((subtotal - discount) / N(loy.pesoPerPoint)) : 0;
    let code; const prefix = (S(site.order.prefix, 6).toUpperCase().replace(/[^A-Z0-9]/g, '') || 'CKJ');
    do { code = `${prefix}-${randCode(6)}`; } while (db.prepare('SELECT 1 FROM orders WHERE code = ?').get(code));
    const history = JSON.stringify([{ status: 'pending', ts: now, note: '' }]);
    const src = S(b.src, 60).replace(/[^\w\-]/g, '');
    const oid = db.prepare(`INSERT INTO orders (code, customer_id, name, phone, address, fulfillment, notes, subtotal, delivery_fee, discount, total, points_redeemed, points_earned,
      payment_method_id, payment_name, payment_type, history, source, created, updated, lat, lng, distance_km) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(code, cust.id, name, phone, fulfillment === 'delivery' ? address : '', fulfillment, notes, subtotal, fee, discount, total, redeem, earn, pm.id, pm.name, pm.type, history, src, now, now, dist == null ? null : b.lat, dist == null ? null : b.lng, dist).lastInsertRowid;
    const insItem = db.prepare('INSERT INTO order_items (order_id, product_id, name, category, unit, price, qty) VALUES (?,?,?,?,?,?,?)');
    for (const { p, qty } of lines) {
      insItem.run(oid, p.id, p.name, p.category || 'Uncategorized', p.unit || '', p.price, qty);
      if (p.stock != null) db.prepare('UPDATE products SET stock = stock - ? WHERE id = ?').run(qty, p.id);
    }
    if (redeem) {
      db.prepare('UPDATE customers SET points = points - ? WHERE id = ?').run(redeem, cust.id);
      db.prepare('INSERT INTO loyalty_tx (customer_id, delta, reason, order_id, ts) VALUES (?,?,?,?,?)').run(cust.id, -redeem, `Redeemed on ${code}`, oid, now);
    }
    return { oid, cardNo: cust.card_no, isNew };
  });
  const o = db.prepare('SELECT * FROM orders WHERE id = ?').get(result.oid);
  res.status(201).json({ order: trackView(o), loyaltyCard: getSetting('loyalty').enabled ? result.cardNo : null, newCustomer: result.isNew });
}));

pub.get('/orders/:code', limitTrack, wrap((req, res) => {
  const o = findOrder(req.params.code);
  if (!o) throw bad('We couldn’t find an order with that code. Please check and try again.', 404);
  res.set('Cache-Control', 'no-store').json({ order: trackView(o) });
}));

pub.post('/orders/:code/payment', limitOrder, wrap((req, res) => {
  const o = findOrder(req.params.code);
  if (!o) throw bad('Order not found.', 404);
  if (o.payment_type === 'cod') throw bad('This order is cash on delivery.');
  if (o.status === 'cancelled') throw bad('This order was cancelled.');
  if (o.payment_status === 'paid') throw bad('This order is already marked as paid.');
  const ref = S(req.body && req.body.reference, 60);
  if (ref.length < 4) throw bad('Please enter the payment reference number.');
  let proof = o.payment_proof;
  if (req.body.proof) {
    const name = saveDataUrl(req.body.proof, PROOF_DIR);
    if (proof) fs.rm(path.join(PROOF_DIR, path.basename(proof)), () => {});
    proof = name;
  }
  db.prepare("UPDATE orders SET payment_ref = ?, payment_proof = ?, payment_status = 'submitted', updated = ? WHERE id = ?").run(ref, proof, nowIso(), o.id);
  res.json({ order: trackView(db.prepare('SELECT * FROM orders WHERE id = ?').get(o.id)) });
}));

pub.post('/loyalty/check', limitTrack, wrap((req, res) => {
  const loy = getSetting('loyalty');
  if (!loy.enabled) throw bad('Loyalty program is not active.');
  const card = S(req.body && req.body.cardNo, 30).replace(/\D/g, '');
  const c = card.length >= 8 ? db.prepare('SELECT name, card_no, points FROM customers WHERE card_no = ?').get(card) : null;
  if (!c) throw bad('Card not found. Please check the number.', 404);
  res.json({ name: c.name.split(/\s+/)[0], cardNo: c.card_no, points: c.points, value: round2(c.points * N(loy.pointValue, 1)) });
}));

pub.post('/messages', limitMsg, wrap((req, res) => {
  const b = req.body || {};
  const name = S(b.name, 80), contact = S(b.contact, 120), body = S(b.message, 2000), orderCode = S(b.orderCode, 30).toUpperCase();
  if (name.length < 2) throw bad('Please enter your name.');
  if (contact.length < 5) throw bad('Please enter a mobile number or email so we can reply.');
  if (body.length < 5) throw bad('Please write your message.');
  let ticket; do { ticket = 'MSG-' + randCode(6); } while (db.prepare('SELECT 1 FROM messages WHERE ticket = ?').get(ticket));
  db.prepare('INSERT INTO messages (ticket, name, contact, order_code, body, created) VALUES (?,?,?,?,?,?)').run(ticket, name, contact, orderCode, body, nowIso());
  res.status(201).json({ ticket });
}));
pub.get('/messages/:ticket', limitTrack, wrap((req, res) => {
  const m = db.prepare('SELECT ticket, body, status, reply, created, replied_at FROM messages WHERE ticket = ?').get(S(req.params.ticket, 20).toUpperCase());
  if (!m) throw bad('We couldn’t find that message code.', 404);
  res.set('Cache-Control', 'no-store').json({ message: m });
}));
app.use('/api', (req, res, next) => (req.path.startsWith('/admin') ? next() : pub(req, res, next)));

/* ================= ADMIN API ================= */
const adm = express.Router();
adm.use((req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });

adm.post('/login', sec.rateLimit(30, 10 * 60e3), wrap(async (req, res) => {
  const ip = req.ip || 'x';
  const wait = sec.loginLock(ip);
  if (wait) throw bad(`Too many failed attempts. Try again in ${Math.ceil(wait / 60)} minute(s).`, 429);
  const admin = db.prepare('SELECT * FROM admin WHERE id = 1').get();
  const userOk = S(req.body && req.body.username, 60).toLowerCase() === String(admin.username || 'Admin').toLowerCase();
  const ok = (await sec.verifyPassword(S(req.body && req.body.password, 300), admin.pass_hash)) && userOk;
  await new Promise((r) => setTimeout(r, 250 + crypto.randomInt(200)));
  if (!ok) {
    const f = sec.loginFailed(ip); sec.logLogin(ip, false, 'Wrong username or password');
    throw bad(f.count >= 5 ? 'Too many failed attempts. This device is temporarily locked.' : `Incorrect username or password. ${5 - f.count} attempt(s) left.`, 401);
  }
  if (admin.totp_enabled) {
    const code = S(req.body.code, 10);
    if (!code) return res.status(401).json({ need2fa: true, error: 'Enter the 6-digit code from your authenticator app.' });
    const ctr = sec.verifyTotp(admin.totp_secret, code, admin.totp_last);
    if (!ctr) { sec.loginFailed(ip); sec.logLogin(ip, false, 'Wrong 2FA code'); return res.status(401).json({ need2fa: true, error: 'That code is not valid. Try again.' }); }
    db.prepare('UPDATE admin SET totp_last = ? WHERE id = 1').run(ctr);
  }
  sec.loginSucceeded(ip); sec.logLogin(ip, true, 'Signed in');
  sec.destroySession(req, res);
  const csrf = sec.createSession(req, res);
  res.json({ ok: true, csrf, mustChange: !!admin.must_change });
}));
adm.use(sec.requireAdmin);

adm.get('/me', (req, res) => {
  const a = db.prepare('SELECT must_change, totp_enabled FROM admin WHERE id = 1').get();
  res.json({ ok: true, csrf: req.session.csrf, mustChange: !!a.must_change, twoFactor: !!a.totp_enabled });
});
adm.post('/logout', (req, res) => { sec.destroySession(req, res); res.json({ ok: true }); });
adm.post('/password', wrap(async (req, res) => {
  const admin = db.prepare('SELECT * FROM admin WHERE id = 1').get();
  const { current, next } = req.body || {};
  if (!(await sec.verifyPassword(S(current, 300), admin.pass_hash))) throw bad('Current password is incorrect.', 403);
  const problem = sec.passwordProblem(next);
  if (problem) throw bad(problem);
  if (await sec.verifyPassword(next, admin.pass_hash)) throw bad('New password must be different from the current one.');
  db.prepare('UPDATE admin SET pass_hash = ?, must_change = 0, is_default = 0, updated = ? WHERE id = 1').run(await sec.hashPassword(next), nowIso());
  db.prepare('DELETE FROM sessions WHERE id <> ?').run(req.session.id); // sign out every other device
  sec.clearInitialPasswordFile(); sec.logLogin(req.ip, true, 'Password changed');
  res.json({ ok: true });
}));

/* --- security: 2FA, sessions, log --- */
let pendingTotp = null;
adm.post('/2fa/setup', wrap(async (req, res) => {
  pendingTotp = sec.newTotpSecret();
  const label = encodeURIComponent('CKJ Admin');
  const uri = `otpauth://totp/${label}?secret=${pendingTotp}&issuer=${label}&digits=6&period=30`;
  res.json({ secret: pendingTotp, qr: await QRCode.toString(uri, { type: 'svg', margin: 1, width: 200 }) });
}));
adm.post('/2fa/enable', wrap((req, res) => {
  const ctr = pendingTotp && sec.verifyTotp(pendingTotp, S(req.body.code, 10));
  if (!ctr) throw bad('That code is not valid. Make sure your phone’s time is correct and try again.');
  db.prepare('UPDATE admin SET totp_secret = ?, totp_enabled = 1, totp_last = ? WHERE id = 1').run(pendingTotp, ctr);
  pendingTotp = null; sec.logLogin(req.ip, true, '2FA enabled');
  res.json({ ok: true });
}));
adm.post('/2fa/disable', wrap(async (req, res) => {
  const admin = db.prepare('SELECT * FROM admin WHERE id = 1').get();
  if (!(await sec.verifyPassword(S(req.body.password, 300), admin.pass_hash))) throw bad('Password is incorrect.', 403);
  db.prepare('UPDATE admin SET totp_secret = NULL, totp_enabled = 0, totp_last = 0 WHERE id = 1').run();
  sec.logLogin(req.ip, true, '2FA disabled');
  res.json({ ok: true });
}));
adm.get('/security', (req, res) => {
  res.json({
    twoFactor: !!db.prepare('SELECT totp_enabled FROM admin WHERE id = 1').get().totp_enabled,
    sessions: db.prepare('SELECT id, created, last_seen, ip, ua FROM sessions ORDER BY last_seen DESC').all().map((s) => ({ key: s.id.slice(0, 16), current: s.id === req.session.id, created: s.created, lastSeen: s.last_seen, ip: s.ip, ua: s.ua })),
    log: db.prepare('SELECT ts, ip, ok, note FROM login_log ORDER BY id DESC LIMIT 40').all()
  });
});
adm.post('/sessions/revoke', (req, res) => {
  const key = S(req.body.key, 16);
  if (key === 'others') db.prepare('DELETE FROM sessions WHERE id <> ?').run(req.session.id);
  else if (key.length === 16) db.prepare("DELETE FROM sessions WHERE id LIKE ? || '%' AND id <> ?").run(key.replace(/[^a-f0-9]/g, ''), req.session.id);
  res.json({ ok: true });
});

/* --- uploads --- */
adm.post('/upload', wrap((req, res) => res.json({ url: '/uploads/' + saveDataUrl(req.body.dataUrl, UPLOAD_DIR) })));
adm.get('/proof/:file', (req, res) => {
  const f = path.join(PROOF_DIR, path.basename(req.params.file));
  if (!fs.existsSync(f)) return res.status(404).end();
  res.sendFile(f);
});

/* --- dashboard --- */
adm.get('/dashboard', (req, res) => {
  const tz = tzMod(), site = getSetting('site');
  const sum = (from) => db.prepare("SELECT COUNT(*) AS orders, COALESCE(SUM(total),0) AS revenue FROM orders WHERE status <> 'cancelled' AND date(created, ?) >= ?").get(tz, from);
  const days = [];
  const rows = db.prepare("SELECT date(created, ?) AS day, COUNT(*) AS orders, SUM(total) AS revenue FROM orders WHERE status <> 'cancelled' AND date(created, ?) >= ? GROUP BY day").all(tz, tz, localToday(-13));
  for (let i = 13; i >= 0; i--) { const d = localToday(-i); const r = rows.find((x) => x.day === d); days.push({ day: d, orders: r ? r.orders : 0, revenue: r ? round2(r.revenue) : 0 }); }
  const pm = db.prepare("SELECT COUNT(*) AS n FROM payment_methods WHERE enabled = 1 AND type <> 'cod'").get().n;
  res.json({
    today: sum(localToday()), week: sum(localToday(-6)), month: sum(localToday(-29)),
    pending: db.prepare("SELECT COUNT(*) AS n FROM orders WHERE status = 'pending'").get().n,
    active: db.prepare("SELECT COUNT(*) AS n FROM orders WHERE status IN ('confirmed','preparing','out_for_delivery')").get().n,
    toVerify: db.prepare("SELECT COUNT(*) AS n FROM orders WHERE payment_status = 'submitted' AND status <> 'cancelled'").get().n,
    newMessages: db.prepare("SELECT COUNT(*) AS n FROM messages WHERE status = 'new'").get().n,
    customers: db.prepare('SELECT COUNT(*) AS n FROM customers').get().n,
    days,
    recent: db.prepare('SELECT id, code, name, total, status, payment_status, created FROM orders ORDER BY id DESC LIMIT 8').all(),
    top: db.prepare("SELECT i.name, SUM(i.qty) AS qty, SUM(i.qty * i.price) AS revenue FROM order_items i JOIN orders o ON o.id = i.order_id WHERE o.status <> 'cancelled' AND date(o.created, ?) >= ? GROUP BY i.name ORDER BY revenue DESC LIMIT 6").all(tz, localToday(-29)),
    lowStock: db.prepare('SELECT id, name, stock, unit FROM products WHERE active = 1 AND stock IS NOT NULL AND stock <= ? ORDER BY stock LIMIT 8').all(I(site.order.lowStock, 5)),
    checklist: { payments: pm > 0, contact: !!(site.contact.phone || site.contact.email), twoFactor: !!db.prepare('SELECT totp_enabled FROM admin WHERE id = 1').get().totp_enabled, defaultPassword: !!db.prepare('SELECT is_default FROM admin WHERE id = 1').get().is_default }
  });
});

/* --- orders --- */
const STATUSES = ['pending', 'confirmed', 'preparing', 'out_for_delivery', 'completed', 'cancelled'];
const PAY_STATUSES = ['unpaid', 'submitted', 'paid', 'refunded'];
function orderFilter(q) {
  const where = [], args = [], tz = tzMod();
  if (STATUSES.includes(q.status)) { where.push('o.status = ?'); args.push(q.status); }
  else if (q.status === 'active') where.push("o.status IN ('pending','confirmed','preparing','out_for_delivery')");
  if (PAY_STATUSES.includes(q.pay)) { where.push('o.payment_status = ?'); args.push(q.pay); }
  if (/^\d{4}-\d{2}-\d{2}$/.test(q.from || '')) { where.push('date(o.created, ?) >= ?'); args.push(tz, q.from); }
  if (/^\d{4}-\d{2}-\d{2}$/.test(q.to || '')) { where.push('date(o.created, ?) <= ?'); args.push(tz, q.to); }
  const s = S(q.q, 60);
  if (s) { where.push("(o.code LIKE ? OR o.name LIKE ? OR o.phone LIKE ?)"); const like = '%' + s.replace(/[%_]/g, '') + '%'; args.push(like, like, like); }
  return { sql: where.length ? 'WHERE ' + where.join(' AND ') : '', args };
}
adm.get('/orders', (req, res) => {
  const f = orderFilter(req.query);
  res.json({
    orders: db.prepare(`SELECT o.id, o.code, o.name, o.phone, o.total, o.status, o.payment_status, o.payment_name, o.fulfillment, o.created,
      (SELECT SUM(qty) FROM order_items WHERE order_id = o.id) AS items FROM orders o ${f.sql} ORDER BY o.id DESC LIMIT 500`).all(...f.args),
    counts: Object.fromEntries(db.prepare('SELECT status, COUNT(*) AS n FROM orders GROUP BY status').all().map((r) => [r.status, r.n]))
  });
});
function fullOrder(id) {
  const o = db.prepare('SELECT * FROM orders WHERE id = ?').get(I(id));
  if (!o) throw bad('Order not found.', 404);
  o.history = JSON.parse(o.history || '[]');
  o.items = db.prepare('SELECT name, unit, price, qty FROM order_items WHERE order_id = ?').all(o.id);
  o.customer = o.customer_id ? db.prepare('SELECT id, name, card_no, points FROM customers WHERE id = ?').get(o.customer_id) : null;
  return o;
}
adm.get('/orders/:id', wrap((req, res) => res.json({ order: fullOrder(req.params.id) })));
adm.patch('/orders/:id', wrap((req, res) => {
  const b = req.body || {};
  tx(() => {
    const o = db.prepare('SELECT * FROM orders WHERE id = ?').get(I(req.params.id));
    if (!o) throw bad('Order not found.', 404);
    const now = nowIso(), hist = JSON.parse(o.history || '[]');
    if (b.status && b.status !== o.status) {
      if (!STATUSES.includes(b.status)) throw bad('Invalid status.');
      if (o.status === 'cancelled') throw bad('A cancelled order cannot be reopened. Please create a new order.');
      hist.push({ status: b.status, ts: now, note: S(b.note, 300), public: true });
      if (b.status === 'completed' && !o.points_awarded && o.points_earned > 0 && o.customer_id && getSetting('loyalty').enabled) {
        db.prepare('UPDATE customers SET points = points + ? WHERE id = ?').run(o.points_earned, o.customer_id);
        db.prepare('INSERT INTO loyalty_tx (customer_id, delta, reason, order_id, ts) VALUES (?,?,?,?,?)').run(o.customer_id, o.points_earned, `Earned from ${o.code}`, o.id, now);
        db.prepare('UPDATE orders SET points_awarded = 1 WHERE id = ?').run(o.id);
      }
      if (b.status === 'cancelled') {
        for (const it of db.prepare('SELECT product_id, qty FROM order_items WHERE order_id = ?').all(o.id)) {
          db.prepare('UPDATE products SET stock = stock + ? WHERE id = ? AND stock IS NOT NULL').run(it.qty, it.product_id);
        }
        if (o.customer_id) {
          let delta = o.points_redeemed;
          if (o.points_awarded) delta -= o.points_earned;
          if (delta) {
            db.prepare('UPDATE customers SET points = MAX(0, points + ?) WHERE id = ?').run(delta, o.customer_id);
            db.prepare('INSERT INTO loyalty_tx (customer_id, delta, reason, order_id, ts) VALUES (?,?,?,?,?)').run(o.customer_id, delta, `Order ${o.code} cancelled`, o.id, now);
          }
          db.prepare('UPDATE orders SET points_awarded = 0 WHERE id = ?').run(o.id);
        }
      }
      db.prepare('UPDATE orders SET status = ?, history = ?, updated = ? WHERE id = ?').run(b.status, JSON.stringify(hist), now, o.id);
      if (b.status === 'completed' && o.payment_type === 'cod' && o.payment_status === 'unpaid') db.prepare("UPDATE orders SET payment_status = 'paid' WHERE id = ?").run(o.id);
    }
    if (b.payment_status && PAY_STATUSES.includes(b.payment_status)) db.prepare('UPDATE orders SET payment_status = ?, updated = ? WHERE id = ?').run(b.payment_status, now, o.id);
    if (typeof b.admin_note === 'string') db.prepare('UPDATE orders SET admin_note = ? WHERE id = ?').run(S(b.admin_note, 1000), o.id);
  });
  res.json({ order: fullOrder(req.params.id) });
}));
adm.delete('/orders/:id', wrap((req, res) => {
  const o = db.prepare('SELECT status, payment_proof FROM orders WHERE id = ?').get(I(req.params.id));
  if (!o) throw bad('Order not found.', 404);
  if (o.status !== 'cancelled') throw bad('Cancel the order first, then delete it.');
  if (o.payment_proof) fs.rm(path.join(PROOF_DIR, path.basename(o.payment_proof)), () => {});
  db.prepare('DELETE FROM orders WHERE id = ?').run(I(req.params.id));
  res.json({ ok: true });
}));

/* --- catalog --- */
adm.get('/catalog', (req, res) => res.json({
  categories: db.prepare('SELECT c.*, (SELECT COUNT(*) FROM products WHERE category_id = c.id) AS products FROM categories c ORDER BY sort, id').all(),
  products: db.prepare('SELECT * FROM products ORDER BY sort, id').all()
}));
function productFields(b) {
  const name = S(b.name, 120);
  if (!name) throw bad('Product name is required.');
  const price = round2(N(b.price, -1));
  if (price < 0 || price > 1e7) throw bad('Enter a valid price.');
  const stock = b.stock === '' || b.stock == null ? null : Math.max(0, I(b.stock));
  const cmp = b.compare_price === '' || b.compare_price == null ? null : round2(N(b.compare_price));
  const cat = I(b.category_id) || null;
  return [name, S(b.description, 600), cat, price, cmp, S(b.unit, 40), stock, img(b.image), S(b.emoji, 8), B(b.featured), b.active === undefined ? 1 : B(b.active), I(b.sort)];
}
adm.post('/products', wrap((req, res) => {
  const id = db.prepare('INSERT INTO products (name, description, category_id, price, compare_price, unit, stock, image, emoji, featured, active, sort, created) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)').run(...productFields(req.body || {}), nowIso()).lastInsertRowid;
  res.status(201).json({ id });
}));
adm.put('/products/:id', wrap((req, res) => {
  const r = db.prepare('UPDATE products SET name=?, description=?, category_id=?, price=?, compare_price=?, unit=?, stock=?, image=?, emoji=?, featured=?, active=?, sort=? WHERE id=?').run(...productFields(req.body || {}), I(req.params.id));
  if (!r.changes) throw bad('Product not found.', 404);
  res.json({ ok: true });
}));
adm.patch('/products/:id', wrap((req, res) => {
  const b = req.body || {}, id = I(req.params.id);
  if ('active' in b) db.prepare('UPDATE products SET active = ? WHERE id = ?').run(B(b.active), id);
  if ('featured' in b) db.prepare('UPDATE products SET featured = ? WHERE id = ?').run(B(b.featured), id);
  if ('stock' in b) db.prepare('UPDATE products SET stock = ? WHERE id = ?').run(b.stock === '' || b.stock == null ? null : Math.max(0, I(b.stock)), id);
  res.json({ ok: true });
}));
adm.delete('/products/:id', (req, res) => { db.prepare('DELETE FROM products WHERE id = ?').run(I(req.params.id)); res.json({ ok: true }); });
adm.post('/categories', wrap((req, res) => {
  const name = S(req.body.name, 60); if (!name) throw bad('Category name is required.');
  const sort = db.prepare('SELECT COALESCE(MAX(sort), 0) + 1 AS s FROM categories').get().s;
  res.status(201).json({ id: db.prepare('INSERT INTO categories (name, emoji, sort) VALUES (?,?,?)').run(name, S(req.body.emoji, 8), sort).lastInsertRowid });
}));
adm.put('/categories/:id', wrap((req, res) => {
  const name = S(req.body.name, 60); if (!name) throw bad('Category name is required.');
  db.prepare('UPDATE categories SET name = ?, emoji = ?, sort = ? WHERE id = ?').run(name, S(req.body.emoji, 8), I(req.body.sort), I(req.params.id));
  res.json({ ok: true });
}));
adm.delete('/categories/:id', (req, res) => { db.prepare('DELETE FROM categories WHERE id = ?').run(I(req.params.id)); res.json({ ok: true }); });

/* --- customers & loyalty --- */
const CUST_SQL = `SELECT c.*, (SELECT COUNT(*) FROM orders WHERE customer_id = c.id AND status <> 'cancelled') AS orders,
  (SELECT COALESCE(SUM(total),0) FROM orders WHERE customer_id = c.id AND status <> 'cancelled') AS spent,
  (SELECT MAX(created) FROM orders WHERE customer_id = c.id) AS last_order FROM customers c`;
function customerRows(q) {
  const s = S(q, 60).replace(/[%_]/g, '');
  return s ? db.prepare(`${CUST_SQL} WHERE c.name LIKE ? OR c.phone LIKE ? OR c.card_no LIKE ? OR c.email LIKE ? ORDER BY c.id DESC LIMIT 1000`).all(...Array(4).fill('%' + s + '%'))
    : db.prepare(`${CUST_SQL} ORDER BY c.id DESC LIMIT 1000`).all();
}
adm.get('/customers', (req, res) => res.json({ customers: customerRows(req.query.q) }));
adm.get('/customers/:id', wrap((req, res) => {
  const c = db.prepare(`${CUST_SQL} WHERE c.id = ?`).get(I(req.params.id));
  if (!c) throw bad('Customer not found.', 404);
  res.json({
    customer: c,
    orders: db.prepare('SELECT id, code, total, status, payment_status, created FROM orders WHERE customer_id = ? ORDER BY id DESC LIMIT 100').all(c.id),
    favorites: db.prepare("SELECT i.name, SUM(i.qty) AS qty, SUM(i.qty*i.price) AS spent FROM order_items i JOIN orders o ON o.id = i.order_id WHERE o.customer_id = ? AND o.status <> 'cancelled' GROUP BY i.name ORDER BY qty DESC LIMIT 8").all(c.id),
    points: db.prepare('SELECT delta, reason, ts FROM loyalty_tx WHERE customer_id = ? ORDER BY id DESC LIMIT 50').all(c.id)
  });
}));
function custFields(b) {
  const name = S(b.name, 80); if (name.length < 2) throw bad('Customer name is required.');
  const phone = normPhone(b.phone); if (!phone) throw bad('Enter a valid mobile number.');
  return [name, phone, S(b.email, 120), S(b.address, 300), S(b.notes, 1000)];
}
adm.post('/customers', wrap((req, res) => {
  const f = custFields(req.body || {});
  if (db.prepare('SELECT 1 FROM customers WHERE phone = ?').get(f[1])) throw bad('A customer with that mobile number already exists.', 409);
  res.status(201).json({ id: db.prepare('INSERT INTO customers (name, phone, email, address, notes, card_no, created) VALUES (?,?,?,?,?,?,?)').run(...f, newCardNo(), nowIso()).lastInsertRowid });
}));
adm.put('/customers/:id', wrap((req, res) => {
  const f = custFields(req.body || {}), id = I(req.params.id);
  if (db.prepare('SELECT 1 FROM customers WHERE phone = ? AND id <> ?').get(f[1], id)) throw bad('Another customer already uses that mobile number.', 409);
  db.prepare('UPDATE customers SET name=?, phone=?, email=?, address=?, notes=? WHERE id=?').run(...f, id);
  res.json({ ok: true });
}));
adm.delete('/customers/:id', (req, res) => { db.prepare('DELETE FROM customers WHERE id = ?').run(I(req.params.id)); res.json({ ok: true }); });
adm.post('/customers/:id/points', wrap((req, res) => {
  const delta = I(req.body.delta), id = I(req.params.id);
  if (!delta || Math.abs(delta) > 1e6) throw bad('Enter the number of points to add or remove.');
  const c = db.prepare('SELECT points FROM customers WHERE id = ?').get(id);
  if (!c) throw bad('Customer not found.', 404);
  if (c.points + delta < 0) throw bad('Customer does not have that many points.');
  tx(() => {
    db.prepare('UPDATE customers SET points = points + ? WHERE id = ?').run(delta, id);
    db.prepare('INSERT INTO loyalty_tx (customer_id, delta, reason, ts) VALUES (?,?,?,?)').run(id, delta, S(req.body.reason, 120) || 'Manual adjustment', nowIso());
  });
  res.json({ ok: true, points: c.points + delta });
}));
adm.get('/loyalty', (req, res) => res.json({
  settings: getSetting('loyalty'),
  stats: db.prepare('SELECT COUNT(*) AS members, COALESCE(SUM(points),0) AS outstanding FROM customers').get(),
  issued: db.prepare('SELECT COALESCE(SUM(CASE WHEN delta > 0 THEN delta END),0) AS earned, COALESCE(-SUM(CASE WHEN delta < 0 THEN delta END),0) AS redeemed FROM loyalty_tx').get(),
  top: db.prepare('SELECT id, name, phone, card_no, points FROM customers ORDER BY points DESC, id LIMIT 200').all(),
  recent: db.prepare('SELECT t.delta, t.reason, t.ts, c.name FROM loyalty_tx t JOIN customers c ON c.id = t.customer_id ORDER BY t.id DESC LIMIT 30').all()
}));
adm.put('/loyalty', wrap((req, res) => {
  const b = req.body || {}, d = DEFAULTS.loyalty, col = (v, f) => (Theme.COLOR_RE.test(v) ? v : f);
  res.json({ settings: setSetting('loyalty', {
    enabled: !!b.enabled, name: S(b.name, 60) || d.name, pesoPerPoint: Math.max(1, N(b.pesoPerPoint, 100)), pointValue: Math.max(0.01, N(b.pointValue, 1)),
    minRedeem: Math.max(1, I(b.minRedeem, 1)), signupBonus: Math.max(0, I(b.signupBonus)), cardBg: col(b.cardBg, d.cardBg), cardBg2: col(b.cardBg2, d.cardBg2), cardFg: col(b.cardFg, d.cardFg)
  }) });
}));

/* --- reports --- */
function reportRange(q) {
  const re = /^\d{4}-\d{2}-\d{2}$/;
  const to = re.test(q.to || '') ? q.to : localToday();
  const from = re.test(q.from || '') ? q.from : localToday(-29);
  return from <= to ? { from, to } : { from: to, to: from };
}
adm.get('/reports', (req, res) => {
  const { from, to } = reportRange(req.query), tz = tzMod();
  const W = "o.status <> 'cancelled' AND date(o.created, ?) BETWEEN ? AND ?", A = [tz, from, to];
  const summary = db.prepare(`SELECT COUNT(*) AS orders, COALESCE(SUM(total),0) AS revenue, COALESCE(SUM(subtotal),0) AS subtotal, COALESCE(SUM(discount),0) AS discounts,
    COALESCE(SUM(delivery_fee),0) AS delivery, COUNT(DISTINCT customer_id) AS customers,
    COALESCE(SUM(CASE WHEN status = 'completed' THEN total END),0) AS completedRevenue, SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed,
    COALESCE(SUM(CASE WHEN payment_status = 'paid' THEN total END),0) AS paidRevenue FROM orders o WHERE ${W}`).get(...A);
  summary.items = db.prepare(`SELECT COALESCE(SUM(i.qty),0) AS n FROM order_items i JOIN orders o ON o.id = i.order_id WHERE ${W}`).get(...A).n;
  summary.cancelled = db.prepare("SELECT COUNT(*) AS n FROM orders o WHERE o.status = 'cancelled' AND date(o.created, ?) BETWEEN ? AND ?").get(...A).n;
  summary.newCustomers = db.prepare('SELECT COUNT(*) AS n FROM customers WHERE date(created, ?) BETWEEN ? AND ?').get(...A).n;
  summary.avg = summary.orders ? round2(summary.revenue / summary.orders) : 0;
  res.json({
    from, to, summary,
    byDay: db.prepare(`SELECT date(o.created, ?) AS day, COUNT(*) AS orders, SUM(total) AS revenue FROM orders o WHERE ${W} GROUP BY day ORDER BY day`).all(tz, ...A),
    byProduct: db.prepare(`SELECT i.name, i.unit, SUM(i.qty) AS qty, SUM(i.qty*i.price) AS revenue, COUNT(DISTINCT o.id) AS orders FROM order_items i JOIN orders o ON o.id = i.order_id WHERE ${W} GROUP BY i.name, i.unit ORDER BY revenue DESC LIMIT 100`).all(...A),
    byCategory: db.prepare(`SELECT COALESCE(i.category,'Uncategorized') AS name, SUM(i.qty) AS qty, SUM(i.qty*i.price) AS revenue FROM order_items i JOIN orders o ON o.id = i.order_id WHERE ${W} GROUP BY 1 ORDER BY revenue DESC`).all(...A),
    byPayment: db.prepare(`SELECT COALESCE(payment_name,'—') AS name, COUNT(*) AS orders, SUM(total) AS revenue FROM orders o WHERE ${W} GROUP BY 1 ORDER BY revenue DESC`).all(...A),
    byFulfillment: db.prepare(`SELECT fulfillment AS name, COUNT(*) AS orders, SUM(total) AS revenue FROM orders o WHERE ${W} GROUP BY 1`).all(...A),
    bySource: db.prepare(`SELECT CASE WHEN COALESCE(source,'') = '' THEN 'Direct visit' ELSE 'QR: ' || source END AS name, COUNT(*) AS orders, SUM(total) AS revenue FROM orders o WHERE ${W} GROUP BY 1 ORDER BY revenue DESC`).all(...A),
    topCustomers: db.prepare(`SELECT o.name, o.phone, COUNT(*) AS orders, SUM(total) AS revenue FROM orders o WHERE ${W} GROUP BY o.phone ORDER BY revenue DESC LIMIT 15`).all(...A)
  });
});
adm.get('/export/orders.csv', (req, res) => {
  const { from, to } = reportRange(req.query), tz = tzMod();
  const rows = db.prepare(`SELECT o.*, datetime(o.created, ?) AS local, (SELECT GROUP_CONCAT(qty || ' x ' || name, '; ') FROM order_items WHERE order_id = o.id) AS items
    FROM orders o WHERE date(o.created, ?) BETWEEN ? AND ? ORDER BY o.id`).all(tz, tz, from, to);
  sendCsv(res, `orders_${from}_to_${to}.csv`, ['Order code', 'Date', 'Customer', 'Mobile', 'Address', 'Type', 'Items', 'Subtotal', 'Delivery fee', 'Discount', 'Total', 'Payment method', 'Payment status', 'Reference', 'Status', 'Source', 'Notes'],
    rows.map((o) => [o.code, o.local, o.name, o.phone, o.address, o.fulfillment, o.items, o.subtotal, o.delivery_fee, o.discount, o.total, o.payment_name, o.payment_status, o.payment_ref, o.status, o.source, o.notes]));
});
adm.get('/export/products.csv', (req, res) => {
  const { from, to } = reportRange(req.query), tz = tzMod();
  const rows = db.prepare(`SELECT i.name, i.category, i.unit, SUM(i.qty) AS qty, SUM(i.qty*i.price) AS revenue FROM order_items i JOIN orders o ON o.id = i.order_id
    WHERE o.status <> 'cancelled' AND date(o.created, ?) BETWEEN ? AND ? GROUP BY i.name, i.unit ORDER BY revenue DESC`).all(tz, from, to);
  sendCsv(res, `product_sales_${from}_to_${to}.csv`, ['Product', 'Category', 'Unit', 'Quantity sold', 'Sales'], rows.map((r) => [r.name, r.category, r.unit, r.qty, round2(r.revenue)]));
});
adm.get('/export/customers.csv', (req, res) => {
  sendCsv(res, 'customers.csv', ['Name', 'Mobile', 'Email', 'Address', 'Loyalty card', 'Points', 'Orders', 'Total spent', 'Last order', 'Customer since', 'Notes'],
    customerRows('').map((c) => [c.name, c.phone, c.email, c.address, c.card_no, c.points, c.orders, round2(c.spent), c.last_order, c.created, c.notes]));
});

/* --- messages --- */
adm.get('/messages', (req, res) => res.json({ messages: db.prepare('SELECT * FROM messages ORDER BY id DESC LIMIT 500').all() }));
adm.patch('/messages/:id', wrap((req, res) => {
  const b = req.body || {}, id = I(req.params.id);
  if (typeof b.reply === 'string') db.prepare("UPDATE messages SET reply = ?, replied_at = ?, status = 'replied' WHERE id = ?").run(S(b.reply, 2000), nowIso(), id);
  if (['new', 'read', 'replied', 'closed'].includes(b.status)) db.prepare('UPDATE messages SET status = ? WHERE id = ?').run(b.status, id);
  res.json({ ok: true });
}));
adm.delete('/messages/:id', (req, res) => { db.prepare('DELETE FROM messages WHERE id = ?').run(I(req.params.id)); res.json({ ok: true }); });

/* --- payment methods --- */
adm.get('/payments', (req, res) => res.json({ methods: db.prepare('SELECT * FROM payment_methods ORDER BY sort, id').all() }));
function payFields(b) {
  const name = S(b.name, 60); if (!name) throw bad('Name is required.');
  const type = ['cod', 'ewallet', 'bank'].includes(b.type) ? b.type : 'ewallet';
  const acct = S(b.account_number, 60), qr = img(b.qr_image), enabled = B(b.enabled);
  if (enabled && type !== 'cod' && !acct && !qr) throw bad('Add an account number or a QR code image before enabling this payment method.');
  return [name, type, S(b.account_name, 80), acct, qr, S(b.instructions, 500), enabled, I(b.sort)];
}
adm.post('/payments', wrap((req, res) => res.status(201).json({ id: db.prepare('INSERT INTO payment_methods (name, type, account_name, account_number, qr_image, instructions, enabled, sort) VALUES (?,?,?,?,?,?,?,?)').run(...payFields(req.body || {})).lastInsertRowid })));
adm.put('/payments/:id', wrap((req, res) => { db.prepare('UPDATE payment_methods SET name=?, type=?, account_name=?, account_number=?, qr_image=?, instructions=?, enabled=?, sort=? WHERE id=?').run(...payFields(req.body || {}), I(req.params.id)); res.json({ ok: true }); }));
adm.delete('/payments/:id', (req, res) => { db.prepare('DELETE FROM payment_methods WHERE id = ?').run(I(req.params.id)); res.json({ ok: true }); });

/* --- site settings / design --- */
const SECTION_KEYS = DEFAULTS.site.sections.order;
function capStrings(v, depth = 0) {
  if (depth > 6) return null;
  if (typeof v === 'string') return v.replace(/\u0000/g, '').slice(0, 3000);
  if (Array.isArray(v)) return v.slice(0, 20).map((x) => capStrings(x, depth + 1));
  if (v && typeof v === 'object') { const o = {}; for (const k of Object.keys(v).slice(0, 80)) o[k] = capStrings(v[k], depth + 1); return o; }
  return typeof v === 'number' || typeof v === 'boolean' ? v : null;
}
function cleanSite(input) {
  const css = input && input.theme && typeof input.theme.customCss === 'string' ? input.theme.customCss.slice(0, 20000) : '';
  const s = require('./server/db').withDefaults(capStrings(input), DEFAULTS.site);
  for (const k of Theme.COLOR_KEYS) if (!Theme.COLOR_RE.test(s.theme[k])) s.theme[k] = DEFAULTS.site.theme[k];
  for (const k of ['bg', 'fg']) if (s.announcement[k] && !Theme.COLOR_RE.test(s.announcement[k])) s.announcement[k] = '';
  if (!Theme.FONTS[s.theme.headingFont]) s.theme.headingFont = DEFAULTS.site.theme.headingFont;
  if (!Theme.FONTS[s.theme.bodyFont]) s.theme.bodyFont = DEFAULTS.site.theme.bodyFont;
  s.theme.customCss = css.replace(/<\/?style/gi, '');
  s.brand.logo = img(s.brand.logo); s.hero.image = img(s.hero.image);
  s.brand.utcOffset = Math.min(14, Math.max(-12, N(s.brand.utcOffset, 8)));
  s.brand.currency = S(s.brand.currency, 4) || '₱';
  s.brand.publicUrl = /^https?:\/\/[^\s"'<>]+$/i.test(s.brand.publicUrl) ? s.brand.publicUrl.replace(/\/+$/, '') : '';
  s.contact.facebook = /^https:\/\/[^\s"'<>]+$/i.test(s.contact.facebook) ? s.contact.facebook : '';
  const order = Array.isArray(s.sections.order) ? s.sections.order.filter((k, i, a) => SECTION_KEYS.includes(k) && a.indexOf(k) === i) : [];
  s.sections.order = order.concat(SECTION_KEYS.filter((k) => !order.includes(k)));
  for (const k of ['deliveryFee', 'freeDeliveryMin', 'minOrder', 'lowStock', 'freeKm', 'freeKmMin', 'feePerKm', 'maxKm']) s.order[k] = Math.max(0, N(s.order[k]));
  s.order.distancePricing = !!s.order.distancePricing;
  s.order.storeLat = Math.min(90, Math.max(-90, N(s.order.storeLat))); s.order.storeLng = Math.min(180, Math.max(-180, N(s.order.storeLng)));
  s.text.steps = (Array.isArray(s.text.steps) ? s.text.steps : []).slice(0, 4).map((x) => ({ icon: S(x && x.icon, 8), title: S(x && x.title, 60), text: S(x && x.text, 240) }));
  return s;
}
adm.get('/settings', (req, res) => res.json({ site: getSetting('site'), defaults: DEFAULTS.site }));
adm.put('/settings', wrap((req, res) => res.json({ site: setSetting('site', cleanSite(req.body && req.body.site)) })));

/* --- QR codes --- */
function baseUrl(req) { return getSetting('site').brand.publicUrl || `${req.protocol}://${req.get('host')}`; }
adm.get('/qr', wrap(async (req, res) => {
  const text = S(req.query.text, 600); if (!text) throw bad('Missing text.');
  const col = (v, d) => (Theme.COLOR_RE.test('#' + v) ? '#' + v : d);
  const opts = { margin: Math.min(8, Math.max(0, I(req.query.margin, 2))), errorCorrectionLevel: 'H', color: { dark: col(req.query.dark, '#000000'), light: col(req.query.light, '#ffffff') } };
  if (req.query.fmt === 'png') {
    const buf = await QRCode.toBuffer(text, { ...opts, type: 'png', width: Math.min(2000, Math.max(200, I(req.query.size, 1000))) });
    if (req.query.dl) res.set('Content-Disposition', 'attachment; filename="qr-code.png"');
    return res.type('png').send(buf);
  }
  if (req.query.dl) res.set('Content-Disposition', 'attachment; filename="qr-code.svg"');
  res.type('image/svg+xml').send(await QRCode.toString(text, { ...opts, type: 'svg' }));
}));
adm.get('/campaigns', (req, res) => {
  const tz = tzMod();
  res.json({
    base: baseUrl(req),
    campaigns: db.prepare("SELECT q.*, (SELECT COUNT(*) FROM orders WHERE source = q.slug AND status <> 'cancelled') AS orders, (SELECT COALESCE(SUM(total),0) FROM orders WHERE source = q.slug AND status <> 'cancelled') AS revenue FROM qr_campaigns q ORDER BY q.id").all(),
    tz
  });
});
adm.post('/campaigns', wrap((req, res) => {
  const name = S(req.body.name, 60); if (!name) throw bad('Give this QR code a name.');
  let slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 30) || 'qr';
  while (db.prepare('SELECT 1 FROM qr_campaigns WHERE slug = ?').get(slug)) slug = slug.slice(0, 26) + '-' + randCode(3).toLowerCase();
  res.status(201).json({ id: db.prepare('INSERT INTO qr_campaigns (name, slug, created) VALUES (?,?,?)').run(name, slug, nowIso()).lastInsertRowid });
}));
adm.delete('/campaigns/:id', (req, res) => { db.prepare('DELETE FROM qr_campaigns WHERE id = ?').run(I(req.params.id)); res.json({ ok: true }); });

app.use('/api/admin', adm);

/* ---------------- fallbacks ---------------- */
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));
app.use((req, res) => (req.method === 'GET' && !path.extname(req.path) ? res.redirect('/') : res.status(404).end()));
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err && err.type === 'entity.too.large') return res.status(413).json({ error: 'That upload is too large.' });
  if (err && (err.status === 400 || err.type === 'entity.parse.failed') && !(err instanceof HttpError)) return res.status(400).json({ error: 'Invalid request.' });
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
  console.error(err);
  res.status(500).json({ error: 'Something went wrong. Please try again.' });
});

sec.ensureAdmin().then(() => {
  app.listen(PORT, () => console.log(`CK&J store running on http://localhost:${PORT}  (admin: /admin)`));
}).catch((e) => { console.error(e); process.exit(1); });
