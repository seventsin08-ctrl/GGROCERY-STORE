/* Delivery distance + fee rules, shared by the server and the storefront. */
(function (root, factory) { if (typeof module === 'object' && module.exports) module.exports = factory(); else root.CKJDelivery = factory(); })(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var num = function (v) { v = Number(v); return isFinite(v) ? v : 0; };
  // straight-line distance in km
  function km(lat1, lng1, lat2, lng2) {
    var r = Math.PI / 180, dLat = (lat2 - lat1) * r, dLng = (lng2 - lng1) * r;
    var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
    return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }
  function validPoint(lat, lng) { return typeof lat === 'number' && typeof lng === 'number' && isFinite(lat) && isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180 && !(lat === 0 && lng === 0); }
  // is distance-based pricing switched on and usable?
  function active(o) { return !!o.distancePricing && validPoint(num(o.storeLat), num(o.storeLng)); }
  // distance from the store to a customer, rounded to 0.01 km (null if unknown)
  function distance(o, lat, lng) { return active(o) && validPoint(lat, lng) ? Math.round(km(num(o.storeLat), num(o.storeLng), lat, lng) * 100) / 100 : null; }
  // delivery fee for an order; dist = km from the store, or null when the customer did not share a location
  function fee(o, subtotal, dist) {
    var f = num(o.deliveryFee);
    if (active(o) && dist != null) {
      if (dist > num(o.freeKm)) f += num(o.feePerKm) * Math.ceil(dist - num(o.freeKm));
      else f = num(o.freeKmMin) > 0 && subtotal < num(o.freeKmMin) ? f + num(o.feePerKm) : 0; // inside the free radius: free only from the minimum purchase
    }
    if (f && num(o.freeDeliveryMin) > 0 && subtotal >= num(o.freeDeliveryMin)) f = 0;
    return Math.round(f * 100) / 100;
  }
  function tooFar(o, dist) { return active(o) && dist != null && num(o.maxKm) > 0 && dist > num(o.maxKm); }
  return { km: km, validPoint: validPoint, active: active, distance: distance, fee: fee, tooFar: tooFar };
});
