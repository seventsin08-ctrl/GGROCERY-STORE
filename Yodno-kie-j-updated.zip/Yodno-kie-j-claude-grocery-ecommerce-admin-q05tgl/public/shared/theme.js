/* Shared theme engine — used by the server (theme.css) and the browser (live preview). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CKJTheme = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var SYS = '-apple-system,BlinkMacSystemFont,"SF Pro Display","SF Pro Text","Helvetica Neue",Helvetica,Arial,sans-serif';
  var SERIF = 'Georgia,"Times New Roman",serif';

  // name -> { g: Google Fonts family spec (optional), serif: bool }
  var FONTS = {
    'System (Apple style)': {},
    'Inter': { g: 'Inter:wght@400;500;600;700;800' },
    'Poppins': { g: 'Poppins:wght@400;500;600;700;800' },
    'Montserrat': { g: 'Montserrat:wght@400;500;600;700;800' },
    'DM Sans': { g: 'DM+Sans:wght@400;500;600;700;800' },
    'Plus Jakarta Sans': { g: 'Plus+Jakarta+Sans:wght@400;500;600;700;800' },
    'Manrope': { g: 'Manrope:wght@400;500;600;700;800' },
    'Outfit': { g: 'Outfit:wght@400;500;600;700;800' },
    'Nunito': { g: 'Nunito:wght@400;500;600;700;800' },
    'Raleway': { g: 'Raleway:wght@400;500;600;700;800' },
    'Roboto': { g: 'Roboto:wght@400;500;700;900' },
    'Open Sans': { g: 'Open+Sans:wght@400;500;600;700;800' },
    'Space Grotesk': { g: 'Space+Grotesk:wght@400;500;600;700' },
    'Sora': { g: 'Sora:wght@400;500;600;700;800' },
    'Playfair Display': { g: 'Playfair+Display:wght@400;500;600;700;800', serif: true },
    'Cormorant Garamond': { g: 'Cormorant+Garamond:wght@400;500;600;700', serif: true },
    'Lora': { g: 'Lora:wght@400;500;600;700', serif: true },
    'Libre Baskerville': { g: 'Libre+Baskerville:wght@400;700', serif: true },
    'DM Serif Display': { g: 'DM+Serif+Display', serif: true }
  };

  var PRESETS = {
    'CK&J Navy': { primary: '#0b1a4a', onPrimary: '#ffffff', accent: '#0071e3', bg: '#fbfbfd', surface: '#ffffff', text: '#1d1d1f', muted: '#6e6e73', border: '#e3e3e8', heroBg: '#0a1433', heroText: '#ffffff', footerBg: '#f5f5f7', footerText: '#6e6e73' },
    'Pure White': { primary: '#0071e3', onPrimary: '#ffffff', accent: '#0071e3', bg: '#ffffff', surface: '#ffffff', text: '#1d1d1f', muted: '#6e6e73', border: '#e3e3e8', heroBg: '#f5f5f7', heroText: '#1d1d1f', footerBg: '#f5f5f7', footerText: '#6e6e73' },
    'Midnight': { primary: '#2997ff', onPrimary: '#ffffff', accent: '#2997ff', bg: '#000000', surface: '#161617', text: '#f5f5f7', muted: '#a1a1a6', border: '#2c2c2e', heroBg: '#000000', heroText: '#f5f5f7', footerBg: '#0d0d0e', footerText: '#86868b' },
    'Fresh Market': { primary: '#17633a', onPrimary: '#ffffff', accent: '#2e9e5b', bg: '#fafcf9', surface: '#ffffff', text: '#18241c', muted: '#627066', border: '#dfe8e1', heroBg: '#0f3d25', heroText: '#ffffff', footerBg: '#f0f5f1', footerText: '#627066' },
    'Golden Grain': { primary: '#8a5a13', onPrimary: '#ffffff', accent: '#c98a1b', bg: '#fdfbf6', surface: '#ffffff', text: '#2a2115', muted: '#7a6d5b', border: '#ebe3d3', heroBg: '#3b2a10', heroText: '#fff8e8', footerBg: '#f6f1e5', footerText: '#7a6d5b' },
    'Graphite': { primary: '#1d1d1f', onPrimary: '#ffffff', accent: '#bf4800', bg: '#f5f5f7', surface: '#ffffff', text: '#1d1d1f', muted: '#6e6e73', border: '#d9d9de', heroBg: '#1d1d1f', heroText: '#f5f5f7', footerBg: '#e8e8ed', footerText: '#6e6e73' },
    'Rose Market': { primary: '#b0264c', onPrimary: '#ffffff', accent: '#e0527a', bg: '#fffafb', surface: '#ffffff', text: '#2a1a1f', muted: '#7d6a70', border: '#f0dfe4', heroBg: '#4a1023', heroText: '#ffffff', footerBg: '#faf0f3', footerText: '#7d6a70' }
  };

  var COLOR_KEYS = ['primary', 'onPrimary', 'accent', 'bg', 'surface', 'text', 'muted', 'border', 'heroBg', 'heroText', 'footerBg', 'footerText'];
  var COLOR_RE = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/;
  var DEFAULT = PRESETS['CK&J Navy'];

  function color(v, fallback) { return typeof v === 'string' && COLOR_RE.test(v) ? v : fallback; }
  function clamp(n, lo, hi, d) { n = Number(n); return isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; }
  function stack(name) {
    var f = FONTS[name];
    if (!f || !f.g) return SYS;
    return '"' + name + '",' + (f.serif ? SERIF : SYS);
  }

  function vars(t) {
    t = t || {};
    var radius = clamp(t.radius, 0, 40, 20);
    var shape = t.buttonShape;
    var btn = shape === 'square' ? '4px' : shape === 'rounded' ? '12px' : '980px';
    var v = {};
    COLOR_KEYS.forEach(function (k) {
      v['--' + k.replace(/[A-Z]/g, function (m) { return '-' + m.toLowerCase(); })] = color(t[k], DEFAULT[k]);
    });
    v['--radius'] = radius + 'px';
    v['--radius-sm'] = Math.round(radius * 0.6) + 'px';
    v['--btn-radius'] = btn;
    v['--font-head'] = stack(t.headingFont);
    v['--font-body'] = stack(t.bodyFont);
    v['--head-weight'] = String(clamp(t.headingWeight, 300, 900, 700));
    v['--head-spacing'] = clamp(t.headingSpacing, -0.06, 0.1, -0.025) + 'em';
    v['--base-size'] = clamp(t.baseSize, 14, 20, 17) + 'px';
    v['--hero-scale'] = String(clamp(t.heroScale, 0.6, 1.4, 1));
    return v;
  }

  function fontUrl(t) {
    t = t || {};
    var fams = [];
    [t.headingFont, t.bodyFont].forEach(function (n) {
      var f = FONTS[n];
      if (f && f.g && fams.indexOf(f.g) < 0) fams.push(f.g);
    });
    if (!fams.length) return null;
    return 'https://fonts.googleapis.com/css2?' + fams.map(function (f) { return 'family=' + f; }).join('&') + '&display=swap';
  }

  function css(t) {
    var v = vars(t), out = '';
    var url = fontUrl(t);
    if (url) out += '@import url("' + url + '");\n';
    out += ':root{' + Object.keys(v).map(function (k) { return k + ':' + v[k]; }).join(';') + '}\n';
    if (t && typeof t.customCss === 'string') out += t.customCss.replace(/@import[^;]*;?/gi, '') + '\n';
    return out;
  }

  // Apply to a live document (browser only)
  function apply(t, doc) {
    doc = doc || document;
    var v = vars(t), rs = doc.documentElement.style;
    Object.keys(v).forEach(function (k) { rs.setProperty(k, v[k]); });
    var url = fontUrl(t), link = doc.getElementById('ckj-font');
    if (url) {
      if (!link) { link = doc.createElement('link'); link.id = 'ckj-font'; link.rel = 'stylesheet'; doc.head.appendChild(link); }
      if (link.getAttribute('href') !== url) link.setAttribute('href', url);
    }
    var st = doc.getElementById('ckj-custom-css');
    if (!st) { st = doc.createElement('style'); st.id = 'ckj-custom-css'; doc.head.appendChild(st); }
    st.textContent = (t && typeof t.customCss === 'string') ? t.customCss.replace(/@import[^;]*;?/gi, '') : '';
  }

  return { FONTS: FONTS, PRESETS: PRESETS, COLOR_KEYS: COLOR_KEYS, COLOR_RE: COLOR_RE, vars: vars, fontUrl: fontUrl, css: css, apply: apply };
});
