(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const nl = (s) => esc(s).replace(/\n/g, '<br>');
  const store = {
    get(k, d) { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private mode */ } }
  };
  const params = new URLSearchParams(location.search);
  const PREVIEW = params.has('preview');
  if (params.get('src')) { try { sessionStorage.setItem('ckj_src', params.get('src')); } catch { /* ignore */ } }

  let D = null;                                   // store data from the server
  let cart = store.get('ckj_cart', {});           // { productId: qty }
  const st = { cat: 0, q: '', overlay: null, co: Object.assign({ fulfillment: 'delivery' }, store.get('ckj_info', {})), order: null, newCard: null, tracked: null, trackErr: '', loy: null, msg: null, busy: false, err: '' };

  async function api(method, url, body) {
    const r = await fetch('/api' + url, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || 'Something went wrong. Please try again.');
    return j;
  }
  const money = (n) => (D.site.brand.currency || '₱') + Number(n || 0).toLocaleString('en-PH', { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 });
  const when = (iso) => new Date(iso).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  const prod = (id) => D.products.find((p) => p.id === Number(id));
  const cartLines = () => Object.entries(cart).map(([id, qty]) => ({ p: prod(id), qty })).filter((l) => l.p && l.qty > 0);
  const cartCount = () => cartLines().reduce((n, l) => n + l.qty, 0);
  const subtotal = () => cartLines().reduce((n, l) => n + l.p.price * l.qty, 0);
  let toastT;
  function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2600); }
  const STATUS = { pending: 'Order placed', confirmed: 'Confirmed', preparing: 'Preparing', out_for_delivery: 'Out for delivery', completed: 'Completed', cancelled: 'Cancelled' };
  const PAY = { unpaid: 'Awaiting payment', submitted: 'Payment sent — verifying', paid: 'Paid', refunded: 'Refunded' };
  const ICON = {
    bag: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 7h12l1 13H5L6 7z"/><path d="M9 7a3 3 0 0 1 6 0"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>'
  };

  /* ---------------- page ---------------- */
  function thumb(p) { return p.image ? `<img src="${esc(p.image)}" alt="" loading="lazy">` : esc(p.emoji || '🛒'); }
  function control(p) {
    const q = cart[p.id] || 0;
    if (p.stock != null && p.stock <= 0) return '<span class="note">Sold out</span>';
    if (!q) return `<button class="btn sm" data-act="add" data-id="${p.id}">Add</button>`;
    return `<div class="stepper"><button data-act="dec" data-id="${p.id}" aria-label="Remove one">−</button><span>${q}</span><button data-act="inc" data-id="${p.id}" aria-label="Add one">+</button></div>`;
  }
  function card(p) {
    const low = Number(D.site.order.lowStock) || 5;
    let badge = '';
    if (p.stock != null && p.stock <= 0) badge = '<span class="badge">Sold out</span>';
    else if (p.compare_price > p.price) badge = '<span class="badge sale">Sale</span>';
    else if (D.site.cards.showStock && p.stock != null && p.stock <= low) badge = `<span class="badge low">Only ${p.stock} left</span>`;
    return `<article class="card"><button class="card-img ${D.site.cards.imageFit === 'contain' ? 'contain' : ''}" data-act="view" data-id="${p.id}" aria-label="${esc(p.name)}">${thumb(p)}${badge}</button>
      <div class="card-body"><h3>${esc(p.name)}</h3><span class="unit">${esc(p.unit || '')}</span>
      <div class="card-foot"><span class="price">${money(p.price)}${p.compare_price > p.price ? `<s>${money(p.compare_price)}</s>` : ''}</span><span data-ctl="${p.id}">${control(p)}</span></div></div></article>`;
  }
  function gridHtml() {
    const q = st.q.trim().toLowerCase();
    const list = D.products.filter((p) => (!st.cat || p.category_id === st.cat) && (!q || (p.name + ' ' + (p.description || '')).toLowerCase().includes(q)));
    return list.length ? list.map(card).join('') : '<div class="empty">No products found. Try another search or category.</div>';
  }
  const chipsHtml = () => `<button class="chip ${st.cat ? '' : 'on'}" data-act="cat" data-id="0">All</button>` + D.categories.map((c) => `<button class="chip ${st.cat === c.id ? 'on' : ''}" data-act="cat" data-id="${c.id}">${esc(c.name)}</button>`).join('');

  const sections = {
    categories: (s, t) => (D.categories.length ? `<section class="sec" id="categories"><div class="wrap"><div class="sec-head reveal"><h2>${esc(t.categoriesTitle)}</h2></div>
      <div class="cats reveal">${D.categories.map((c) => `<button class="cat" data-act="cat" data-id="${c.id}" data-jump="1"><i>${esc(c.emoji || '🛒')}</i><span>${esc(c.name)}</span></button>`).join('')}</div></div></section>` : ''),
    featured: (s, t) => { const f = D.products.filter((p) => p.featured); return f.length ? `<section class="sec alt" id="featured"><div class="wrap"><div class="sec-head reveal"><h2>${esc(t.featuredTitle)}</h2><p>${esc(t.featuredSub)}</p></div><div class="grid reveal" id="grid-f">${f.map(card).join('')}</div></div></section>` : ''; },
    products: (s, t) => `<section class="sec" id="shop"><div class="wrap"><div class="sec-head reveal"><h2>${esc(t.productsTitle)}</h2><p>${esc(t.productsSub)}</p></div>
      <div class="tools"><label class="search">${ICON.search}<input type="search" id="search" placeholder="Search products" value="${esc(st.q)}" aria-label="Search products"></label><div class="chips" id="chips">${chipsHtml()}</div></div>
      <div class="grid" id="grid">${gridHtml()}</div></div></section>`,
    steps: (s, t) => (t.steps && t.steps.length ? `<section class="sec alt" id="how"><div class="wrap"><div class="sec-head center reveal"><h2>${esc(t.stepsTitle)}</h2></div><div class="steps reveal">${t.steps.map((x) => `<div class="step"><i>${esc(x.icon)}</i><h3>${esc(x.title)}</h3><p>${esc(x.text)}</p></div>`).join('')}</div></div></section>` : ''),
    loyalty: (s, t) => {
      if (!D.loyalty.enabled) return '';
      const L = D.loyalty;
      return `<section class="sec" id="rewards"><div class="wrap duo"><div class="reveal"><div class="loy-card" style="--lc-a:${esc(L.cardBg)};--lc-b:${esc(L.cardBg2)};--lc-fg:${esc(L.cardFg)}">
        <div class="lc-top"><span>${esc(L.name)}</span>${s.brand.logo ? `<img src="${esc(s.brand.logo)}" alt="">` : ''}</div>
        <div><small>Card number</small><div class="lc-no">${st.loy ? esc(st.loy.cardNo.replace(/(\d{4})(?=\d)/g, '$1 ')) : '8••• •••• ••••'}</div></div>
        <div class="lc-bot"><span><small>Member</small>${st.loy ? esc(st.loy.name) : 'Your name'}</span><span><small>Points</small>${st.loy ? st.loy.points.toLocaleString() : '—'}</span></div></div></div>
        <div class="reveal"><div class="sec-head"><h2>${esc(t.loyaltyTitle)}</h2><p>${esc(t.loyaltyText)}</p></div>
        <p class="note">Earn 1 point for every ${money(L.pesoPerPoint)} spent. Each point is worth ${money(L.pointValue)}.</p>
        <form class="inline-form" data-form="loyalty"><input name="cardNo" inputmode="numeric" placeholder="Enter your card number" aria-label="Loyalty card number" required><button class="btn">Check points</button></form>
        <div id="loy-out" style="margin-top:14px">${st.loy ? `<div class="okbox">Hi ${esc(st.loy.name)}! You have <b>${st.loy.points.toLocaleString()} points</b> worth ${money(st.loy.value)}.</div>` : ''}</div></div></div></section>`;
    },
    track: (s, t) => `<section class="sec alt" id="track"><div class="wrap" style="max-width:760px"><div class="sec-head center reveal"><h2>${esc(t.trackTitle)}</h2><p>${esc(t.trackText)}</p></div>
      <div class="panel reveal"><form class="inline-form" style="margin-top:0" data-form="track"><input name="code" placeholder="e.g. ${esc(s.order.prefix || 'CKJ')}-AB12CD" autocapitalize="characters" autocomplete="off" aria-label="Tracking code" required><button class="btn">Track</button></form>
      <div id="recent">${recentHtml()}</div><div id="track-out">${trackHtml()}</div></div></div></section>`,
    contact: (s, t) => {
      const c = s.contact, rows = [];
      if (c.phone) rows.push(`<div><i>📞</i><span><small>Call or text</small><a href="tel:${esc(c.phone.replace(/[^\d+]/g, ''))}">${esc(c.phone)}</a></span></div>`);
      if (c.email) rows.push(`<div><i>✉️</i><span><small>Email</small><a href="mailto:${esc(c.email)}">${esc(c.email)}</a></span></div>`);
      if (c.address) rows.push(`<div><i>📍</i><span><small>Visit us</small>${nl(c.address)}</span></div>`);
      if (c.hours) rows.push(`<div><i>🕒</i><span><small>Store hours</small>${nl(c.hours)}</span></div>`);
      if (c.facebook) rows.push(`<div><i>💬</i><span><small>Facebook</small><a href="${esc(c.facebook)}" target="_blank" rel="noopener noreferrer">Message us on Facebook</a></span></div>`);
      return `<section class="sec" id="contact"><div class="wrap duo" style="align-items:start"><div class="reveal"><div class="sec-head" style="margin-bottom:0"><h2>${esc(t.contactTitle)}</h2><p>${esc(t.contactText)}</p></div><div class="contact-list">${rows.join('')}</div></div>
        <div class="panel reveal" id="contact-panel">${contactHtml()}</div></div></section>`;
    }
  };

  function heroHtml(s) {
    const h = s.hero, layout = ['center', 'split', 'image'].includes(h.layout) ? h.layout : 'center';
    const align = layout === 'split' ? 'left' : (h.align === 'left' ? 'left' : 'center');
    const copy = `<div class="hero-copy reveal">${h.showLogo && s.brand.logo && layout !== 'split' ? `<img class="hero-logo" src="${esc(s.brand.logo)}" alt="${esc(s.brand.name)}">` : ''}
      ${h.eyebrow ? `<p class="eyebrow">${esc(h.eyebrow)}</p>` : ''}<h1>${nl(h.title)}</h1>${h.subtitle ? `<p class="sub">${nl(h.subtitle)}</p>` : ''}
      <div class="hero-cta">${h.cta1 ? `<a class="btn lg" href="#shop">${esc(h.cta1)}</a>` : ''}${h.cta2 ? `<a class="btn lg ghost" href="#track">${esc(h.cta2)}</a>` : ''}</div></div>`;
    const bg = layout === 'image' && h.image ? `<div class="hero-bg" style="background-image:url('${esc(h.image)}')"></div><div class="hero-shade" style="opacity:${Math.min(90, Math.max(0, Number(h.overlay) || 0)) / 100}"></div>` : '';
    const art = layout === 'split' ? `<div class="hero-art reveal"><img src="${esc(h.image || s.brand.logo || '/assets/logo.jpg')}" alt=""></div>` : '';
    return `<header class="hero ${layout} ${align} ${['tall', 'medium', 'compact'].includes(h.height) ? h.height : 'tall'}">${bg}<div class="wrap">${copy}${art}</div></header>`;
  }

  function render() {
    const s = D.site, t = s.text, en = s.sections.enabled, a = s.announcement;
    document.documentElement.style.setProperty('--cols', Math.min(5, Math.max(2, Number(s.cards.columns) || 4)));
    const links = [['shop', 'Shop', en.products], ['rewards', 'Rewards', en.loyalty && D.loyalty.enabled], ['track', 'Track order', en.track, 'keep'], ['contact', 'Contact', en.contact]];
    $('#app').innerHTML = `
      ${a.enabled && a.text ? `<div class="announce" style="${a.bg ? `background:${esc(a.bg)};` : ''}${a.fg ? `color:${esc(a.fg)}` : ''}">${esc(a.text)}</div>` : ''}
      ${s.order.accepting ? '' : `<div class="closed-banner">${esc(s.order.closedMessage)}</div>`}
      <nav class="nav"><div class="wrap"><a class="brand" href="#top">${s.brand.logo ? `<img src="${esc(s.brand.logo)}" alt="${esc(s.brand.short)}" style="height:${Math.min(56, Math.max(20, Number(s.brand.logoHeight) || 40))}px">` : ''}${s.brand.showNameInNav || !s.brand.logo ? `<span>${esc(s.brand.short || s.brand.name)}</span>` : ''}</a>
        <div class="nav-links">${links.filter((l) => l[2]).map((l) => `<a href="#${l[0]}" class="${l[3] || ''}">${l[1]}</a>`).join('')}</div>
        <button class="cart-btn" data-act="cart" aria-label="Open cart">${ICON.bag}<span>Cart</span><b id="cart-n">${cartCount()}</b></button></div></nav>
      <span id="top"></span>${heroHtml(s)}
      <main>${s.sections.order.map((k) => (en[k] && sections[k] ? sections[k](s, t) : '')).join('')}</main>
      <footer class="foot"><div class="wrap"><div>© ${new Date().getFullYear()} ${esc(t.footerText)}${t.footerNote ? `<br>${esc(t.footerNote)}` : ''}</div>
        <nav>${links.filter((l) => l[2]).map((l) => `<a href="#${l[0]}">${l[1]}</a>`).join('')}</nav><a class="adm-btn" href="/admin" rel="nofollow">🔒 Admin</a></div></footer>`;
    observe();
  }
  let io;
  function observe() {
    if (io) io.disconnect();
    if (!('IntersectionObserver' in window) || PREVIEW) { document.querySelectorAll('.reveal').forEach((e) => e.classList.add('in')); return; }
    io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: 0.08 });
    document.querySelectorAll('.reveal').forEach((e) => io.observe(e));
  }
  function refreshCart() {
    store.set('ckj_cart', cart);
    const n = $('#cart-n'); if (n) n.textContent = cartCount();
    document.querySelectorAll('[data-ctl]').forEach((el) => { const p = prod(el.dataset.ctl); if (p) el.innerHTML = control(p); });
    if (st.overlay === 'cart') renderOverlay();
  }
  function setQty(id, q) {
    const p = prod(id); if (!p) return;
    const max = p.stock == null ? 999 : Math.min(999, p.stock);
    if (q > max) { toast(`Only ${max} available`); q = max; }
    if (q <= 0) delete cart[id]; else cart[id] = q;
    refreshCart();
  }

  /* ---------------- tracking / contact fragments ---------------- */
  function recentHtml() {
    const mine = store.get('ckj_orders', []);
    return mine.length ? `<div class="recent"><span class="note">Your recent orders:</span>${mine.slice(0, 5).map((c) => `<button class="chip" data-act="track" data-code="${esc(c)}">${esc(c)}</button>`).join('')}</div>` : '';
  }
  function payPanel(o) {
    const p = o.payment;
    if (!p || o.status === 'cancelled' || o.paymentStatus === 'paid' || o.paymentStatus === 'refunded') return '';
    const sent = o.paymentStatus === 'submitted';
    return `<div class="pay"><h4>Pay with ${esc(p.name)}</h4><p class="note">${esc(p.instructions || '')}</p>
      ${p.qr_image ? `<img class="pay-qr" src="${esc(p.qr_image)}" alt="Payment QR code">` : ''}
      ${p.account_name ? `<div class="kv"><span>Account name</span><b>${esc(p.account_name)}</b></div>` : ''}
      ${p.account_number ? `<div class="kv"><span>Account number</span><b>${esc(p.account_number)}<button class="copy" data-act="copy" data-text="${esc(p.account_number)}">Copy</button></b></div>` : ''}
      <div class="kv"><span>Amount to pay</span><b>${money(o.total)}</b></div>
      ${sent ? `<div class="okbox" style="margin-top:12px">We received your payment details (ref ${esc(o.paymentRef)}). We’ll verify it shortly.</div>` : ''}
      <form data-form="pay" data-code="${esc(o.code)}" style="margin-top:16px"><div class="field"><label>${sent ? 'Update reference number' : 'Reference number'}</label><input name="reference" placeholder="From your payment receipt" required minlength="4" maxlength="60"></div>
      <div class="field"><label>Screenshot of receipt (optional)</label><input type="file" name="proof" accept="image/*"></div><div data-err></div><button class="btn block">${sent ? 'Update payment details' : 'I’ve paid — submit'}</button></form></div>`;
  }
  function orderHtml(o) {
    const pickup = o.fulfillment === 'pickup';
    const steps = ['pending', 'confirmed', 'preparing', 'out_for_delivery', 'completed'];
    const label = (k) => (k === 'out_for_delivery' ? (pickup ? 'Ready for pickup' : 'Out for delivery') : k === 'completed' ? (pickup ? 'Picked up' : 'Delivered') : STATUS[k]);
    const idx = steps.indexOf(o.status);
    const at = (k) => { const h = o.history.filter((x) => x.status === k).pop(); return h ? `<small>${when(h.ts)}${h.note ? ' · ' + esc(h.note) : ''}</small>` : ''; };
    const cancelled = o.status === 'cancelled';
    return `<div style="margin-top:24px"><div class="kv"><span>Order</span><b>${esc(o.code)}</b></div>
      <div class="kv"><span>Status</span><b><span class="pill ${o.status}">${cancelled ? 'Cancelled' : label(o.status)}</span></b></div>
      <div class="kv"><span>Payment</span><b>${esc(o.paymentName || '')} · <span class="pill ${o.paymentStatus}">${o.paymentType === 'cod' && o.paymentStatus === 'unpaid' ? 'Pay on ' + (pickup ? 'pickup' : 'delivery') : PAY[o.paymentStatus]}</span></b></div>
      ${cancelled ? `<div class="err" style="margin-top:14px">This order was cancelled.${(() => { const h = o.history.filter((x) => x.status === 'cancelled').pop(); return h && h.note ? ' ' + esc(h.note) : ''; })()} Please contact us if you have questions.</div>`
        : `<ol class="tl">${steps.map((k, i) => `<li class="${i < idx || o.status === 'completed' ? 'ok' : i === idx ? 'now ok' : ''}"><b>${label(k)}</b>${i <= idx ? at(k) : ''}</li>`).join('')}</ol>`}
      ${payPanel(o)}
      <h4 class="grp">Items</h4>${o.items.map((i) => `<div class="kv"><span>${i.qty} × ${esc(i.name)}</span><b>${money(i.price * i.qty)}</b></div>`).join('')}
      <div class="sum" style="margin-top:12px"><div><span>Subtotal</span><span>${money(o.subtotal)}</span></div>${pickup ? '' : `<div><span>Delivery</span><span>${o.deliveryFee ? money(o.deliveryFee) : 'Free'}</span></div>`}
      ${o.discount ? `<div class="neg"><span>Points used (${o.pointsRedeemed})</span><span>−${money(o.discount)}</span></div>` : ''}<div class="tot"><span>Total</span><span>${money(o.total)}</span></div></div>
      ${o.pointsEarned && !cancelled ? `<p class="note" style="margin-top:10px">${o.status === 'completed' ? 'You earned' : 'You’ll earn'} ${o.pointsEarned} loyalty point${o.pointsEarned === 1 ? '' : 's'} ${o.status === 'completed' ? 'from' : 'when'} this order${o.status === 'completed' ? '' : ' is completed'}.</p>` : ''}</div>`;
  }
  const trackHtml = () => (st.trackErr ? `<div class="err" style="margin-top:18px">${esc(st.trackErr)}</div>` : st.tracked ? orderHtml(st.tracked) : '');
  function contactHtml() {
    if (st.msg && st.msg.ticket) return `<div class="done"><div class="tick">✓</div><h3>Message sent</h3><p class="muted" style="margin-top:8px">We’ll get back to you soon. Keep this code to check for our reply:</p>
      <div class="code-box"><b>${esc(st.msg.ticket)}</b><button class="copy" data-act="copy" data-text="${esc(st.msg.ticket)}">Copy</button></div><div><button class="link" data-act="msg-new">Send another message</button></div></div>`;
    return `<form data-form="contact"><h4 class="grp">Send us a message</h4><div class="row2"><div class="field"><label>Your name</label><input name="name" required maxlength="80" value="${esc(st.co.name || '')}"></div>
      <div class="field"><label>Mobile number or email</label><input name="contact" required maxlength="120" value="${esc(st.co.phone || '')}"></div></div>
      <div class="field"><label>Order code (optional)</label><input name="orderCode" maxlength="30"></div><div class="field"><label>Message</label><textarea name="message" required minlength="5" maxlength="2000"></textarea></div>
      <div data-err></div><button class="btn block">Send message</button></form>
      <form class="inline-form" data-form="reply" style="border-top:1px solid var(--border);padding-top:18px"><input name="ticket" placeholder="Have a message code? MSG-XXXXXX" aria-label="Message code" required><button class="btn soft">Check reply</button></form>
      <div id="reply-out">${st.msg && st.msg.view ? `<div class="pay"><p class="note">${when(st.msg.view.created)} — you wrote:</p><p>${nl(st.msg.view.body)}</p>${st.msg.view.reply ? `<div class="okbox" style="margin-top:12px"><b>Our reply</b><br>${nl(st.msg.view.reply)}</div>` : '<p class="note" style="margin-top:10px">No reply yet — we’ll answer as soon as we can.</p>'}</div>` : ''}${st.msg && st.msg.err ? `<div class="err" style="margin-top:12px">${esc(st.msg.err)}</div>` : ''}</div>`;
  }
  async function track(code, scroll) {
    code = String(code || '').trim().toUpperCase(); if (!code) return;
    try { st.tracked = (await api('GET', '/orders/' + encodeURIComponent(code))).order; st.trackErr = ''; }
    catch (e) { st.tracked = null; st.trackErr = e.message; }
    const out = $('#track-out'); if (out) out.innerHTML = trackHtml();
    if (scroll) { const el = $('#track'); if (el) el.scrollIntoView({ behavior: 'smooth' }); }
  }
  setInterval(() => { if (st.tracked && !document.hidden && !st.overlay && !['completed', 'cancelled'].includes(st.tracked.status) && !document.activeElement.closest('[data-form="pay"]')) track(st.tracked.code); }, 30000);

  /* ---------------- overlays ---------------- */
  function open(name) { st.overlay = name; st.err = ''; renderOverlay(); }
  function close() { st.overlay = null; renderOverlay(); }
  const DL = window.CKJDelivery;
  const dist = () => (st.co.geo ? DL.distance(D.site.order, st.co.geo.lat, st.co.geo.lng) : null);
  function geoHtml() {
    const o = D.site.order, d = dist();
    if (!DL.active(o)) return '';
    const far = DL.tooFar(o, d), f = DL.fee(o, subtotal(), d);
    const need = o.freeKmMin > 0 ? ` for orders of ${money(o.freeKmMin)} or more` : '';
    const short = d != null && d <= o.freeKm && f && o.freeKmMin > subtotal() ? ` Add ${money(o.freeKmMin - subtotal())} more for free delivery.` : '';
    const msg = d == null ? `Free delivery within ${o.freeKm} km of the store${need}. Tap the button so we can work out your fee.`
      : far ? `You are about ${d} km from the store. We only deliver within ${o.maxKm} km — please choose store pickup.`
      : `You are about ${d} km from the store — ${f ? 'delivery fee ' + money(f) : 'free delivery'}.${short}`;
    return `<div class="geo"><button type="button" class="btn soft" data-act="co-geo" ${st.co.geoBusy ? 'disabled' : ''}>${st.co.geoBusy ? 'Finding you…' : d == null ? '📍 Use my location' : '📍 Update my location'}</button><p class="note ${far ? 'bad' : d != null && !f ? 'good' : ''}">${esc(msg)}</p>${st.co.geoErr ? `<p class="note bad">${esc(st.co.geoErr)}</p>` : ''}<div id="co-map" class="co-map"></div><p class="note">${d == null ? 'Or tap the map to drop a pin where we should deliver.' : 'Delivering somewhere else? Drag the pin or tap the map to move it.'}${d != null ? ` <a href="https://www.google.com/maps?q=${st.co.geo.lat},${st.co.geo.lng}" target="_blank" rel="noopener">Check in Google Maps</a>` : ''}</p></div>`;
  }
  function payInfo() {
    const p = D.payments.find((x) => x.id === st.co.pay);
    if (!p || p.type === 'cod' || !(p.account_number || p.qr_image)) return '';
    return `<div class="pay" style="margin-top:12px"><h4>Send your payment to</h4>${p.qr_image ? `<img class="pay-qr" src="${esc(p.qr_image)}" alt="Payment QR code">` : ''}
      ${p.account_name ? `<div class="kv"><span>Account name</span><b>${esc(p.account_name)}</b></div>` : ''}
      ${p.account_number ? `<div class="kv"><span>${p.type === 'ewallet' ? esc(p.name) + ' number' : 'Account number'}</span><b>${esc(p.account_number)}<button type="button" class="copy" data-act="copy" data-text="${esc(p.account_number)}">Copy</button></b></div>` : ''}
      <div class="kv"><span>Amount to pay</span><b>${money(totals().total)}</b></div><p class="note" style="margin-top:8px">Place your order first, then enter your reference number on the next screen.</p></div>`;
  }
  function totals() {
    const o = D.site.order, sub = subtotal();
    const fee = st.co.fulfillment === 'delivery' ? DL.fee(o, sub, dist()) : 0;
    let redeem = 0;
    if (st.co.useLoy && st.co.loy) redeem = Math.min(st.co.loy.points, Math.floor(sub / D.loyalty.pointValue));
    if (redeem < D.loyalty.minRedeem) redeem = 0;
    const discount = Math.round(redeem * D.loyalty.pointValue * 100) / 100;
    return { sub, fee, redeem, discount, total: Math.round((sub + fee - discount) * 100) / 100 };
  }
  function sumHtml() {
    const t = totals(), o = D.site.order;
    return `<div><span>Subtotal</span><span>${money(t.sub)}</span></div>${st.co.fulfillment === 'delivery' ? `<div><span>Delivery</span><span>${DL.active(o) && dist() == null ? 'Share your location' : t.fee ? money(t.fee) : 'Free'}</span></div>` : ''}
      ${t.discount ? `<div class="neg"><span>Points (${t.redeem})</span><span>−${money(t.discount)}</span></div>` : ''}<div class="tot"><span>Total</span><span>${money(t.total)}</span></div>
      ${st.co.fulfillment === 'delivery' && t.fee && o.freeDeliveryMin > 0 ? `<p class="note">Add ${money(o.freeDeliveryMin - t.sub)} more for free delivery.</p>` : ''}`;
  }
  function cartView() {
    const lines = cartLines();
    return `<div class="scrim" data-act="close-bg"><aside class="drawer" role="dialog" aria-label="Cart"><div class="o-head"><h3>Your cart</h3><button class="x" data-act="close" aria-label="Close">✕</button></div>
      <div class="o-body">${lines.length ? lines.map(({ p, qty }) => `<div class="line"><div class="thumb">${thumb(p)}</div><div class="info"><b>${esc(p.name)}</b><span class="unit">${money(p.price)} · ${esc(p.unit || '')}</span>
        <div style="margin-top:8px"><div class="stepper"><button data-act="dec" data-id="${p.id}" aria-label="Remove one">−</button><span>${qty}</span><button data-act="inc" data-id="${p.id}" aria-label="Add one">+</button></div></div></div><div class="amt">${money(p.price * qty)}</div></div>`).join('')
        : '<div class="empty"><div style="font-size:3rem">🛒</div><p style="margin-top:10px">Your cart is empty.</p></div>'}</div>
      ${lines.length ? `<div class="o-foot"><div class="sum" style="margin-bottom:14px"><div class="tot" style="border:0;padding:0"><span>Subtotal</span><span>${money(subtotal())}</span></div></div>
        ${D.site.order.minOrder > subtotal() ? `<p class="note" style="margin-bottom:10px">Minimum order is ${money(D.site.order.minOrder)}.</p>` : ''}
        <button class="btn lg block" data-act="checkout" ${!D.site.order.accepting || D.site.order.minOrder > subtotal() ? 'disabled' : ''}>${D.site.order.accepting ? 'Check out' : 'Ordering is closed'}</button></div>` : ''}</aside></div>`;
  }
  function checkoutView() {
    const c = st.co, o = D.site.order, L = D.loyalty;
    if (!o.delivery && c.fulfillment === 'delivery') c.fulfillment = 'pickup';
    if (!o.pickup && c.fulfillment === 'pickup') c.fulfillment = 'delivery';
    if (!D.payments.some((p) => p.id === c.pay)) c.pay = D.payments[0] ? D.payments[0].id : 0;
    const fulf = [];
    if (o.delivery) fulf.push(`<label class="opt"><input type="radio" name="fulfillment" value="delivery" ${c.fulfillment === 'delivery' ? 'checked' : ''}><span><b>Delivery</b><small>${DL.active(o) ? `Free within ${o.freeKm} km${o.freeKmMin > 0 ? ` on ${money(o.freeKmMin)}+` : ''}` : (o.deliveryFee ? money(o.deliveryFee) : 'Free') + (o.freeDeliveryMin > 0 && o.deliveryFee ? ` · free over ${money(o.freeDeliveryMin)}` : '')}</small></span></label>`);
    if (o.pickup) fulf.push(`<label class="opt"><input type="radio" name="fulfillment" value="pickup" ${c.fulfillment === 'pickup' ? 'checked' : ''}><span><b>Store pickup</b><small>Free</small></span></label>`);
    const sub = { cod: 'Pay in cash', ewallet: 'Scan QR or send to number', bank: 'Transfer to account number' };
    let loy = '';
    if (L.enabled) {
      const usable = c.loy ? Math.min(c.loy.points, Math.floor(subtotal() / L.pointValue)) : 0;
      loy = `<h4 class="grp">Loyalty card <span class="note" style="font-weight:400">(optional)</span></h4><div class="inline-form" style="margin-top:0"><input name="cardNo" inputmode="numeric" placeholder="Card number" value="${esc(c.cardNo || '')}"><button type="button" class="btn soft" data-act="co-loy">Check points</button></div>
        ${c.loyErr ? `<p class="note" style="color:var(--danger);margin-top:8px">${esc(c.loyErr)}</p>` : ''}
        ${c.loy ? (usable >= L.minRedeem ? `<label class="opt" style="margin-top:10px"><input type="checkbox" name="useLoy" ${c.useLoy ? 'checked' : ''}><span><b>Use ${usable.toLocaleString()} points</b><small>Save ${money(usable * L.pointValue)} on this order</small></span></label>`
          : `<p class="note" style="margin-top:8px">You have ${c.loy.points} points. You need at least ${L.minRedeem} to redeem.</p>`) : '<p class="note" style="margin-top:8px">New here? Your card is created automatically with this order.</p>'}`;
    }
    return `<div class="scrim s-sheet" data-act="close-bg"><form class="sheet" data-form="checkout" role="dialog" aria-label="Checkout" novalidate><div class="o-head"><h3>Checkout</h3><button type="button" class="x" data-act="close" aria-label="Close">✕</button></div>
      <div class="o-body"><h4 class="grp">Your details</h4><div class="row2"><div class="field"><label>Full name</label><input name="name" autocomplete="name" maxlength="80" value="${esc(c.name || '')}"></div>
        <div class="field"><label>Mobile number</label><input name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="09XX XXX XXXX" maxlength="20" value="${esc(c.phone || '')}"></div></div>
        <h4 class="grp">How would you like to get it?</h4><div class="opts ${fulf.length > 1 ? 'two' : ''}">${fulf.join('')}</div>
        ${c.fulfillment === 'delivery' ? `<div class="field"><label>Delivery address</label><textarea name="address" autocomplete="street-address" maxlength="300" placeholder="House no., street, barangay, landmark">${esc(c.address || '')}</textarea>${o.deliveryNote ? `<span class="note">${esc(o.deliveryNote)}</span>` : ''}</div>${geoHtml()}` : ''}
        <div class="field"><label>Notes for the store (optional)</label><input name="notes" maxlength="500" value="${esc(c.notes || '')}"></div>
        ${loy}
        <h4 class="grp">Payment method</h4><div class="opts">${D.payments.map((p) => `<label class="opt"><input type="radio" name="pay" value="${p.id}" ${c.pay === p.id ? 'checked' : ''}><span><b>${esc(p.name)}</b><small>${sub[p.type] || ''}</small></span></label>`).join('') || '<p class="err">No payment methods are available right now.</p>'}</div>${payInfo()}
        <h4 class="grp">Order summary</h4>${cartLines().map(({ p, qty }) => `<div class="kv"><span>${qty} × ${esc(p.name)}</span><b>${money(p.price * qty)}</b></div>`).join('')}
        <div class="sum" id="co-sum" style="margin-top:12px">${sumHtml()}</div><p class="note" style="margin-top:12px">${esc(D.site.text.checkoutNote || '')}</p></div>
      <div class="o-foot">${st.err ? `<div class="err">${esc(st.err)}</div>` : ''}<button class="btn lg block" ${st.busy ? 'disabled' : ''}>${st.busy ? '<span class="spin"></span>' : `Place order · ${money(totals().total)}`}</button></div></form></div>`;
  }
  function doneView() {
    const o = st.order;
    return `<div class="scrim s-sheet"><div class="sheet" role="dialog" aria-label="Order received"><div class="o-body"><div class="done"><div class="tick">✓</div><h3 style="font-size:1.6rem">${esc(D.site.text.thankYou)}</h3>
      <p class="muted" style="margin-top:8px">Save your tracking code to follow your order.</p><div class="code-box"><b>${esc(o.code)}</b><button class="copy" data-act="copy" data-text="${esc(o.code)}">Copy</button></div>
      <p class="note">Total: <b>${money(o.total)}</b> · ${esc(o.paymentName)}</p>
      ${st.newCard ? `<p class="note" style="margin-top:10px">Your loyalty card number: <b>${esc(st.newCard.replace(/(\d{4})(?=\d)/g, '$1 '))}</b><button class="copy" data-act="copy" data-text="${esc(st.newCard)}">Copy</button></p>` : ''}</div>
      <div id="done-pay">${payPanel(o)}</div></div>
      <div class="o-foot" style="display:grid;gap:10px"><button class="btn lg block" data-act="done-track">Track my order</button><button class="btn soft block" data-act="close">Continue shopping</button></div></div></div>`;
  }
  function productView() {
    const p = prod(st.viewId); if (!p) return '';
    const cat = D.categories.find((c) => c.id === p.category_id);
    return `<div class="scrim s-sheet" data-act="close-bg"><div class="sheet" role="dialog" aria-label="${esc(p.name)}"><div class="o-head"><h3>${esc(cat ? cat.name : 'Product')}</h3><button class="x" data-act="close" aria-label="Close">✕</button></div>
      <div class="o-body"><div class="card-img" style="border-radius:var(--radius);overflow:hidden;cursor:default;max-height:340px">${thumb(p)}</div>
      <h3 style="font-size:1.6rem;margin-top:20px">${esc(p.name)}</h3><p class="unit" style="margin-top:4px">${esc(p.unit || '')}${D.site.cards.showStock && p.stock != null ? ` · ${p.stock > 0 ? p.stock + ' in stock' : 'Sold out'}` : ''}</p>
      ${p.description ? `<p style="margin-top:14px" class="muted">${nl(p.description)}</p>` : ''}</div>
      <div class="o-foot" style="display:flex;justify-content:space-between;align-items:center;gap:12px"><span class="price" style="font-size:1.4rem">${money(p.price)}${p.compare_price > p.price ? `<s>${money(p.compare_price)}</s>` : ''}</span><span data-ctl="${p.id}">${control(p)}</span></div></div></div>`;
  }
  // first visit: ask whether the visitor is a customer or the store's admin
  function welcomeView() {
    const b = D.site.brand;
    return `<div class="scrim welcome"><div class="sheet" role="dialog" aria-label="Welcome"><div class="o-body" style="text-align:center;padding:34px 24px 28px">
      <img src="${esc(b.logo || '/assets/logo.jpg')}" alt="" style="width:84px;height:84px;border-radius:20px;object-fit:cover;margin:0 auto 16px;display:block">
      <h3 style="font-size:1.4rem">Welcome to ${esc(b.short || b.name || 'our store')}</h3><p class="note" style="margin:8px 0 22px;display:block">How would you like to continue?</p>
      <button class="btn lg block" data-act="role-customer">🛒 I’m a customer — start shopping</button>
      <a class="btn soft lg block" style="margin-top:12px" href="/admin" rel="nofollow">🔒 I’m the admin — sign in</a></div></div></div>`;
  }
  function renderOverlay() {
    const views = { cart: cartView, checkout: checkoutView, done: doneView, product: productView, welcome: welcomeView };
    const body = $('.o-body'), top = body ? body.scrollTop : 0, same = $('#overlay').dataset.v === st.overlay;
    $('#overlay').innerHTML = st.overlay ? views[st.overlay]() : '';
    $('#overlay').dataset.v = st.overlay || '';
    document.body.classList.toggle('lock', !!st.overlay);
    if (same && $('.o-body')) $('.o-body').scrollTop = top;
    mountMap();
  }
  // delivery map: store, free-delivery circle and a movable pin for the drop-off point
  let coMap = null;
  function mountMap() {
    if (coMap) { st.co.zoom = coMap.getZoom(); coMap.remove(); coMap = null; }
    const el = $('#co-map'), L = window.L, o = D.site.order;
    if (!el || !L || !DL.active(o)) return;
    L.Icon.Default.imagePath = '/vendor/leaflet/images/';
    const shop = [Number(o.storeLat), Number(o.storeLng)], g = st.co.geo, at = g ? [g.lat, g.lng] : shop;
    coMap = L.map(el, { scrollWheelZoom: false }).setView(at, st.co.zoom || 15);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap' }).addTo(coMap);
    if (o.freeKm > 0) L.circle(shop, { radius: o.freeKm * 1000, color: '#1e8e3e', weight: 1, fillOpacity: 0.08, interactive: false }).addTo(coMap);
    L.circleMarker(shop, { radius: 8, color: '#fff', weight: 2, fillColor: '#0b1a4a', fillOpacity: 1, interactive: false }).addTo(coMap).bindTooltip(D.site.brand.short || 'Store', { permanent: true, direction: 'top', offset: [0, -8] });
    const move = (ll) => { const f = $('[data-form="checkout"]'); if (f) readCheckout(f); st.co.geo = { lat: ll.lat, lng: ll.lng }; st.co.geoErr = ''; renderOverlay(); };
    if (g) { const pin = L.marker(at, { draggable: true }).addTo(coMap); pin.on('dragend', () => move(pin.getLatLng())); }
    coMap.on('click', (e) => move(e.latlng));
  }
  function readCheckout(form) {
    const f = new FormData(form);
    for (const k of ['name', 'phone', 'address', 'notes', 'cardNo']) if (f.has(k)) st.co[k] = String(f.get(k));
    if (f.has('fulfillment')) st.co.fulfillment = f.get('fulfillment');
    if (f.has('pay')) st.co.pay = Number(f.get('pay'));
    st.co.useLoy = f.has('useLoy');
  }
  function fileToDataUrl(file) {
    return new Promise((res, rej) => {
      const im = new Image(), url = URL.createObjectURL(file);
      im.onload = () => { const k = Math.min(1, 1600 / Math.max(im.width, im.height)); const c = document.createElement('canvas'); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(url); res(c.toDataURL('image/jpeg', 0.85)); };
      im.onerror = () => rej(new Error('That file is not an image we can read.'));
      im.src = url;
    });
  }

  /* ---------------- events ---------------- */
  const acts = {
    add: (el) => setQty(el.dataset.id, 1),
    inc: (el) => setQty(el.dataset.id, (cart[el.dataset.id] || 0) + 1),
    dec: (el) => setQty(el.dataset.id, (cart[el.dataset.id] || 0) - 1),
    'role-customer': () => { store.set('ckj_role', 'customer'); close(); },
    cart: () => open('cart'),
    view: (el) => { st.viewId = Number(el.dataset.id); open('product'); },
    close,
    'close-bg': (el, e) => { if (e.target === el) close(); },
    checkout: () => open('checkout'),
    cat: (el) => { st.cat = Number(el.dataset.id); const g = $('#grid'), c = $('#chips'); if (g) g.innerHTML = gridHtml(); if (c) c.innerHTML = chipsHtml(); if (el.dataset.jump && $('#shop')) $('#shop').scrollIntoView({ behavior: 'smooth' }); },
    copy: (el) => { const t = el.dataset.text; (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => toast('Copied'), () => toast(t)); },
    track: (el) => { const i = $('[data-form="track"] input'); if (i) i.value = el.dataset.code; track(el.dataset.code); },
    'done-track': () => { const code = st.order.code; close(); track(code, true); },
    'msg-new': () => { st.msg = null; $('#contact-panel').innerHTML = contactHtml(); },
    'co-geo': (el) => {
      const form = el.closest('form'); readCheckout(form);
      const fail = (m) => { st.co.geoBusy = false; st.co.geoErr = m; renderOverlay(); };
      if (!navigator.geolocation) return fail('Your browser cannot share your location.');
      st.co.geoBusy = true; st.co.geoErr = ''; renderOverlay();
      navigator.geolocation.getCurrentPosition((pos) => { const f = $('[data-form="checkout"]'); if (f) readCheckout(f); st.co.geoBusy = false; st.co.geo = { lat: pos.coords.latitude, lng: pos.coords.longitude }; renderOverlay(); },
        (e) => fail(e.code === 1 ? 'Location access was blocked. Allow it in your browser settings and try again.' : 'We could not find your location. Please try again.'), { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 });
    },
    'co-loy': async (el) => {
      const form = el.closest('form'); readCheckout(form);
      try { st.co.loy = await api('POST', '/loyalty/check', { cardNo: st.co.cardNo }); st.co.loyErr = ''; }
      catch (e) { st.co.loy = null; st.co.useLoy = false; st.co.loyErr = e.message; }
      renderOverlay();
    }
  };
  document.addEventListener('click', (e) => { const el = e.target.closest('[data-act]'); if (el && acts[el.dataset.act]) acts[el.dataset.act](el, e); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && st.overlay && st.overlay !== 'done') close(); });
  document.addEventListener('input', (e) => {
    if (e.target.id === 'search') { st.q = e.target.value; $('#grid').innerHTML = gridHtml(); }
    const f = e.target.closest('[data-form="checkout"]');
    if (f && e.target.type !== 'radio' && e.target.type !== 'checkbox') readCheckout(f);
  });
  document.addEventListener('change', (e) => { const f = e.target.closest('[data-form="checkout"]'); if (f && (e.target.type === 'radio' || e.target.type === 'checkbox')) { readCheckout(f); renderOverlay(); } });

  const forms = {
    async checkout(form) {
      readCheckout(form);
      const c = st.co, t = totals();
      st.busy = true; st.err = ''; renderOverlay();
      try {
        let src = ''; try { src = sessionStorage.getItem('ckj_src') || ''; } catch { /* ignore */ }
        const r = await api('POST', '/orders', { name: c.name, phone: c.phone, address: c.address, fulfillment: c.fulfillment, notes: c.notes, lat: c.geo ? c.geo.lat : null, lng: c.geo ? c.geo.lng : null, paymentMethodId: c.pay, cardNo: c.cardNo, redeemPoints: t.redeem, src, items: cartLines().map((l) => ({ id: l.p.id, qty: l.qty })) });
        st.order = r.order; st.newCard = r.loyaltyCard;
        store.set('ckj_orders', [r.order.code].concat(store.get('ckj_orders', []).filter((x) => x !== r.order.code)).slice(0, 8));
        store.set('ckj_info', { name: c.name, phone: c.phone, address: c.address, cardNo: c.cardNo || r.loyaltyCard || '', fulfillment: c.fulfillment });
        if (!c.cardNo && r.loyaltyCard) c.cardNo = r.loyaltyCard;
        cart = {}; c.notes = ''; c.useLoy = false; c.loy = null; st.busy = false;
        refreshCart(); st.overlay = 'done'; renderOverlay();
        const rc = $('#recent'); if (rc) rc.innerHTML = recentHtml();
        load(true);
      } catch (e) { st.busy = false; st.err = e.message; renderOverlay(); load(true); }
    },
    async pay(form) {
      const btn = form.querySelector('button'), err = form.querySelector('[data-err]'), file = form.proof.files[0];
      btn.disabled = true; err.innerHTML = '';
      try {
        const r = await api('POST', `/orders/${encodeURIComponent(form.dataset.code)}/payment`, { reference: form.reference.value, proof: file ? await fileToDataUrl(file) : undefined });
        toast('Payment details sent. Thank you!');
        if (st.order && st.order.code === r.order.code) st.order = r.order;
        if (st.tracked && st.tracked.code === r.order.code) st.tracked = r.order;
        const dp = $('#done-pay'); if (dp) dp.innerHTML = payPanel(r.order);
        const out = $('#track-out'); if (out) out.innerHTML = trackHtml();
      } catch (e) { err.innerHTML = `<div class="err">${esc(e.message)}</div>`; btn.disabled = false; }
    },
    track(form) { track(form.code.value); },
    async loyalty(form) {
      try { st.loy = await api('POST', '/loyalty/check', { cardNo: form.cardNo.value }); render(); $('#rewards').scrollIntoView(); }
      catch (e) { $('#loy-out').innerHTML = `<div class="err">${esc(e.message)}</div>`; }
    },
    async contact(form) {
      const btn = form.querySelector('button'), err = form.querySelector('[data-err]'); btn.disabled = true;
      try { const r = await api('POST', '/messages', { name: form.name.value, contact: form.contact.value, orderCode: form.orderCode.value, message: form.message.value }); st.msg = { ticket: r.ticket }; $('#contact-panel').innerHTML = contactHtml(); }
      catch (e) { err.innerHTML = `<div class="err">${esc(e.message)}</div>`; btn.disabled = false; }
    },
    async reply(form) {
      try { st.msg = { view: (await api('GET', '/messages/' + encodeURIComponent(form.ticket.value.trim()))).message }; }
      catch (e) { st.msg = { err: e.message }; }
      $('#contact-panel').innerHTML = contactHtml();
    }
  };
  document.addEventListener('submit', (e) => { const f = e.target.closest('[data-form]'); if (f && forms[f.dataset.form]) { e.preventDefault(); forms[f.dataset.form](f); } });

  /* ---------------- live preview from Admin → Design ---------------- */
  window.addEventListener('message', (e) => {
    if (e.origin !== location.origin || !e.data || e.data.type !== 'ckj-preview' || !D) return;
    D.site = e.data.site; if (e.data.loyalty) Object.assign(D.loyalty, e.data.loyalty);
    window.CKJTheme.apply(D.site.theme); render();
    if (e.data.focus && $(e.data.focus)) $(e.data.focus).scrollIntoView({ block: 'start' });
  });

  /* ---------------- boot ---------------- */
  async function load(silent) {
    try {
      D = await api('GET', '/store');
      for (const id of Object.keys(cart)) { const p = prod(id); if (!p || (p.stock != null && p.stock <= 0)) delete cart[id]; else if (p.stock != null && cart[id] > p.stock) cart[id] = p.stock; }
      if (silent) { const g = $('#grid'), gf = $('#grid-f'); if (g) g.innerHTML = gridHtml(); if (gf) gf.innerHTML = D.products.filter((p) => p.featured).map(card).join(''); return; }
      render(); store.set('ckj_cart', cart);
      if (!PREVIEW && !params.get('track') && !store.get('ckj_role')) open('welcome');
      const code = params.get('track');
      if (code) { const i = $('[data-form="track"] input'); if (i) i.value = code.toUpperCase(); track(code, true); }
      if (PREVIEW && window.parent !== window) window.parent.postMessage({ type: 'ckj-preview-ready' }, location.origin);
    } catch (e) { if (!silent) $('#app').innerHTML = `<div class="boot"><div class="center"><p>We couldn’t load the store. Please check your connection.</p><p style="margin-top:14px"><a class="btn" href="/">Try again</a></p></div></div>`; }
  }
  $('#app').innerHTML = '<div class="boot"><span class="spin"></span></div>';
  load();
})();
