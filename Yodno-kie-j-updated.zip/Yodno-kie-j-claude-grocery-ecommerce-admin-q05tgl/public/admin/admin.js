(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const A = (window.ADM = { $, esc, views: {}, acts: {}, forms: {}, changes: {}, site: null, csrf: '', current: '' });
  const { views, acts, forms, changes } = A;

  /* ---------------- core helpers ---------------- */
  async function api(method, url, body) {
    const r = await fetch('/api/admin' + url, { method, headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': A.csrf }, body: body === undefined ? undefined : JSON.stringify(body), credentials: 'same-origin' });
    const j = await r.json().catch(() => ({}));
    if (r.status === 401 && !url.startsWith('/login')) { showLogin(A.csrf ? 'Your session has ended. Please sign in again.' : ''); A.csrf = ''; throw new Error('Signed out'); }
    if (!r.ok) { const e = new Error(j.error || 'Something went wrong.'); e.data = j; e.status = r.status; throw e; }
    return j;
  }
  let toastT;
  function toast(msg, bad) { const t = $('#toast'); t.textContent = msg; t.className = 'show' + (bad ? ' bad' : ''); clearTimeout(toastT); toastT = setTimeout(() => (t.className = ''), 2800); }
  const cur = () => (A.site && A.site.brand.currency) || '₱';
  const money = (n) => cur() + Number(n || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const dt = (iso) => (iso ? new Date(iso).toLocaleString([], { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }) : '—');
  const day = (iso) => (iso ? new Date(iso).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }) : '—');
  const cardFmt = (n) => String(n || '').replace(/(\d{4})(?=\d)/g, '$1 ');
  const LBL = { pending: 'Pending', confirmed: 'Confirmed', preparing: 'Preparing', out_for_delivery: 'Out for delivery', completed: 'Completed', cancelled: 'Cancelled', unpaid: 'Unpaid', submitted: 'To verify', paid: 'Paid', refunded: 'Refunded', new: 'New', read: 'Read', replied: 'Replied', closed: 'Closed', delivery: 'Delivery', pickup: 'Pickup' };
  const pill = (s, o) => `<span class="pill ${esc(s)}">${esc(s === 'out_for_delivery' && o && o.fulfillment === 'pickup' ? 'Ready for pickup' : LBL[s] || s)}</span>`;
  const qrUrl = (text, extra = '') => `/api/admin/qr?text=${encodeURIComponent(text)}${extra}`;
  const thumb = (p) => `<span class="thumb">${p.image ? `<img src="${esc(p.image)}" alt="">` : esc(p.emoji || '🛒')}</span>`;
  // map of where a delivery order goes: the customer's pin when they set one, otherwise a Google search of the typed address
  function deliveryMap(o) {
    if (o.fulfillment === 'pickup' || o.status === 'cancelled') return '';
    const so = (A.site && A.site.order) || {}, hasPin = o.lat != null && o.lng != null;
    const town = (A.site && A.site.contact && A.site.contact.address) || '';
    const dest = hasPin ? `${Number(o.lat)},${Number(o.lng)}` : [o.address, town].filter(Boolean).join(', ');
    if (!dest) return '';
    const q = encodeURIComponent(dest), origin = Number(so.storeLat) || Number(so.storeLng) ? `&origin=${Number(so.storeLat)},${Number(so.storeLng)}` : '';
    return `${o.distance_km != null ? `<div class="kv"><span>Distance</span><b>${o.distance_km} km from store</b></div>` : ''}
      <iframe class="gmap" loading="lazy" referrerpolicy="no-referrer" title="Delivery location" src="https://www.google.com/maps?q=${q}&z=16&output=embed"></iframe>
      <div class="acts" style="margin-bottom:6px"><a class="btn sm" href="https://www.google.com/maps/dir/?api=1${origin}&destination=${q}" target="_blank" rel="noopener">Get directions</a><a class="btn soft sm" href="https://www.google.com/maps?q=${q}" target="_blank" rel="noopener">Open in Google Maps</a></div>
      <p class="small muted" style="margin-bottom:8px">${hasPin ? 'Pin placed by the customer on the map at checkout.' : 'Found from the address the customer typed, so it may be approximate. Call the customer if it looks wrong.'}</p>`;
  }
  function table(heads, rows, empty = 'Nothing here yet.') {
    if (!rows.length) return `<div class="empty">${esc(empty)}</div>`;
    // label every cell with its column heading so phones can show each row as a card
    const labels = heads.map((h) => h.replace(/^>/, ''));
    const main = labels.findIndex((l) => l);
    const t = document.createElement('template');
    t.innerHTML = `<table><tbody>${rows.join('')}</tbody></table>`;
    t.content.querySelectorAll('tr').forEach((tr) => [...tr.children].forEach((td, i) => {
      td.dataset.label = labels[i] || '';
      td.classList.add(i === main ? 'm-main' : labels[i] ? 'm-f' : i < main ? 'm-lead' : 'm-act');
    }));
    return `<div class="tbl-wrap"><table><thead><tr>${heads.map((h) => `<th class="${h.startsWith('>') ? 'right' : ''}">${esc(h.replace(/^>/, ''))}</th>`).join('')}</tr></thead>${t.content.querySelector('tbody').outerHTML}</table></div>`;
  }
  function bars(data, key = 'revenue') {
    const max = Math.max(1, ...data.map((d) => d[key]));
    return `<div class="bars">${data.map((d) => `<div class="b" title="${esc(d.day)} — ${money(d.revenue)} · ${d.orders} order(s)"><i style="height:${Math.round((d[key] / max) * 100)}%"></i><small>${esc(d.day.slice(5).replace('-', '/'))}</small></div>`).join('')}</div>`;
  }
  function hbars(rows, fmt = money, key = 'revenue') {
    const max = Math.max(1, ...rows.map((r) => r[key]));
    return rows.length ? rows.map((r) => `<div class="hbar"><span>${esc(r.name)}</span><div class="t"><i style="width:${Math.max(2, Math.round((r[key] / max) * 100))}%"></i></div><b>${fmt(r[key])}</b></div>`).join('') : '<div class="empty">No data for this period.</div>';
  }
  function field(label, name, value = '', o = {}) {
    const attrs = `name="${name}" ${o.req ? 'required' : ''} ${o.ph ? `placeholder="${esc(o.ph)}"` : ''} ${o.attrs || ''}`;
    let inp;
    if (o.type === 'textarea') inp = `<textarea ${attrs}>${esc(value)}</textarea>`;
    else if (o.type === 'select') inp = `<select ${attrs}>${o.options.map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(value) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
    else inp = `<input type="${o.type || 'text'}" value="${esc(value)}" ${attrs}>`;
    return `<div class="f"><label>${esc(label)}</label>${inp}${o.help ? `<small>${esc(o.help)}</small>` : ''}</div>`;
  }
  const toggle = (label, name, on) => `<label class="sw"><span>${esc(label)}</span><input type="checkbox" name="${name}" ${on ? 'checked' : ''}></label>`;
  const imgField = (label, name, value) => `<div class="f"><label>${esc(label)}</label><div class="imgf" data-imgf><div class="pv">${value ? `<img src="${esc(value)}" alt="">` : 'No image'}</div><input type="hidden" name="${name}" value="${esc(value || '')}">
    <button type="button" class="btn soft sm" data-act="img-pick">Upload</button><button type="button" class="btn soft sm" data-act="img-clear">Remove</button><input type="file" accept="image/png,image/jpeg,image/webp,image/gif" hidden></div></div>`;
  Object.assign(A, { api, toast, money, dt, day, pill, table, field, toggle, imgField, qrUrl, cardFmt });

  // image upload (resized in the browser first)
  function fileToDataUrl(file, max = 1600) {
    return new Promise((res, rej) => {
      if (file.type === 'image/gif') { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = rej; return fr.readAsDataURL(file); }
      const im = new Image(), url = URL.createObjectURL(file);
      im.onload = () => { const k = Math.min(1, max / Math.max(im.width, im.height)); const c = document.createElement('canvas'); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(url); res(file.type === 'image/png' ? c.toDataURL('image/png') : c.toDataURL('image/jpeg', 0.88)); };
      im.onerror = () => rej(new Error('That file is not a readable image.'));
      im.src = url;
    });
  }
  acts['img-pick'] = (el) => el.parentNode.querySelector('input[type=file]').click();
  function setImg(box, url) { box.querySelector('.pv').innerHTML = url ? `<img src="${esc(url)}" alt="">` : 'No image'; const h = box.querySelector('input[type=hidden]'); h.value = url; h.dispatchEvent(new Event('input', { bubbles: true })); }
  acts['img-clear'] = (el) => setImg(el.parentNode, '');
  document.addEventListener('change', async (e) => {
    const box = e.target.type === 'file' && e.target.closest('[data-imgf]');
    if (box && e.target.files[0]) {
      try { toast('Uploading…'); const { url } = await api('POST', '/upload', { dataUrl: await fileToDataUrl(e.target.files[0]) }); setImg(box, url); toast('Image uploaded'); }
      catch (err) { toast(err.message, true); }
      e.target.value = '';
      return;
    }
    const c = e.target.closest('[data-change]'); if (c && changes[c.dataset.change]) changes[c.dataset.change](c, e);
  });
  document.addEventListener('click', (e) => { const el = e.target.closest('[data-act]'); if (el && acts[el.dataset.act]) { acts[el.dataset.act](el, e); } });
  document.addEventListener('submit', async (e) => {
    const f = e.target.closest('[data-form]'); if (!f || !forms[f.dataset.form]) return;
    e.preventDefault();
    const btn = f.querySelector('button:not([type=button])'); if (btn) btn.disabled = true;
    try { await forms[f.dataset.form](f, new FormData(f)); } catch (err) { if (err.message !== 'Signed out') { const box = f.querySelector('[data-err]') || $('#m-err'); if (box && f.contains(box)) box.innerHTML = `<div class="msg-err">${esc(err.message)}</div>`; else toast(err.message, true); } }
    if (btn && document.contains(btn)) btn.disabled = false;
  });
  function printHtml(html) { $('#print').innerHTML = html; document.body.classList.add('printing'); setTimeout(() => { window.print(); document.body.classList.remove('printing'); }, 350); }
  A.printHtml = printHtml;

  /* ---------------- modal ---------------- */
  let modalSave = null;
  function modal(title, body, o = {}) {
    modalSave = o.onSave || null;
    $('#modal').innerHTML = `<div class="scrim" data-act="m-bg"><form class="mod ${o.wide ? 'wide' : ''}" data-form="modal" novalidate><header><h3>${esc(title)}</h3><button type="button" class="x" data-act="m-close" aria-label="Close">✕</button></header>
      <div class="mod-body">${body}</div><div class="mod-err" data-err></div>${o.onSave ? `<footer><button type="button" class="btn soft" data-act="m-close">Cancel</button><button class="btn">${esc(o.saveLabel || 'Save')}</button></footer>` : ''}</form></div>`;
  }
  const closeModal = () => { $('#modal').innerHTML = ''; modalSave = null; };
  acts['m-close'] = closeModal;
  acts['m-bg'] = (el, e) => { if (e.target === el) closeModal(); };
  forms.modal = async (f, fd) => { if (!modalSave) return; const r = await modalSave(fd, f); if (r !== false) { closeModal(); refresh(); } };
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && $('#modal').innerHTML) closeModal(); });
  Object.assign(A, { modal, closeModal });

  /* ---------------- auth screens ---------------- */
  const authWrap = (inner) => `<div class="auth"><div class="auth-card"><img src="${esc((A.site && A.site.brand.logo) || '/assets/logo.jpg')}" alt="">${inner}<p class="small muted" style="margin-top:18px"><a href="/">← Back to store</a></p></div></div>`;
  function showLogin(note, need2fa) {
    clearInterval(A.poll); closeModal();
    $('#root').innerHTML = authWrap(`<h1>Admin sign in</h1><p class="muted small">Authorised staff only.</p><form data-form="login">
      ${note ? `<div class="msg-err">${esc(note)}</div>` : ''}<div data-err></div>
      <div class="f"><label>Username</label><input name="username" autocomplete="username" autocapitalize="none" required autofocus></div>
      <div class="f"><label>Password</label><input type="password" name="password" autocomplete="current-password" required></div>
      <div class="f" id="f-code" ${need2fa ? '' : 'hidden'}><label>6-digit authenticator code</label><input name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" pattern="[0-9]*"></div>
      <button class="btn block">Sign in</button></form>`);
  }
  forms.login = async (f, fd) => {
    try {
      const r = await api('POST', '/login', { username: fd.get('username'), password: fd.get('password'), code: fd.get('code') });
      A.csrf = r.csrf; r.mustChange ? showMustChange() : boot();
    } catch (e) { if (e.data && e.data.need2fa) { $('#f-code').hidden = false; f.code.focus(); } throw e; }
  };
  function showMustChange() {
    $('#root').innerHTML = authWrap(`<h1>Set your password</h1><p class="muted small">For security, choose your own password before continuing.</p><form data-form="firstpw"><div data-err></div>
      <div class="f"><label>Temporary password</label><input type="password" name="current" required autocomplete="current-password"></div>
      <div class="f"><label>New password</label><input type="password" name="next" required minlength="10" autocomplete="new-password"><small>At least 10 characters, with letters, numbers and an uppercase letter or symbol.</small></div>
      <div class="f"><label>Confirm new password</label><input type="password" name="again" required autocomplete="new-password"></div><button class="btn block">Save and continue</button></form>`);
  }
  async function changePw(fd) {
    if (fd.get('next') !== fd.get('again')) throw new Error('The new passwords do not match.');
    await api('POST', '/password', { current: fd.get('current'), next: fd.get('next') });
  }
  forms.firstpw = async (f, fd) => { await changePw(fd); toast('Password saved'); boot(); };
  acts.logout = async () => { try { await api('POST', '/logout'); } catch { /* ignore */ } A.csrf = ''; showLogin(); };

  /* ---------------- shell + router ---------------- */
  const NAV = [['dashboard', '📊', 'Dashboard'], ['orders', '🧾', 'Orders'], ['products', '📦', 'Products'], ['customers', '👥', 'Customers'], ['loyalty', '💳', 'Loyalty cards'], ['reports', '📈', 'Sales reports'], ['messages', '💬', 'Messages'],
    ['-', '', 'Store'], ['design', '🎨', 'Design & branding'], ['payments', '💰', 'Payment methods'], ['qr', '🔳', 'QR codes'], ['settings', '⚙️', 'Store settings'], ['security', '🔒', 'Security']];
  function shell() {
    $('#root').innerHTML = `<div class="shell"><aside class="side"><div class="side-brand"><img src="${esc(A.site.brand.logo || '/assets/logo.jpg')}" alt=""><b>${esc(A.site.brand.short || 'Admin')}</b></div>
      ${NAV.map(([k, i, l]) => (k === '-' ? `<div class="sep">${l}</div>` : `<a class="nav" href="#${k}" data-nav="${k}"><i>${i}</i>${l}<b data-badge="${k}" hidden></b></a>`)).join('')}
      <div class="grow"></div><a class="nav" href="/" target="_blank" rel="noopener"><i>🛍️</i>View store</a><a class="nav" href="#" data-act="logout"><i>↩︎</i>Sign out</a></aside>
      <main><div class="top"><h1 id="title"></h1><div class="acts" id="actions"></div></div><div id="view"></div></main></div>`;
  }
  async function go(name) {
    if (!views[name]) name = 'dashboard';
    if (A.current === 'design' && name !== 'design' && A.dirty && !confirm('You have unsaved design changes. Leave without saving?')) { location.hash = '#design'; return; }
    A.current = name; A.dirty = false;
    document.querySelectorAll('[data-nav]').forEach((a) => a.classList.toggle('on', a.dataset.nav === name));
    $('#title').textContent = (NAV.find((n) => n[0] === name) || [])[2] || '';
    $('#actions').innerHTML = ''; $('#view').innerHTML = '<div class="empty"><span class="spin"></span></div>';
    await refresh();
    window.scrollTo(0, 0);
  }
  async function refresh() {
    try { await views[A.current](); } catch (e) { if (e.message !== 'Signed out') $('#view').innerHTML = `<div class="card"><div class="msg-err">${esc(e.message)}</div></div>`; }
  }
  A.refresh = refresh;
  window.addEventListener('hashchange', () => { if ($('.shell')) go(location.hash.slice(1)); });
  async function badges() {
    try {
      const d = await api('GET', '/dashboard'); A.dash = d;
      const set = (k, n) => { const b = $(`[data-badge="${k}"]`); if (b) { b.hidden = !n; b.textContent = n; } };
      set('orders', d.pending + d.toVerify); set('messages', d.newMessages);
      document.title = (d.pending ? `(${d.pending}) ` : '') + 'Admin · ' + (A.site.brand.short || '');
      if (A.lastPending != null && d.pending > A.lastPending) { toast('🔔 New order received'); if (['orders', 'dashboard'].includes(A.current) && !$('#modal').innerHTML) refresh(); }
      A.lastPending = d.pending;
    } catch { /* ignore */ }
  }
  A.badges = badges;
  async function boot() {
    try {
      const me = await api('GET', '/me'); A.csrf = me.csrf;
      if (me.mustChange) return showMustChange();
      A.site = (await api('GET', '/settings')).site;
      shell(); await go(location.hash.slice(1) || 'dashboard');
      badges(); clearInterval(A.poll); A.poll = setInterval(badges, 30000);
    } catch (e) { if (e.message !== 'Signed out') showLogin(); }
  }

  /* ================= DASHBOARD ================= */
  views.dashboard = async () => {
    const d = await api('GET', '/dashboard'); A.dash = d;
    const ck = d.checklist, todo = [];
    if (ck.defaultPassword) todo.push(['You are still using the default password — change it before the store goes live', '#security']);
    if (!ck.payments) todo.push(['Add your GCash / bank account number or QR code so customers can pay online', '#payments']);
    if (!ck.contact) todo.push(['Add your store phone number and address', '#settings']);
    if (!ck.twoFactor) todo.push(['Turn on two-step sign-in for extra protection', '#security']);
    $('#view').innerHTML = `
      ${todo.length ? `<div class="card"><h3>Finish setting up</h3>${todo.map(([t, h]) => `<div class="check"><span>○</span><span style="flex:1">${esc(t)}</span><a class="btn soft sm" href="${h}">Set up</a></div>`).join('')}</div>` : ''}
      <div class="tiles">
        <div class="tile"><small>Sales today</small><b>${money(d.today.revenue)}</b><span>${d.today.orders} order(s)</span></div>
        <div class="tile"><small>Last 7 days</small><b>${money(d.week.revenue)}</b><span>${d.week.orders} order(s)</span></div>
        <div class="tile"><small>Last 30 days</small><b>${money(d.month.revenue)}</b><span>${d.month.orders} order(s)</span></div>
        <a class="tile ${d.pending ? 'alert' : ''}" href="#orders"><small>New orders to confirm</small><b>${d.pending}</b><span>${d.active} in progress</span></a>
        <a class="tile ${d.toVerify ? 'alert' : ''}" href="#orders"><small>Payments to verify</small><b>${d.toVerify}</b><span>Reference submitted</span></a>
        <a class="tile ${d.newMessages ? 'alert' : ''}" href="#messages"><small>New messages</small><b>${d.newMessages}</b><span>${d.customers} customers total</span></a>
      </div>
      <div class="cols"><div><div class="card"><h3>Sales — last 14 days</h3>${bars(d.days)}</div>
        <div class="card"><h3>Recent orders <a class="small" href="#orders">View all</a></h3>${table(['Order', 'Customer', '>Total', 'Status', 'Placed'], d.recent.map((o) => `<tr class="click" data-act="order" data-id="${o.id}"><td class="mono">${esc(o.code)}</td><td>${esc(o.name)}</td><td class="right">${money(o.total)}</td><td>${pill(o.status)}</td><td class="muted nowrap">${dt(o.created)}</td></tr>`), 'No orders yet. Share your store link or QR code to get started.')}</div></div>
        <div><div class="card"><h3>Top products — 30 days</h3>${hbars(d.top)}</div>
        <div class="card"><h3>Low stock <a class="small" href="#products">Manage</a></h3>${d.lowStock.length ? d.lowStock.map((p) => `<div class="kv"><span>${esc(p.name)}</span><b style="color:${p.stock ? 'var(--warn)' : 'var(--danger)'}">${p.stock ? p.stock + ' left' : 'Sold out'}</b></div>`).join('') : '<div class="empty">All products are well stocked.</div>'}</div></div></div>`;
  };

  /* ================= ORDERS ================= */
  const of = { status: '', q: '' };
  views.orders = async () => {
    const { orders, counts } = await api('GET', `/orders?status=${of.status}&q=${encodeURIComponent(of.q)}`);
    const total = Object.values(counts).reduce((a, b) => a + b, 0);
    const tabs = [['', 'All', total], ['pending', 'Pending', counts.pending], ['active', 'In progress', (counts.confirmed || 0) + (counts.preparing || 0) + (counts.out_for_delivery || 0) + (counts.pending || 0)], ['completed', 'Completed', counts.completed], ['cancelled', 'Cancelled', counts.cancelled]];
    $('#actions').innerHTML = '<a class="btn soft" href="#reports">Sales reports</a>';
    const had = document.activeElement && document.activeElement.id === 'o-q';
    $('#view').innerHTML = `<div class="tabs">${tabs.map(([k, l, n]) => `<button class="tab ${of.status === k ? 'on' : ''}" data-act="o-tab" data-k="${k}">${l}<b>${n || 0}</b></button>`).join('')}</div>
      <div class="card"><div class="bar-row"><input class="inp" id="o-q" type="search" placeholder="Search code, name or mobile" value="${esc(of.q)}" data-change="o-q"></div>
      ${table(['Order', 'Customer', 'Items', '>Total', 'Payment', 'Status', 'Placed'], orders.map((o) => `<tr class="click" data-act="order" data-id="${o.id}"><td class="mono nowrap">${esc(o.code)}</td><td>${esc(o.name)}<div class="small muted">${esc(o.phone)} · ${LBL[o.fulfillment]}</div></td><td>${o.items || 0}</td>
        <td class="right nowrap">${money(o.total)}</td><td><div class="small">${esc(o.payment_name || '')}</div>${pill(o.payment_status)}</td><td>${pill(o.status, o)}</td><td class="muted nowrap">${dt(o.created)}</td></tr>`), 'No orders match.')}</div>`;
    if (had) { const i = $('#o-q'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }
  };
  acts['o-tab'] = (el) => { of.status = el.dataset.k; refresh(); };
  changes['o-q'] = (el) => { of.q = el.value; refresh(); };
  async function orderModal(id) {
    const { order: o } = await api('GET', '/orders/' + id);
    const flow = ['pending', 'confirmed', 'preparing', 'out_for_delivery', 'completed'];
    const next = { confirmed: 'Confirm order', preparing: 'Start preparing', out_for_delivery: o.fulfillment === 'pickup' ? 'Ready for pickup' : 'Out for delivery', completed: 'Mark completed' };
    const idx = flow.indexOf(o.status);
    const btns = o.status === 'cancelled' ? '' : flow.slice(1).map((s, i) => `<button type="button" class="btn sm ${i + 1 === idx + 1 ? '' : 'soft'}" data-act="o-status" data-id="${o.id}" data-s="${s}" ${s === o.status ? 'disabled' : ''}>${next[s]}</button>`).join('') + `<button type="button" class="btn sm danger" data-act="o-status" data-id="${o.id}" data-s="cancelled">Cancel order</button>`;
    modal(`Order ${o.code}`, `
      <div class="g2"><div><h4 class="grp">Customer</h4><div class="kv"><span>Name</span><b>${esc(o.name)}</b></div><div class="kv"><span>Mobile</span><b><a href="tel:${esc(o.phone)}">${esc(o.phone)}</a></b></div>
        <div class="kv"><span>${o.fulfillment === 'pickup' ? 'Pickup' : 'Deliver to'}</span><b>${o.fulfillment === 'pickup' ? 'Store pickup' : esc(o.address)}</b></div>${deliveryMap(o)}${o.notes ? `<div class="kv"><span>Customer note</span><b>${esc(o.notes)}</b></div>` : ''}
        ${o.customer ? `<div class="kv"><span>Loyalty</span><b>${cardFmt(o.customer.card_no)} · ${o.customer.points} pts</b></div>` : ''}${o.source ? `<div class="kv"><span>Came from</span><b>QR: ${esc(o.source)}</b></div>` : ''}</div>
      <div><h4 class="grp">Payment</h4><div class="kv"><span>Method</span><b>${esc(o.payment_name || '—')}</b></div><div class="kv"><span>Status</span><b>${pill(o.payment_status)}</b></div>
        ${o.payment_ref ? `<div class="kv"><span>Reference no.</span><b class="mono">${esc(o.payment_ref)}</b></div>` : ''}${o.payment_proof ? `<div class="kv"><span>Receipt</span><b><a href="/api/admin/proof/${esc(o.payment_proof)}" target="_blank" rel="noopener">View screenshot</a></b></div>` : ''}
        <div class="acts" style="margin-top:10px">${o.payment_status !== 'paid' ? `<button type="button" class="btn sm ok" data-act="o-pay" data-id="${o.id}" data-s="paid">Mark as paid</button>` : `<button type="button" class="btn sm soft" data-act="o-pay" data-id="${o.id}" data-s="unpaid">Mark unpaid</button>`}
        ${o.payment_status === 'paid' ? `<button type="button" class="btn sm soft" data-act="o-pay" data-id="${o.id}" data-s="refunded">Refunded</button>` : ''}</div></div></div>
      <h4 class="grp">Items</h4>${table(['Item', '>Price', '>Qty', '>Amount'], o.items.map((i) => `<tr><td>${esc(i.name)} <span class="muted small">${esc(i.unit || '')}</span></td><td class="right">${money(i.price)}</td><td class="right">${i.qty}</td><td class="right">${money(i.price * i.qty)}</td></tr>`))}
      <div style="max-width:300px;margin-left:auto;margin-top:8px"><div class="kv"><span>Subtotal</span><b>${money(o.subtotal)}</b></div><div class="kv"><span>Delivery fee</span><b>${money(o.delivery_fee)}</b></div>${o.discount ? `<div class="kv"><span>Points used (${o.points_redeemed})</span><b>−${money(o.discount)}</b></div>` : ''}<div class="kv"><span>Total</span><b style="font-size:1.15rem">${money(o.total)}</b></div></div>
      <h4 class="grp">Update status — now: ${pill(o.status, o)}</h4><div class="f"><input id="o-note" class="inp" placeholder="Optional note the customer will see (e.g. rider name, ETA)" maxlength="300"></div><div class="acts">${btns || '<span class="muted small">This order was cancelled.</span>'}</div>
      <h4 class="grp">History</h4>${o.history.map((h) => `<div class="kv"><span>${dt(h.ts)}</span><b>${LBL[h.status] || esc(h.status)}${h.note ? ` — <span class="muted">${esc(h.note)}</span>` : ''}</b></div>`).join('')}
      <h4 class="grp">Private staff note</h4><div class="f"><textarea id="o-admin-note" maxlength="1000" placeholder="Only visible to staff">${esc(o.admin_note || '')}</textarea></div>
      <div class="acts"><button type="button" class="btn sm soft" data-act="o-save-note" data-id="${o.id}">Save note</button><button type="button" class="btn sm soft" data-act="o-print" data-id="${o.id}">Print receipt</button>
      ${o.status === 'cancelled' ? `<button type="button" class="btn sm danger" data-act="o-del" data-id="${o.id}">Delete order</button>` : ''}</div>`, { wide: true });
    A.openOrder = o;
  }
  acts.order = (el) => orderModal(el.dataset.id).catch((e) => toast(e.message, true));
  async function patchOrder(id, body, msg) { try { await api('PATCH', '/orders/' + id, body); toast(msg); await orderModal(id); refresh(); badges(); } catch (e) { toast(e.message, true); } }
  acts['o-status'] = (el) => {
    let note = $('#o-note').value;
    if (el.dataset.s === 'cancelled') { const r = prompt('Cancel this order? Stock and loyalty points will be restored.\n\nReason to show the customer (optional):', note); if (r === null) return; note = r; }
    patchOrder(el.dataset.id, { status: el.dataset.s, note }, 'Order updated');
  };
  acts['o-pay'] = (el) => patchOrder(el.dataset.id, { payment_status: el.dataset.s }, 'Payment updated');
  acts['o-save-note'] = (el) => patchOrder(el.dataset.id, { admin_note: $('#o-admin-note').value }, 'Note saved');
  acts['o-del'] = async (el) => { if (!confirm('Delete this cancelled order permanently?')) return; try { await api('DELETE', '/orders/' + el.dataset.id); closeModal(); refresh(); toast('Order deleted'); } catch (e) { toast(e.message, true); } };
  acts['o-print'] = () => {
    const o = A.openOrder, b = A.site.brand;
    printHtml(`<div style="max-width:380px;margin:0 auto;font:14px/1.5 var(--font)"><h2 style="text-align:center;font-size:18px">${esc(b.name)}</h2><p style="text-align:center">${esc(A.site.contact.address || '')}<br>${esc(A.site.contact.phone || '')}</p><hr>
      <p><b>Order ${esc(o.code)}</b><br>${dt(o.created)}<br>${esc(o.name)} · ${esc(o.phone)}<br>${o.fulfillment === 'pickup' ? 'Store pickup' : esc(o.address)}${o.notes ? `<br>Note: ${esc(o.notes)}` : ''}</p><hr>
      <table style="width:100%;font-size:13px">${o.items.map((i) => `<tr><td style="border:0;padding:3px 0">${i.qty} × ${esc(i.name)}</td><td style="border:0;padding:3px 0;text-align:right">${money(i.price * i.qty)}</td></tr>`).join('')}</table><hr>
      <p>Subtotal <span style="float:right">${money(o.subtotal)}</span><br>Delivery <span style="float:right">${money(o.delivery_fee)}</span>${o.discount ? `<br>Points discount <span style="float:right">−${money(o.discount)}</span>` : ''}<br><b>TOTAL <span style="float:right">${money(o.total)}</span></b></p>
      <p>Payment: ${esc(o.payment_name || '')} (${LBL[o.payment_status]})</p><hr><p style="text-align:center">Thank you for your order!</p></div>`);
  };

  /* ================= PRODUCTS ================= */
  let catalog = { products: [], categories: [] }, pf = { cat: '', q: '' };
  views.products = async () => {
    catalog = await api('GET', '/catalog');
    $('#actions').innerHTML = '<button class="btn soft" data-act="cat-new">Add category</button><button class="btn" data-act="p-edit" data-id="0">Add product</button>';
    const q = pf.q.toLowerCase(), list = catalog.products.filter((p) => (!pf.cat || String(p.category_id) === pf.cat) && (!q || p.name.toLowerCase().includes(q)));
    const cname = (id) => (catalog.categories.find((c) => c.id === id) || {}).name || '—';
    const had = document.activeElement && document.activeElement.id === 'p-q';
    $('#view').innerHTML = `<div class="card"><h3>Categories</h3><div class="tabs" style="margin:0">${catalog.categories.map((c) => `<button class="tab" data-act="cat-edit" data-id="${c.id}">${esc(c.emoji || '')} ${esc(c.name)}<b>${c.products}</b></button>`).join('') || '<span class="muted">No categories yet.</span>'}</div></div>
      <div class="card"><div class="bar-row"><input class="inp" id="p-q" type="search" placeholder="Search products" value="${esc(pf.q)}" data-change="p-q"><select class="inp" style="max-width:220px" data-change="p-cat"><option value="">All categories</option>${catalog.categories.map((c) => `<option value="${c.id}" ${pf.cat === String(c.id) ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select><span class="muted small">${list.length} product(s)</span></div>
      ${table(['', 'Product', 'Category', '>Price', '>Stock', 'Best seller', 'Visible', ''], list.map((p) => `<tr><td>${thumb(p)}</td><td><b>${esc(p.name)}</b><div class="small muted">${esc(p.unit || '')}</div></td><td>${esc(cname(p.category_id))}</td><td class="right nowrap">${money(p.price)}</td>
        <td class="right"><input class="inp right" style="width:84px;min-height:32px;padding:4px 8px" type="number" min="0" placeholder="∞" value="${p.stock == null ? '' : p.stock}" data-change="p-stock" data-id="${p.id}" aria-label="Stock"></td>
        <td><label class="sw" style="margin:0;justify-content:flex-start"><input type="checkbox" ${p.featured ? 'checked' : ''} data-change="p-flag" data-k="featured" data-id="${p.id}"></label></td><td><label class="sw" style="margin:0;justify-content:flex-start"><input type="checkbox" ${p.active ? 'checked' : ''} data-change="p-flag" data-k="active" data-id="${p.id}"></label></td>
        <td class="right nowrap"><button class="btn soft sm" data-act="p-edit" data-id="${p.id}">Edit</button></td></tr>`), 'No products yet. Add your first product.')}</div>`;
    if (had) { const i = $('#p-q'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }
  };
  changes['p-q'] = (el) => { pf.q = el.value; refresh(); };
  changes['p-cat'] = (el) => { pf.cat = el.value; refresh(); };
  changes['p-stock'] = async (el) => { try { await api('PATCH', '/products/' + el.dataset.id, { stock: el.value }); toast('Stock updated'); } catch (e) { toast(e.message, true); } };
  changes['p-flag'] = async (el) => { try { await api('PATCH', '/products/' + el.dataset.id, { [el.dataset.k]: el.checked }); toast('Saved'); } catch (e) { toast(e.message, true); } };
  acts['p-edit'] = (el) => {
    const id = Number(el.dataset.id), p = catalog.products.find((x) => x.id === id) || { active: 1, price: '', stock: '' };
    modal(id ? 'Edit product' : 'Add product', `${field('Product name', 'name', p.name, { req: true })}${field('Description', 'description', p.description, { type: 'textarea' })}
      <div class="g2">${field('Category', 'category_id', p.category_id || '', { type: 'select', options: [['', 'No category']].concat(catalog.categories.map((c) => [c.id, c.name])) })}${field('Unit / size', 'unit', p.unit, { ph: 'e.g. 25 kg sack, per kg' })}</div>
      <div class="g3">${field(`Price (${cur()})`, 'price', p.price, { type: 'number', req: true, attrs: 'step="0.01" min="0"' })}${field('Old price (optional)', 'compare_price', p.compare_price == null ? '' : p.compare_price, { type: 'number', attrs: 'step="0.01" min="0"', help: 'Shows a Sale badge' })}${field('Stock', 'stock', p.stock == null ? '' : p.stock, { type: 'number', attrs: 'min="0"', help: 'Leave blank for unlimited' })}</div>
      ${imgField('Photo', 'image', p.image)}<div class="g2">${field('Icon when there is no photo', 'emoji', p.emoji, { ph: '🌾' })}${field('Sort order', 'sort', p.sort || 0, { type: 'number' })}</div>
      ${toggle('Show in Best sellers', 'featured', p.featured)}${toggle('Visible in store', 'active', p.active)}
      ${id ? `<button type="button" class="btn danger sm" data-act="p-del" data-id="${id}">Delete product</button>` : ''}`, {
      onSave: async (fd) => { const b = Object.fromEntries(fd); b.featured = fd.has('featured'); b.active = fd.has('active'); await api(id ? 'PUT' : 'POST', '/products' + (id ? '/' + id : ''), b); toast('Product saved'); }
    });
  };
  acts['p-del'] = async (el) => { if (!confirm('Delete this product? Past orders keep their records.')) return; await api('DELETE', '/products/' + el.dataset.id); closeModal(); refresh(); toast('Product deleted'); };
  function catModal(c) {
    modal(c.id ? 'Edit category' : 'Add category', `<div class="g2">${field('Name', 'name', c.name, { req: true })}${field('Icon', 'emoji', c.emoji, { ph: '🌾' })}</div>${field('Sort order', 'sort', c.sort || 0, { type: 'number' })}
      ${c.id ? `<button type="button" class="btn danger sm" data-act="cat-del" data-id="${c.id}">Delete category</button>` : ''}`, { onSave: async (fd) => { await api(c.id ? 'PUT' : 'POST', '/categories' + (c.id ? '/' + c.id : ''), Object.fromEntries(fd)); toast('Category saved'); } });
  }
  acts['cat-new'] = () => catModal({});
  acts['cat-edit'] = (el) => catModal(catalog.categories.find((c) => c.id === Number(el.dataset.id)));
  acts['cat-del'] = async (el) => { if (!confirm('Delete this category? Its products will become uncategorised.')) return; await api('DELETE', '/categories/' + el.dataset.id); closeModal(); refresh(); };

  /* ================= CUSTOMERS ================= */
  let cq = '';
  views.customers = async () => {
    const { customers } = await api('GET', '/customers?q=' + encodeURIComponent(cq));
    $('#actions').innerHTML = '<a class="btn soft" href="/api/admin/export/customers.csv">Export CSV</a><button class="btn" data-act="c-new">Add customer</button>';
    const had = document.activeElement && document.activeElement.id === 'c-q';
    $('#view').innerHTML = `<div class="card"><div class="bar-row"><input class="inp" id="c-q" type="search" placeholder="Search name, mobile or card number" value="${esc(cq)}" data-change="c-q"><span class="muted small">${customers.length} customer(s)</span></div>
      ${table(['Customer', 'Mobile', 'Loyalty card', '>Points', '>Orders', '>Total spent', 'Last order'], customers.map((c) => `<tr class="click" data-act="cust" data-id="${c.id}"><td><b>${esc(c.name)}</b></td><td class="nowrap">${esc(c.phone)}</td><td class="mono nowrap">${cardFmt(c.card_no)}</td><td class="right">${c.points}</td><td class="right">${c.orders}</td><td class="right nowrap">${money(c.spent)}</td><td class="muted nowrap">${day(c.last_order)}</td></tr>`), 'No customers yet. They are added automatically when they order.')}</div>`;
    if (had) { const i = $('#c-q'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }
  };
  changes['c-q'] = (el) => { cq = el.value; refresh(); };
  const custForm = (c) => `<div class="g2">${field('Full name', 'name', c.name, { req: true })}${field('Mobile number', 'phone', c.phone, { req: true })}</div><div class="g2">${field('Email', 'email', c.email)}${field('Address', 'address', c.address)}</div>${field('Notes about this customer', 'notes', c.notes, { type: 'textarea' })}`;
  acts['c-new'] = () => modal('Add customer', custForm({}), { onSave: async (fd) => { await api('POST', '/customers', Object.fromEntries(fd)); toast('Customer added'); } });
  function loyCard(c, L) {
    return `<div class="lcard" style="background:linear-gradient(135deg,${esc(L.cardBg)},${esc(L.cardBg2)});color:${esc(L.cardFg)}"><div class="t"><span>${esc(L.name)}</span>${A.site.brand.logo ? `<img src="${esc(A.site.brand.logo)}" alt="">` : ''}</div>
      <div><small>Card number</small><div class="n">${cardFmt(c.card_no)}</div></div><div class="b"><span><small>Member</small>${esc(c.name)}</span><img class="qr" src="${qrUrl(c.card_no, '&margin=0')}" alt="QR"></div></div>`;
  }
  A.loyCard = loyCard;
  async function custModal(id) {
    const [d, loy] = await Promise.all([api('GET', '/customers/' + id), api('GET', '/loyalty')]);
    const c = d.customer; A.openCust = { c, L: loy.settings };
    modal(c.name, `<div class="g2"><div>${loyCard(c, loy.settings)}<div class="acts" style="margin-top:12px"><button type="button" class="btn soft sm" data-act="c-print">Print card</button><button type="button" class="btn soft sm" data-act="c-points" data-id="${c.id}" data-sign="1">Add points</button><button type="button" class="btn soft sm" data-act="c-points" data-id="${c.id}" data-sign="-1">Deduct points</button></div></div>
      <div><div class="kv"><span>Points balance</span><b>${c.points} pts (${money(c.points * loy.settings.pointValue)})</b></div><div class="kv"><span>Orders</span><b>${c.orders}</b></div><div class="kv"><span>Total spent</span><b>${money(c.spent)}</b></div><div class="kv"><span>Average order</span><b>${money(c.orders ? c.spent / c.orders : 0)}</b></div><div class="kv"><span>Customer since</span><b>${day(c.created)}</b></div></div></div>
      <h4 class="grp">Details</h4>${custForm(c)}
      <div class="g2"><div><h4 class="grp">Mostly orders</h4>${d.favorites.length ? d.favorites.map((f) => `<div class="kv"><span>${esc(f.name)}</span><b>${f.qty} × · ${money(f.spent)}</b></div>`).join('') : '<p class="muted small">No orders yet.</p>'}</div>
      <div><h4 class="grp">Points history</h4>${d.points.length ? d.points.slice(0, 8).map((p) => `<div class="kv"><span>${day(p.ts)} · ${esc(p.reason || '')}</span><b style="color:${p.delta > 0 ? 'var(--ok)' : 'var(--danger)'}">${p.delta > 0 ? '+' : ''}${p.delta}</b></div>`).join('') : '<p class="muted small">No points activity yet.</p>'}</div></div>
      <h4 class="grp">Order history</h4>${table(['Order', '>Total', 'Payment', 'Status', 'Date'], d.orders.map((o) => `<tr class="click" data-act="order" data-id="${o.id}"><td class="mono">${esc(o.code)}</td><td class="right">${money(o.total)}</td><td>${pill(o.payment_status)}</td><td>${pill(o.status)}</td><td class="muted nowrap">${dt(o.created)}</td></tr>`), 'No orders yet.')}
      <div style="margin-top:14px"><button type="button" class="btn danger sm" data-act="c-del" data-id="${c.id}">Delete customer</button></div>`, { wide: true, onSave: async (fd) => { await api('PUT', '/customers/' + id, Object.fromEntries(fd)); toast('Customer saved'); } });
  }
  acts.cust = (el) => custModal(el.dataset.id).catch((e) => toast(e.message, true));
  acts['c-print'] = () => printHtml(`<div style="width:86mm">${loyCard(A.openCust.c, A.openCust.L)}</div>`);
  acts['c-points'] = async (el) => {
    const sign = Number(el.dataset.sign), n = prompt(sign > 0 ? 'How many points to add?' : 'How many points to deduct?'); if (!n) return;
    const reason = prompt('Reason (optional):', sign > 0 ? 'Bonus points' : 'Redeemed in store') || '';
    try { await api('POST', `/customers/${el.dataset.id}/points`, { delta: sign * Math.abs(parseInt(n, 10) || 0), reason }); toast('Points updated'); await custModal(el.dataset.id); refresh(); } catch (e) { toast(e.message, true); }
  };
  acts['c-del'] = async (el) => { if (!confirm('Delete this customer and their loyalty card? Their past orders stay in your reports.')) return; await api('DELETE', '/customers/' + el.dataset.id); closeModal(); refresh(); toast('Customer deleted'); };

  /* ================= LOYALTY ================= */
  views.loyalty = async () => {
    const d = await api('GET', '/loyalty'), L = d.settings;
    $('#view').innerHTML = `<div class="tiles"><div class="tile"><small>Card holders</small><b>${d.stats.members}</b></div><div class="tile"><small>Points outstanding</small><b>${d.stats.outstanding.toLocaleString()}</b><span>worth ${money(d.stats.outstanding * L.pointValue)}</span></div>
      <div class="tile"><small>Points given</small><b>${d.issued.earned.toLocaleString()}</b></div><div class="tile"><small>Points redeemed</small><b>${d.issued.redeemed.toLocaleString()}</b></div></div>
      <div class="cols eq"><form class="card" data-form="loy-save"><h3>Program settings</h3>${toggle('Loyalty program is active', 'enabled', L.enabled)}${field('Program / card name', 'name', L.name)}
        <div class="g2">${field(`Spend this much to earn 1 point (${cur()})`, 'pesoPerPoint', L.pesoPerPoint, { type: 'number', attrs: 'min="1" step="1"' })}${field(`Value of 1 point (${cur()})`, 'pointValue', L.pointValue, { type: 'number', attrs: 'min="0.01" step="0.01"' })}</div>
        <div class="g2">${field('Minimum points to redeem', 'minRedeem', L.minRedeem, { type: 'number', attrs: 'min="1"' })}${field('Welcome bonus points', 'signupBonus', L.signupBonus, { type: 'number', attrs: 'min="0"' })}</div>
        <div class="g3">${['cardBg', 'cardBg2', 'cardFg'].map((k, i) => `<div class="f"><label>${['Card colour 1', 'Card colour 2', 'Card text'][i]}</label><div class="colorf"><input type="color" name="${k}" value="${esc(L[k])}"></div></div>`).join('')}</div>
        <div data-err></div><button class="btn">Save loyalty settings</button></form>
        <div class="card"><h3>Card preview</h3>${loyCard({ card_no: '800012345678', name: 'Juan Dela Cruz' }, L)}<p class="small muted" style="margin-top:14px">Every customer gets a card number automatically with their first order. Points are added when an order is marked <b>Completed</b>. Customers enter their card number at checkout to pay with points. Open a customer to print their card.</p>
        <h4 class="grp">Recent activity</h4>${d.recent.slice(0, 8).map((r) => `<div class="kv"><span>${esc(r.name)} · ${esc(r.reason || '')}</span><b style="color:${r.delta > 0 ? 'var(--ok)' : 'var(--danger)'}">${r.delta > 0 ? '+' : ''}${r.delta}</b></div>`).join('') || '<p class="muted small">No activity yet.</p>'}</div></div>
      <div class="card"><h3>Card holders</h3>${table(['Member', 'Mobile', 'Card number', '>Points', '>Value'], d.top.map((c) => `<tr class="click" data-act="cust" data-id="${c.id}"><td><b>${esc(c.name)}</b></td><td>${esc(c.phone)}</td><td class="mono">${cardFmt(c.card_no)}</td><td class="right">${c.points}</td><td class="right">${money(c.points * L.pointValue)}</td></tr>`), 'No card holders yet.')}</div>`;
  };
  forms['loy-save'] = async (f, fd) => { const b = Object.fromEntries(fd); b.enabled = fd.has('enabled'); await api('PUT', '/loyalty', b); toast('Loyalty settings saved'); refresh(); };

  /* ================= REPORTS ================= */
  // all report dates are in the store's time zone (Store settings), not the browser's
  const iso = (d) => d.toISOString().slice(0, 10);
  const storeNow = () => new Date(Date.now() + (Number(A.site && A.site.brand.utcOffset) || 0) * 3600e3);
  const ago = (n) => iso(new Date(storeNow().getTime() - n * 864e5));
  const rr = { from: '', to: '' };
  views.reports = async () => {
    if (!rr.from) { rr.from = ago(29); rr.to = ago(0); }
    const r = await api('GET', `/reports?from=${rr.from}&to=${rr.to}`), s = r.summary, qs = `?from=${r.from}&to=${r.to}`;
    $('#actions').innerHTML = `<a class="btn soft" href="/api/admin/export/orders.csv${qs}">Export orders</a><a class="btn soft" href="/api/admin/export/products.csv${qs}">Export product sales</a><button class="btn" data-act="r-print">Print</button>`;
    $('#view').innerHTML = `<div class="card"><div class="bar-row" style="margin:0"><input class="inp" type="date" style="max-width:170px" value="${r.from}" data-change="r-date" data-k="from"><span class="muted">to</span><input class="inp" type="date" style="max-width:170px" value="${r.to}" data-change="r-date" data-k="to">
      ${[['today', 'Today'], ['7', '7 days'], ['30', '30 days'], ['month', 'This month'], ['last', 'Last month'], ['year', 'This year']].map(([k, l]) => `<button class="btn soft sm" data-act="r-preset" data-k="${k}">${l}</button>`).join('')}</div></div>
      <div class="tiles"><div class="tile"><small>Total sales</small><b>${money(s.revenue)}</b><span>${s.orders} order(s)</span></div><div class="tile"><small>Average order</small><b>${money(s.avg)}</b><span>${s.items} item(s) sold</span></div>
        <div class="tile"><small>Completed sales</small><b>${money(s.completedRevenue)}</b><span>${s.completed || 0} completed</span></div><div class="tile"><small>Payments received</small><b>${money(s.paidRevenue)}</b><span>marked as paid</span></div>
        <div class="tile"><small>Customers</small><b>${s.customers}</b><span>${s.newCustomers} new</span></div><div class="tile"><small>Cancelled orders</small><b>${s.cancelled}</b><span>${money(s.discounts)} in points discounts</span></div></div>
      <div class="card"><h3>Sales by day</h3>${r.byDay.length ? (r.byDay.length > 45 ? '<p class="muted small">Showing the busiest 45 days.</p>' : '') + bars(r.byDay.length > 45 ? r.byDay.slice().sort((a, b) => b.revenue - a.revenue).slice(0, 45).sort((a, b) => a.day.localeCompare(b.day)) : r.byDay) : '<div class="empty">No sales in this period.</div>'}</div>
      <div class="card"><h3>What customers mainly order</h3>${table(['Product', '>Qty sold', '>Orders', '>Sales'], r.byProduct.map((p) => `<tr><td><b>${esc(p.name)}</b> <span class="muted small">${esc(p.unit || '')}</span></td><td class="right">${p.qty}</td><td class="right">${p.orders}</td><td class="right">${money(p.revenue)}</td></tr>`), 'No sales in this period.')}</div>
      <div class="cols eq"><div class="card"><h3>By category</h3>${hbars(r.byCategory)}</div><div class="card"><h3>By payment method</h3>${hbars(r.byPayment)}</div></div>
      <div class="cols eq"><div class="card"><h3>Delivery vs pickup</h3>${hbars(r.byFulfillment.map((x) => ({ ...x, name: LBL[x.name] || x.name })))}</div><div class="card"><h3>Where orders came from</h3>${hbars(r.bySource)}</div></div>
      <div class="card"><h3>Top customers</h3>${table(['Customer', 'Mobile', '>Orders', '>Sales'], r.topCustomers.map((c) => `<tr><td><b>${esc(c.name)}</b></td><td>${esc(c.phone)}</td><td class="right">${c.orders}</td><td class="right">${money(c.revenue)}</td></tr>`), 'No sales in this period.')}</div>`;
  };
  changes['r-date'] = (el) => { if (el.value) { rr[el.dataset.k] = el.value; refresh(); } };
  acts['r-preset'] = (el) => {
    const n = storeNow(), k = el.dataset.k, y = n.getUTCFullYear(), m = n.getUTCMonth(); rr.to = iso(n);
    if (k === 'today') rr.from = iso(n); else if (k === '7') rr.from = ago(6); else if (k === '30') rr.from = ago(29);
    else if (k === 'month') rr.from = iso(new Date(Date.UTC(y, m, 1))); else if (k === 'year') rr.from = iso(new Date(Date.UTC(y, 0, 1)));
    else { rr.from = iso(new Date(Date.UTC(y, m - 1, 1))); rr.to = iso(new Date(Date.UTC(y, m, 0))); }
    refresh();
  };
  acts['r-print'] = () => window.print();

  /* ================= MESSAGES ================= */
  views.messages = async () => {
    const { messages } = await api('GET', '/messages');
    $('#view').innerHTML = messages.length ? messages.map((m) => `<div class="msg ${m.status === 'new' ? 'new' : ''}"><div class="h"><div><b>${esc(m.name)}</b> · <span class="muted">${esc(m.contact)}</span>${m.order_code ? ` · <span class="mono small">${esc(m.order_code)}</span>` : ''}</div><div>${pill(m.status)} <span class="muted small">${dt(m.created)} · ${esc(m.ticket)}</span></div></div>
      <p class="body">${esc(m.body)}</p><form data-form="msg-reply" data-id="${m.id}"><div class="f"><textarea name="reply" placeholder="Write a reply — the customer can read it on the website with their message code ${esc(m.ticket)}" maxlength="2000">${esc(m.reply || '')}</textarea></div>
      <div class="acts"><button class="btn sm">${m.reply ? 'Update reply' : 'Send reply'}</button>${m.status === 'new' ? `<button type="button" class="btn soft sm" data-act="msg-status" data-id="${m.id}" data-s="read">Mark as read</button>` : ''}${m.status !== 'closed' ? `<button type="button" class="btn soft sm" data-act="msg-status" data-id="${m.id}" data-s="closed">Close</button>` : ''}<button type="button" class="btn danger sm" data-act="msg-del" data-id="${m.id}">Delete</button></div></form></div>`).join('')
      : '<div class="card"><div class="empty">No messages yet. Customer support messages from the website appear here.</div></div>';
  };
  forms['msg-reply'] = async (f, fd) => { if (!String(fd.get('reply')).trim()) throw new Error('Write a reply first.'); await api('PATCH', '/messages/' + f.dataset.id, { reply: fd.get('reply') }); toast('Reply saved'); refresh(); badges(); };
  acts['msg-status'] = async (el) => { await api('PATCH', '/messages/' + el.dataset.id, { status: el.dataset.s }); refresh(); badges(); };
  acts['msg-del'] = async (el) => { if (!confirm('Delete this message?')) return; await api('DELETE', '/messages/' + el.dataset.id); refresh(); badges(); };

  /* ================= PAYMENT METHODS ================= */
  let methods = [];
  const PT = { cod: 'Cash on delivery / pickup', ewallet: 'E-wallet (GCash, Maya…)', bank: 'Bank transfer' };
  views.payments = async () => {
    methods = (await api('GET', '/payments')).methods;
    $('#actions').innerHTML = '<button class="btn" data-act="pm-edit" data-id="0">Add payment method</button>';
    $('#view').innerHTML = `<div class="card">${table(['Method', 'Type', 'Account', 'QR code', 'Status', ''], methods.map((m) => `<tr><td><b>${esc(m.name)}</b></td><td>${PT[m.type]}</td><td>${m.type === 'cod' ? '—' : `${esc(m.account_name || '')}<div class="mono small">${esc(m.account_number || 'Not set')}</div>`}</td>
      <td>${m.qr_image ? `<span class="thumb"><img src="${esc(m.qr_image)}" alt=""></span>` : '<span class="muted small">None</span>'}</td><td>${m.enabled ? '<span class="pill paid">Shown at checkout</span>' : '<span class="pill">Hidden</span>'}</td><td class="right"><button class="btn soft sm" data-act="pm-edit" data-id="${m.id}">Edit</button></td></tr>`))}</div>
      <p class="muted small">Customers who choose an e-wallet or bank transfer see your QR code and account number after placing the order, then send their reference number (and a receipt screenshot). You verify it in Orders and tap “Mark as paid”.</p>`;
  };
  acts['pm-edit'] = (el) => {
    const id = Number(el.dataset.id), m = methods.find((x) => x.id === id) || { type: 'ewallet', enabled: 1 };
    modal(id ? 'Edit payment method' : 'Add payment method', `<div class="g2">${field('Name shown to customers', 'name', m.name, { req: true, ph: 'e.g. GCash' })}${field('Type', 'type', m.type, { type: 'select', options: Object.entries(PT) })}</div>
      <div class="g2">${field('Account name', 'account_name', m.account_name)}${field('Account / mobile number', 'account_number', m.account_number)}</div>${imgField('Payment QR code image', 'qr_image', m.qr_image)}
      ${field('Instructions for the customer', 'instructions', m.instructions, { type: 'textarea' })}${field('Sort order', 'sort', m.sort || 0, { type: 'number' })}${toggle('Show at checkout', 'enabled', m.enabled)}
      ${id ? `<button type="button" class="btn danger sm" data-act="pm-del" data-id="${id}">Delete</button>` : ''}`, { onSave: async (fd) => { const b = Object.fromEntries(fd); b.enabled = fd.has('enabled'); await api(id ? 'PUT' : 'POST', '/payments' + (id ? '/' + id : ''), b); toast('Payment method saved'); } });
  };
  acts['pm-del'] = async (el) => { if (!confirm('Delete this payment method?')) return; await api('DELETE', '/payments/' + el.dataset.id); closeModal(); refresh(); };

  /* ================= QR CODES ================= */
  const qs = { slug: '', dark: '#0b1a4a', light: '#ffffff', head: 'Scan to order', sub: 'Order rice & groceries online' };
  let camp = { campaigns: [], base: '' };
  const qrTarget = () => (qs.slug ? `${camp.base}/q/${qs.slug}` : camp.base + '/');
  const qrImg = (fmt, dl) => qrUrl(qrTarget(), `&dark=${qs.dark.slice(1)}&light=${qs.light.slice(1)}${fmt ? '&fmt=' + fmt : ''}${dl ? '&dl=1' : ''}`);
  const poster = () => `<div class="poster">${A.site.brand.logo ? `<img class="logo" src="${esc(A.site.brand.logo)}" alt="">` : ''}<h2>${esc(qs.head)}</h2><p class="muted" style="font-size:1.05rem;margin-top:6px">${esc(qs.sub)}</p><img class="q" src="${qrImg()}" alt="QR code"><p class="mono small">${esc(qrTarget().replace(/^https?:\/\//, ''))}</p><p style="font-weight:600;margin-top:6px">${esc(A.site.brand.name)}</p></div>`;
  views.qr = async () => {
    camp = await api('GET', '/campaigns');
    if (qs.slug && !camp.campaigns.some((c) => c.slug === qs.slug)) qs.slug = '';
    $('#actions').innerHTML = '<button class="btn" data-act="qr-new">New tracked QR code</button>';
    $('#view').innerHTML = `<div class="cols eq"><div><div class="card"><h3>QR code for your ordering page</h3><div id="qr-poster">${poster()}</div>
      <div class="acts" style="margin-top:14px"><a class="btn" id="qr-png" href="${qrImg('png', 1)}">Download PNG</a><a class="btn soft" id="qr-svg" href="${qrImg('', 1)}">Download SVG</a><button class="btn soft" data-act="qr-print">Print poster</button><button class="btn soft" data-act="qr-copy">Copy link</button></div></div></div>
      <div><div class="card"><h3>Customise</h3>${field('Which QR code', 'slug', qs.slug, { type: 'select', options: [['', 'Main store link (not tracked)']].concat(camp.campaigns.map((c) => [c.slug, c.name + ' (tracked)'])), attrs: 'data-change="qr-opt" data-k="slug"' })}
        ${field('Poster heading', 'head', qs.head, { attrs: 'data-change="qr-opt" data-k="head"' })}${field('Poster text', 'sub', qs.sub, { attrs: 'data-change="qr-opt" data-k="sub"' })}
        <div class="g2"><div class="f"><label>QR colour</label><div class="colorf"><input type="color" value="${qs.dark}" data-change="qr-opt" data-k="dark"></div></div><div class="f"><label>Background</label><div class="colorf"><input type="color" value="${qs.light}" data-change="qr-opt" data-k="light"></div></div></div>
        <p class="small muted">Keep the QR colour dark and the background light so phones can scan it. ${A.site.brand.publicUrl ? '' : 'The link uses the address you are visiting now — set your website address in Store settings if it is different.'}</p></div>
      <div class="card"><h3>Tracked QR codes</h3><p class="small muted" style="margin-bottom:10px">Make a separate QR code for each place you promote (store counter, flyers, tarpaulin, Facebook) and see which one brings in orders.</p>
        ${table(['Name', '>Scans', '>Orders', '>Sales', ''], camp.campaigns.map((c) => `<tr><td><b>${esc(c.name)}</b><div class="mono small muted">/q/${esc(c.slug)}</div></td><td class="right">${c.scans}</td><td class="right">${c.orders}</td><td class="right">${money(c.revenue)}</td><td class="right nowrap"><button class="btn soft sm" data-act="qr-pick" data-slug="${esc(c.slug)}">Show</button> <button class="btn danger sm" data-act="qr-del" data-id="${c.id}">✕</button></td></tr>`), 'No tracked QR codes yet.')}</div></div></div>`;
  };
  function qrRefresh() { $('#qr-poster').innerHTML = poster(); $('#qr-png').href = qrImg('png', 1); $('#qr-svg').href = qrImg('', 1); }
  changes['qr-opt'] = (el) => { qs[el.dataset.k] = el.value; qrRefresh(); };
  acts['qr-pick'] = (el) => { qs.slug = el.dataset.slug; refresh(); window.scrollTo(0, 0); };
  acts['qr-print'] = () => printHtml(`<div style="max-width:150mm;margin:10mm auto">${poster()}</div>`);
  acts['qr-copy'] = () => navigator.clipboard.writeText(qrTarget()).then(() => toast('Link copied'), () => prompt('Copy this link:', qrTarget()));
  acts['qr-new'] = () => modal('New tracked QR code', field('Name', 'name', '', { req: true, ph: 'e.g. Flyers, Tarpaulin, Facebook page' }), { saveLabel: 'Create', onSave: async (fd) => { await api('POST', '/campaigns', { name: fd.get('name') }); toast('QR code created'); } });
  acts['qr-del'] = async (el) => { if (!confirm('Delete this tracked QR code? Printed copies will still open your store.')) return; await api('DELETE', '/campaigns/' + el.dataset.id); refresh(); };

  /* ================= SECURITY ================= */
  views.security = async () => {
    const s = await api('GET', '/security');
    $('#view').innerHTML = `<div class="cols eq"><div><form class="card" data-form="pw"><h3>Change password</h3><div data-err></div>${field('Current password', 'current', '', { type: 'password', req: true, attrs: 'autocomplete="current-password"' })}
      ${field('New password', 'next', '', { type: 'password', req: true, attrs: 'autocomplete="new-password" minlength="10"', help: 'At least 10 characters, with letters, numbers and an uppercase letter or symbol.' })}${field('Confirm new password', 'again', '', { type: 'password', req: true, attrs: 'autocomplete="new-password"' })}
      <button class="btn">Change password</button><p class="small muted" style="margin-top:10px">Changing your password signs out every other device.</p></form>
      <div class="card"><h3>Two-step sign-in ${s.twoFactor ? '<span class="pill paid">On</span>' : '<span class="pill">Off</span>'}</h3><p class="small muted" style="margin-bottom:12px">Adds a 6-digit code from an authenticator app (Google Authenticator, Microsoft Authenticator, Authy) every time you sign in. Even if someone learns your password, they cannot get in without your phone.</p>
      <div id="tfa">${s.twoFactor ? `<form data-form="tfa-off"><div data-err></div>${field('Enter your password to turn it off', 'password', '', { type: 'password', req: true })}<button class="btn danger">Turn off two-step sign-in</button></form>` : '<button class="btn" data-act="tfa-setup">Set up two-step sign-in</button>'}</div></div></div>
      <div><div class="card"><h3>Signed-in devices <button class="btn soft sm" data-act="sess-others">Sign out other devices</button></h3>${s.sessions.map((x) => `<div class="kv"><span>${esc((x.ua.match(/\(([^)]+)\)/) || [])[1] || x.ua || 'Unknown device').slice(0, 46)}<br><span class="small">IP ${esc(x.ip)} · active ${dt(x.lastSeen)}</span></span><b>${x.current ? '<span class="pill paid">This device</span>' : `<button class="btn danger sm" data-act="sess-kill" data-key="${esc(x.key)}">Sign out</button>`}</b></div>`).join('')}</div>
      <div class="card"><h3>Sign-in activity</h3>${s.log.map((l) => `<div class="kv"><span>${dt(l.ts)} · IP ${esc(l.ip)}</span><b style="color:${l.ok ? 'var(--ok)' : 'var(--danger)'}">${esc(l.note)}</b></div>`).join('')}</div>
      <div class="card"><h3>How your admin is protected</h3><ul class="small muted" style="margin:0;padding-left:18px;line-height:1.7"><li>Password is stored encrypted (scrypt) — it can never be read back</li><li>5 wrong passwords locks that device out, longer each time</li><li>Sessions end automatically after 2 hours of inactivity</li><li>Sign-in cookie cannot be read by scripts or other websites</li><li>Every change request is checked with a secret anti-forgery token</li></ul></div></div></div>`;
  };
  forms.pw = async (f, fd) => { await changePw(fd); toast('Password changed'); f.reset(); refresh(); };
  acts['tfa-setup'] = async () => {
    try {
      const r = await api('POST', '/2fa/setup');
      $('#tfa').innerHTML = `<form data-form="tfa-on"><p class="small"><b>1.</b> Scan this with your authenticator app:</p><img alt="2FA QR" style="width:200px;display:block;margin:10px 0" src="data:image/svg+xml;utf8,${encodeURIComponent(r.qr)}">
        <p class="small muted">Or type this key: <span class="mono">${esc(r.secret.replace(/(.{4})/g, '$1 '))}</span></p><p class="small" style="margin-top:12px"><b>2.</b> Enter the 6-digit code it shows:</p><div data-err></div>
        <div class="f" style="max-width:200px"><input name="code" inputmode="numeric" maxlength="6" required autocomplete="one-time-code"></div><button class="btn">Turn on</button></form>`;
    } catch (e) { toast(e.message, true); }
  };
  forms['tfa-on'] = async (f, fd) => { await api('POST', '/2fa/enable', { code: fd.get('code') }); toast('Two-step sign-in is on'); refresh(); };
  forms['tfa-off'] = async (f, fd) => { await api('POST', '/2fa/disable', { password: fd.get('password') }); toast('Two-step sign-in turned off'); refresh(); };
  acts['sess-others'] = async () => { await api('POST', '/sessions/revoke', { key: 'others' }); toast('Other devices signed out'); refresh(); };
  acts['sess-kill'] = async (el) => { await api('POST', '/sessions/revoke', { key: el.dataset.key }); refresh(); };

  A.boot = boot;
  document.addEventListener('DOMContentLoaded', boot);
})();
