/* Admin → Design & branding (live preview) and Store settings */
(() => {
  'use strict';
  const A = window.ADM, { $, esc, views, acts, api, toast } = A, T = window.CKJTheme;
  const get = (o, p) => p.split('.').reduce((a, k) => (a == null ? a : a[k]), o);
  const set = (o, p, v) => { const ks = p.split('.'); let a = o; for (let i = 0; i < ks.length - 1; i++) { if (a[ks[i]] == null) a[ks[i]] = {}; a = a[ks[i]]; } a[ks[ks.length - 1]] = v; };
  const clone = (o) => JSON.parse(JSON.stringify(o));
  let draft = null, defaults = null, openGroups = new Set(['Theme']), timer;

  /* ---- schema-driven fields: [path, label, type, options] ---- */
  function fld([path, label, type = 'text', o = {}]) {
    const v = get(draft, path), d = `data-path="${path}" data-type="${type}"`;
    const help = o.help ? `<small>${esc(o.help)}</small>` : '';
    switch (type) {
      case 'toggle': return `<label class="sw"><span>${esc(label)}</span><input type="checkbox" ${d} ${v ? 'checked' : ''}></label>`;
      case 'textarea': return `<div class="f"><label>${esc(label)}</label><textarea ${d} ${o.rows ? `style="min-height:${o.rows * 22}px"` : ''} ${o.mono ? 'class="mono" spellcheck="false"' : ''}>${esc(v)}</textarea>${help}</div>`;
      case 'select': return `<div class="f"><label>${esc(label)}</label><select ${d}>${o.options.map((x) => { const [val, l] = Array.isArray(x) ? x : [x, x]; return `<option value="${esc(val)}" ${String(val) === String(v) ? 'selected' : ''}>${esc(l)}</option>`; }).join('')}</select>${help}</div>`;
      case 'color': return `<div class="f"><label>${esc(label)}</label><div class="colorf"><input type="color" ${d} value="${esc(/^#[0-9a-f]{6}$/i.test(v) ? v : '#000000')}"><input type="text" class="mono" ${d} value="${esc(v || '')}" maxlength="9" placeholder="${esc(o.ph || '#000000')}"></div>${help}</div>`;
      case 'range': return `<div class="f"><label>${esc(label)}</label><div class="rangef"><input type="range" ${d} min="${o.min}" max="${o.max}" step="${o.step || 1}" value="${esc(v)}"><output>${esc(v)}${o.unit || ''}</output></div>${help}</div>`;
      case 'number': return `<div class="f"><label>${esc(label)}</label><input type="number" ${d} value="${esc(v)}" min="${o.min == null ? 0 : o.min}" step="${o.step || 'any'}">${help}</div>`;
      case 'image': return `<div class="f"><label>${esc(label)}</label><div class="imgf" data-imgf><div class="pv">${v ? `<img src="${esc(v)}" alt="">` : 'No image'}</div><input type="hidden" ${d} value="${esc(v || '')}"><button type="button" class="btn soft sm" data-act="img-pick">Upload</button><button type="button" class="btn soft sm" data-act="img-clear">Remove</button><input type="file" accept="image/png,image/jpeg,image/webp,image/gif" hidden></div>${help}</div>`;
      default: return `<div class="f"><label>${esc(label)}</label><input type="text" ${d} value="${esc(v)}" ${o.ph ? `placeholder="${esc(o.ph)}"` : ''} maxlength="${o.max || 300}">${help}</div>`;
    }
  }
  const fields = (list) => list.map(fld).join('');
  const group = (name, inner, focus = '') => `<details class="grp" data-g="${esc(name)}" data-focus="${focus}" ${openGroups.has(name) ? 'open' : ''}><summary>${esc(name)}</summary><div class="in">${inner}</div></details>`;
  const fontOpts = Object.keys(T.FONTS);
  const COLOR_LBL = { primary: 'Buttons & brand colour', onPrimary: 'Text on buttons', accent: 'Links & highlights', bg: 'Page background', surface: 'Cards', text: 'Main text', muted: 'Secondary text', border: 'Lines & borders', heroBg: 'Hero background', heroText: 'Hero text', footerBg: 'Footer background', footerText: 'Footer text' };
  const SEC_LBL = { categories: 'Shop by category', featured: 'Best sellers', products: 'All products', steps: 'How ordering works', loyalty: 'Loyalty / rewards', track: 'Track your order', contact: 'Contact & support' };

  function presetsHtml() {
    return `<div class="presets">${Object.entries(T.PRESETS).map(([n, p]) => `<button type="button" class="preset ${draft.theme.preset === n ? 'on' : ''}" data-act="d-preset" data-name="${esc(n)}"><span>${['heroBg', 'primary', 'accent', 'bg', 'text'].map((k) => `<i style="background:${p[k]}"></i>`).join('')}</span>${esc(n)}</button>`).join('')}</div>`;
  }
  function sectionsHtml() {
    return draft.sections.order.map((k, i) => `<div class="sortrow"><button type="button" class="mv" data-act="d-move" data-i="${i}" data-d="-1" ${i ? '' : 'disabled'} aria-label="Move up">▲</button><button type="button" class="mv" data-act="d-move" data-i="${i}" data-d="1" ${i < draft.sections.order.length - 1 ? '' : 'disabled'} aria-label="Move down">▼</button>
      <span>${SEC_LBL[k]}</span><label class="sw"><input type="checkbox" data-path="sections.enabled.${k}" data-type="toggle" ${draft.sections.enabled[k] ? 'checked' : ''}></label></div>`).join('');
  }
  function panelHtml() {
    const steps = (draft.text.steps || []).map((s, i) => `<h4 class="grp">Step ${i + 1}</h4><div class="g2">${fld([`text.steps.${i}.icon`, 'Icon', 'text', { max: 8 }])}${fld([`text.steps.${i}.title`, 'Title'])}</div>${fld([`text.steps.${i}.text`, 'Text'])}`).join('');
    return [
      group('Theme', `<p class="small muted" style="margin-bottom:10px">Pick a ready-made look, then fine-tune anything below.</p>${presetsHtml()}`),
      group('Colours', `<div class="g2">${T.COLOR_KEYS.map((k) => fld([`theme.${k}`, COLOR_LBL[k], 'color'])).join('')}</div>`),
      group('Fonts', fields([['theme.headingFont', 'Heading font', 'select', { options: fontOpts }], ['theme.bodyFont', 'Body font', 'select', { options: fontOpts }], ['theme.headingWeight', 'Heading thickness', 'range', { min: 300, max: 900, step: 100 }],
        ['theme.headingSpacing', 'Heading letter spacing', 'range', { min: -0.06, max: 0.06, step: 0.005, unit: 'em' }], ['theme.baseSize', 'Text size', 'range', { min: 14, max: 20, unit: 'px' }], ['theme.heroScale', 'Hero headline size', 'range', { min: 0.6, max: 1.4, step: 0.05, unit: '×' }]])),
      group('Shapes & buttons', fields([['theme.radius', 'Corner roundness', 'range', { min: 0, max: 36, unit: 'px' }], ['theme.buttonShape', 'Button shape', 'select', { options: [['pill', 'Pill (fully rounded)'], ['rounded', 'Rounded'], ['square', 'Square']] }]])),
      group('Logo & name', fields([['brand.logo', 'Logo', 'image', { help: 'Square or wide PNG/JPG. Also used as the browser tab icon.' }], ['brand.logoHeight', 'Logo size in the top bar', 'range', { min: 22, max: 56, unit: 'px' }], ['brand.showNameInNav', 'Show store name beside the logo', 'toggle'],
        ['brand.short', 'Short store name'], ['brand.name', 'Full business name'], ['brand.tagline', 'Tagline (shown in search results & link previews)']])),
      group('Announcement bar', fields([['announcement.enabled', 'Show announcement bar', 'toggle'], ['announcement.text', 'Announcement text'], ['announcement.bg', 'Bar colour (blank = brand colour)', 'color', { ph: 'theme' }], ['announcement.fg', 'Text colour (blank = default)', 'color', { ph: 'theme' }]])),
      group('Hero (top banner)', fields([['hero.layout', 'Layout', 'select', { options: [['center', 'Text centred on colour'], ['image', 'Full background photo'], ['split', 'Text left, picture right']] }], ['hero.align', 'Text alignment', 'select', { options: [['center', 'Centre'], ['left', 'Left']] }],
        ['hero.height', 'Height', 'select', { options: [['tall', 'Tall'], ['medium', 'Medium'], ['compact', 'Compact']] }], ['hero.showLogo', 'Show logo in hero', 'toggle'], ['hero.eyebrow', 'Small text above headline'], ['hero.title', 'Headline', 'textarea', { help: 'Press Enter for a new line.' }],
        ['hero.subtitle', 'Text under headline', 'textarea'], ['hero.cta1', 'Main button text'], ['hero.cta2', 'Second button text'], ['hero.image', 'Hero photo', 'image', { help: 'Used by the “Full background photo” and “Text left, picture right” layouts.' }],
        ['hero.overlay', 'Photo darkening', 'range', { min: 0, max: 90, unit: '%' }]]), '.hero'),
      group('Page sections', `<p class="small muted" style="margin-bottom:6px">Turn sections on or off and change their order.</p><div id="d-sections">${sectionsHtml()}</div>`),
      group('Section headings & text', fields([['text.categoriesTitle', 'Categories heading'], ['text.featuredTitle', 'Best sellers heading'], ['text.featuredSub', 'Best sellers text'], ['text.productsTitle', 'Products heading'], ['text.productsSub', 'Products text'], ['text.stepsTitle', 'How-it-works heading']])
        + steps + fields([['text.loyaltyTitle', 'Loyalty heading'], ['text.loyaltyText', 'Loyalty text', 'textarea'], ['text.trackTitle', 'Tracking heading'], ['text.trackText', 'Tracking text'], ['text.contactTitle', 'Contact heading'], ['text.contactText', 'Contact text', 'textarea']])),
      group('Product cards', fields([['cards.columns', 'Products per row (desktop)', 'range', { min: 2, max: 5 }], ['cards.imageFit', 'Product photos', 'select', { options: [['cover', 'Fill the square'], ['contain', 'Show whole photo']] }], ['cards.showStock', 'Show “Only X left” and stock count', 'toggle']]), '#shop'),
      group('Checkout & footer text', fields([['text.checkoutNote', 'Note shown at checkout'], ['text.thankYou', 'Thank-you message after ordering'], ['text.footerText', 'Footer text (after the © year)'], ['text.footerNote', 'Second footer line']]), '.foot'),
      group('Advanced: custom CSS', fields([['theme.customCss', 'Custom CSS', 'textarea', { rows: 8, mono: true, help: 'For developers. Added after the theme, so it can override anything.' }]]))
    ].join('');
  }

  function send(focus) {
    clearTimeout(timer);
    timer = setTimeout(() => { const fr = $('#d-frame'); if (fr && fr.contentWindow) fr.contentWindow.postMessage({ type: 'ckj-preview', site: draft, focus: focus || '' }, location.origin); }, 120);
  }
  function push(focus) { A.dirty = true; const b = $('#d-save'); if (b) b.disabled = false; send(focus); }
  window.addEventListener('message', (e) => { if (e.origin === location.origin && e.data && e.data.type === 'ckj-preview-ready' && draft && A.current === 'design') send(); });

  function readInput(el) {
    const t = el.dataset.type;
    if (t === 'toggle') return el.checked;
    if (t === 'range' || t === 'number') return el.value === '' ? 0 : Number(el.value);
    return el.value;
  }
  document.addEventListener('input', (e) => {
    const el = e.target.closest('[data-path]'); if (!el || !draft || !['design', 'settings'].includes(A.current)) return;
    const path = el.dataset.path; let v = readInput(el);
    if (el.dataset.type === 'color') {
      if (el.type === 'text' && v && !T.COLOR_RE.test(v)) return;                       // wait for a full hex code
      const other = el.parentNode.querySelector(el.type === 'color' ? 'input[type=text]' : 'input[type=color]');
      if (other && (el.type === 'color' || /^#[0-9a-f]{6}$/i.test(v))) other.value = v;
      if (path.startsWith('theme.')) { draft.theme.preset = 'Custom'; document.querySelectorAll('.preset.on').forEach((p) => p.classList.remove('on')); }
    }
    if (el.dataset.type === 'range') el.parentNode.querySelector('output').textContent = v + (el.parentNode.querySelector('output').textContent.replace(/^[-\d.]+/, ''));
    set(draft, path, v);
    if (A.current === 'design') { const g = el.closest('details'); push(g ? g.dataset.focus : ''); } else { A.dirty = true; $('#s-save').disabled = false; }
  });
  document.addEventListener('toggle', (e) => { const g = e.target.dataset && e.target.dataset.g; if (g) e.target.open ? openGroups.add(g) : openGroups.delete(g); }, true);

  views.design = async () => {
    if (!draft || !A.dirty) { const r = await api('GET', '/settings'); draft = clone(r.site); defaults = r.defaults; A.site = r.site; }
    $('#actions').innerHTML = '<button class="btn soft" data-act="d-reset">Reset design to default</button><button class="btn soft" data-act="d-discard">Discard changes</button><button class="btn" id="d-save" data-act="d-save" disabled>Save & publish</button>';
    $('#view').innerHTML = `<div class="design"><div class="d-panel" id="d-panel">${panelHtml()}</div>
      <div class="d-prev" id="d-prev"><div class="d-bar"><button class="tab on" data-act="d-device" data-m="">🖥 Desktop</button><button class="tab" data-act="d-device" data-m="mobile">📱 Phone</button><a class="tab" href="/" target="_blank" rel="noopener">Open live store ↗</a></div>
      <div class="d-stage"><iframe id="d-frame" src="/?preview=1" title="Store preview"></iframe></div></div></div>`;
  };
  const rerenderPanel = () => { const p = $('#d-panel'), top = p.scrollTop; p.innerHTML = panelHtml(); p.scrollTop = top; };
  acts['d-preset'] = (el) => { Object.assign(draft.theme, T.PRESETS[el.dataset.name], { preset: el.dataset.name }); rerenderPanel(); push(); };
  acts['d-move'] = (el) => { const i = Number(el.dataset.i), j = i + Number(el.dataset.d), o = draft.sections.order; if (j < 0 || j >= o.length) return; [o[i], o[j]] = [o[j], o[i]]; $('#d-sections').innerHTML = sectionsHtml(); push(); };
  acts['d-device'] = (el) => { $('#d-prev').classList.toggle('mobile', el.dataset.m === 'mobile'); document.querySelectorAll('[data-act="d-device"]').forEach((b) => b.classList.toggle('on', b === el)); };
  acts['d-save'] = async () => {
    try { const r = await api('PUT', '/settings', { site: draft }); A.site = r.site; draft = clone(r.site); A.dirty = false; $('#d-save').disabled = true; toast('Published — your store is updated'); send(); }
    catch (e) { toast(e.message, true); }
  };
  acts['d-discard'] = () => { if (A.dirty && !confirm('Discard your unsaved changes?')) return; A.dirty = false; draft = null; A.refresh(); };
  acts['d-reset'] = () => {
    if (!confirm('Reset colours, fonts, hero, sections and text to the original design? Your logo, store details and ordering settings are kept. Nothing is published until you press Save.')) return;
    const keep = clone(draft);
    draft = Object.assign(clone(defaults), { brand: keep.brand, contact: keep.contact, order: keep.order });
    rerenderPanel(); push();
  };

  /* ================= STORE SETTINGS ================= */
  views.settings = async () => {
    const r = await api('GET', '/settings'); draft = clone(r.site); defaults = r.defaults; A.site = r.site;
    $('#actions').innerHTML = '<button class="btn" id="s-save" data-act="s-save" disabled>Save settings</button>';
    const card = (title, inner) => `<div class="card"><h3>${title}</h3>${inner}</div>`;
    $('#view').innerHTML = `<div class="settings-wrap">
      ${card('Taking orders', fields([['order.accepting', 'Accept online orders', 'toggle'], ['order.closedMessage', 'Message shown when ordering is closed'], ['order.delivery', 'Offer delivery', 'toggle'], ['order.pickup', 'Offer store pickup', 'toggle']])
        + `<div class="g3">${fields([['order.deliveryFee', 'Delivery fee', 'number'], ['order.freeDeliveryMin', 'Free delivery from (0 = never)', 'number'], ['order.minOrder', 'Minimum order (0 = none)', 'number']])}</div>`
        + `<h4 class="grp">Delivery by distance</h4>` + fields([['order.distancePricing', 'Charge delivery by distance from the store', 'toggle']])
        + fields([['order.freeKmMin', 'Minimum purchase for free delivery inside that distance (0 = always free)', 'number', { help: 'Smaller orders inside the free distance pay the fee for one km.' }]]) + `<div class="g3">${fields([['order.freeKm', 'Free delivery within (km)', 'number'], ['order.feePerKm', 'Fee per km beyond that', 'number', { help: 'Each started km counts. Added to the delivery fee above.' }], ['order.maxKm', 'Farthest delivery (km, 0 = no limit)', 'number']])}</div>`
        + `<div class="g2">${fields([['order.storeLat', 'Store location — latitude', 'number', { min: -90 }], ['order.storeLng', 'Store location — longitude', 'number', { min: -180 }]])}</div>`
        + `<div class="f"><button type="button" class="btn soft sm" data-act="s-geo">📍 I am at the store now — use my location</button><small>Or open Google Maps, press and hold on the store, and copy the two numbers shown. Distance is measured in a straight line. Once the store location is set, customers must tap “Use my location” at checkout to order for delivery.</small></div>`
        + fields([['order.deliveryNote', 'Delivery note shown at checkout', 'text', { ph: 'e.g. Delivery within town proper only' }]]) + `<div class="g2">${fields([['order.prefix', 'Tracking code prefix', 'text', { max: 6, help: 'Codes look like CKJ-AB12CD' }], ['order.lowStock', 'Low-stock warning at', 'number']])}</div>`)}
      ${card('Store contact details', `<div class="g2">${fields([['contact.phone', 'Phone / mobile'], ['contact.email', 'Email']])}</div>` + fields([['contact.address', 'Store address', 'textarea'], ['contact.hours', 'Store hours'], ['contact.facebook', 'Facebook page / Messenger link', 'text', { ph: 'https://facebook.com/yourpage' }]]))}
      ${card('Business', fields([['brand.name', 'Full business name'], ['brand.short', 'Short store name']]) + `<div class="g2">${fields([['brand.currency', 'Currency symbol', 'text', { max: 4 }], ['brand.utcOffset', 'Time zone (hours from UTC)', 'number', { min: -12, step: 0.5, help: 'Philippines = 8. Used for daily sales reports.' }]])}</div>`
        + fields([['brand.publicUrl', 'Website address (for QR codes)', 'text', { ph: 'https://www.yourstore.com', help: 'Leave blank to use the address you are visiting now.' }]]))}
      <p class="small muted">Looking for colours, fonts, logo, hero or page text? Go to <a href="#design">Design & branding</a>.</p></div>`;
  };
  acts['s-geo'] = () => {
    if (!navigator.geolocation) return toast('This browser cannot share its location.', true);
    navigator.geolocation.getCurrentPosition((pos) => {
      for (const [k, v] of [['order.storeLat', pos.coords.latitude], ['order.storeLng', pos.coords.longitude]]) { const i = document.querySelector(`[data-path="${k}"]`); if (i) { i.value = v.toFixed(6); i.dispatchEvent(new Event('input', { bubbles: true })); } }
      toast('Store location set — remember to save');
    }, () => toast('Could not get your location. Allow location access and try again.', true), { enableHighAccuracy: true, timeout: 15000 });
  };
  acts['s-save'] = async () => {
    try { const r = await api('PUT', '/settings', { site: draft }); A.site = r.site; A.dirty = false; toast('Settings saved'); A.refresh(); }
    catch (e) { toast(e.message, true); }
  };
})();
