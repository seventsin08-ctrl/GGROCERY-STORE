'use strict';
const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

const DATA_DIR = path.resolve(process.env.DATA_DIR || process.env.RAILWAY_VOLUME_MOUNT_PATH || path.join(__dirname, '..', 'data'));
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const PROOF_DIR = path.join(DATA_DIR, 'proofs');
for (const d of [DATA_DIR, UPLOAD_DIR, PROOF_DIR]) fs.mkdirSync(d, { recursive: true });

const db = new DatabaseSync(path.join(DATA_DIR, 'store.db'));
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');

db.exec(`
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS admin (
  id INTEGER PRIMARY KEY CHECK (id = 1), pass_hash TEXT NOT NULL, must_change INTEGER NOT NULL DEFAULT 1,
  totp_secret TEXT, totp_enabled INTEGER NOT NULL DEFAULT 0, totp_last INTEGER NOT NULL DEFAULT 0, updated TEXT
);
CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY, csrf TEXT NOT NULL, created TEXT NOT NULL, last_seen TEXT NOT NULL, expires TEXT NOT NULL, ip TEXT, ua TEXT
);
CREATE TABLE IF NOT EXISTS login_log (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, ip TEXT, ok INTEGER NOT NULL, note TEXT);
CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, emoji TEXT, sort INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT, category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
  price REAL NOT NULL DEFAULT 0, compare_price REAL, unit TEXT, stock INTEGER, image TEXT, emoji TEXT,
  featured INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, sort INTEGER NOT NULL DEFAULT 0, created TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT UNIQUE, email TEXT, address TEXT, notes TEXT,
  card_no TEXT UNIQUE NOT NULL, points INTEGER NOT NULL DEFAULT 0, created TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS payment_methods (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'ewallet', account_name TEXT, account_number TEXT,
  qr_image TEXT, instructions TEXT, enabled INTEGER NOT NULL DEFAULT 1, sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  name TEXT NOT NULL, phone TEXT NOT NULL, address TEXT, fulfillment TEXT NOT NULL, notes TEXT,
  subtotal REAL NOT NULL, delivery_fee REAL NOT NULL DEFAULT 0, discount REAL NOT NULL DEFAULT 0, total REAL NOT NULL,
  points_redeemed INTEGER NOT NULL DEFAULT 0, points_earned INTEGER NOT NULL DEFAULT 0, points_awarded INTEGER NOT NULL DEFAULT 0,
  payment_method_id INTEGER, payment_name TEXT, payment_type TEXT, payment_ref TEXT, payment_proof TEXT,
  payment_status TEXT NOT NULL DEFAULT 'unpaid', status TEXT NOT NULL DEFAULT 'pending', history TEXT NOT NULL DEFAULT '[]',
  admin_note TEXT, source TEXT, created TEXT NOT NULL, updated TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created);
CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id);
CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER, name TEXT NOT NULL, category TEXT, unit TEXT, price REAL NOT NULL, qty INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_items_order ON order_items(order_id);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ticket TEXT UNIQUE NOT NULL, name TEXT NOT NULL, contact TEXT NOT NULL, order_code TEXT,
  body TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'new', reply TEXT, created TEXT NOT NULL, replied_at TEXT
);
CREATE TABLE IF NOT EXISTS loyalty_tx (
  id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  delta INTEGER NOT NULL, reason TEXT, order_id INTEGER, ts TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS qr_campaigns (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, slug TEXT UNIQUE NOT NULL, scans INTEGER NOT NULL DEFAULT 0, created TEXT NOT NULL);
`);

for (const col of ['lat REAL', 'lng REAL', 'distance_km REAL']) {
  try { db.exec('ALTER TABLE orders ADD COLUMN ' + col); } catch { /* column already exists */ }
}
for (const col of ["username TEXT NOT NULL DEFAULT 'Admin'", 'is_default INTEGER NOT NULL DEFAULT 0']) {
  try { db.exec('ALTER TABLE admin ADD COLUMN ' + col); } catch { /* column already exists */ }
}

const DEFAULT_SITE = {
  brand: {
    name: 'CK & J Wet and Dry Goods Trading Corporation', short: 'CK&J Grocery', tagline: 'Rice, groceries and everyday essentials — delivered fresh.',
    logo: '/assets/logo.jpg', logoHeight: 40, showNameInNav: true, currency: '₱', utcOffset: 8, publicUrl: ''
  },
  theme: {
    preset: 'CK&J Navy', primary: '#0b1a4a', onPrimary: '#ffffff', accent: '#0071e3', bg: '#fbfbfd', surface: '#ffffff', text: '#1d1d1f',
    muted: '#6e6e73', border: '#e3e3e8', heroBg: '#0a1433', heroText: '#ffffff', footerBg: '#f5f5f7', footerText: '#6e6e73',
    headingFont: 'System (Apple style)', bodyFont: 'System (Apple style)', headingWeight: 700, headingSpacing: -0.025, baseSize: 17,
    heroScale: 1, radius: 20, buttonShape: 'pill', cardStyle: 'soft', customCss: ''
  },
  announcement: { enabled: true, text: 'Free delivery on orders ₱2,000 and up within town.', bg: '', fg: '' },
  hero: {
    layout: 'center', eyebrow: 'CK&J Grocery', title: 'Rice and groceries.\nStraight to your door.', subtitle: 'Quality wet and dry goods at honest prices. Order in a minute, track it by code, pay the way you like.',
    cta1: 'Shop now', cta2: 'Track my order', image: '', overlay: 45, showLogo: true, height: 'tall', align: 'center'
  },
  sections: {
    order: ['categories', 'featured', 'products', 'steps', 'loyalty', 'track', 'contact'],
    enabled: { categories: true, featured: true, products: true, steps: true, loyalty: true, track: true, contact: true }
  },
  text: {
    categoriesTitle: 'Shop by category', featuredTitle: 'Best sellers.', featuredSub: 'The things our customers keep coming back for.',
    productsTitle: 'Everything in store.', productsSub: 'Fresh stock, updated daily.',
    stepsTitle: 'Ordering is simple.', steps: [
      { icon: '🛒', title: 'Choose', text: 'Add rice, groceries and fresh goods to your cart.' },
      { icon: '💳', title: 'Pay your way', text: 'Scan our QR, send to our account number, or pay cash on delivery.' },
      { icon: '📦', title: 'Track', text: 'Follow your order with your tracking code until it arrives.' }
    ],
    loyaltyTitle: 'Every order earns points.', loyaltyText: 'Your loyalty card is created automatically with your first order. Collect points and use them like cash.',
    trackTitle: 'Track your order.', trackText: 'Enter the tracking code you received after ordering.',
    contactTitle: 'We’re here to help.', contactText: 'Questions about an order or a product? Send us a message and we’ll get back to you.',
    footerText: 'CK & J Wet and Dry Goods Trading Corporation. All rights reserved.', footerNote: '',
    checkoutNote: 'We’ll confirm your order by phone or text.', thankYou: 'Thank you! Your order has been received.'
  },
  contact: { phone: '', email: '', address: '', hours: 'Open daily, 7:00 AM – 7:00 PM', facebook: '' },
  order: {
    prefix: 'CKJ', accepting: true, closedMessage: 'We are not accepting online orders right now. Please check back soon.',
    delivery: true, pickup: true, deliveryFee: 0, freeDeliveryMin: 0, minOrder: 0, distancePricing: true, storeLat: 0, storeLng: 0, freeKm: 1, freeKmMin: 2000, feePerKm: 20, maxKm: 0, deliveryNote: 'Delivery within town proper.', lowStock: 5
  },
  cards: { columns: 4, showStock: true, imageFit: 'cover' }
};
const DEFAULT_LOYALTY = { enabled: true, name: 'CK&J Rewards', pesoPerPoint: 100, pointValue: 1, minRedeem: 20, signupBonus: 0, cardBg: '#0b1a4a', cardBg2: '#1c3a8a', cardFg: '#ffffff' };

function isObj(v) { return v && typeof v === 'object' && !Array.isArray(v); }
// Fill missing keys from defaults (so upgrades never break saved settings)
function withDefaults(val, def) {
  if (!isObj(def)) return val === undefined ? def : val;
  const out = {};
  const src = isObj(val) ? val : {};
  for (const k of Object.keys(def)) out[k] = withDefaults(src[k], def[k]);
  for (const k of Object.keys(src)) if (!(k in out)) out[k] = src[k];
  return out;
}

const DEFAULTS = { site: DEFAULT_SITE, loyalty: DEFAULT_LOYALTY };
const cache = {};
function getSetting(key) {
  if (cache[key]) return cache[key];
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  let val;
  try { val = row ? JSON.parse(row.value) : undefined; } catch { val = undefined; }
  cache[key] = withDefaults(val, DEFAULTS[key]);
  return cache[key];
}
function setSetting(key, value) {
  const v = withDefaults(value, DEFAULTS[key]);
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(key, JSON.stringify(v));
  cache[key] = v;
  return v;
}

function tx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { try { db.exec('ROLLBACK'); } catch { /* ignore */ } throw e; }
}

function seed() {
  const now = new Date().toISOString();
  if (!db.prepare('SELECT 1 FROM categories LIMIT 1').get()) {
    const cats = [['Rice', '🌾'], ['Canned Goods', '🥫'], ['Noodles & Pasta', '🍜'], ['Cooking Essentials', '🧂'], ['Beverages', '☕'], ['Snacks', '🍪'], ['Fresh & Wet Goods', '🐟'], ['Household', '🧼']];
    const ids = {};
    cats.forEach(([n, e], i) => { ids[n] = db.prepare('INSERT INTO categories (name, emoji, sort) VALUES (?,?,?)').run(n, e, i).lastInsertRowid; });
    const P = [
      ['Premium Jasmine Rice', 'Soft, fragrant long-grain rice.', 'Rice', 1450, '25 kg sack', 40, '🌾', 1],
      ['Sinandomeng Rice', 'Everyday white rice, well-milled.', 'Rice', 1250, '25 kg sack', 60, '🌾', 1],
      ['Dinorado Rice', 'Slightly sticky, naturally sweet.', 'Rice', 62, 'per kg', 300, '🍚', 1],
      ['Brown Rice', 'Whole grain, high in fiber.', 'Rice', 75, 'per kg', 120, '🍚', 0],
      ['Corned Beef', 'Classic canned corned beef.', 'Canned Goods', 42, '150 g can', 200, '🥫', 1],
      ['Sardines in Tomato Sauce', '', 'Canned Goods', 24, '155 g can', 350, '🐟', 0],
      ['Instant Pancit Canton', 'Original flavor.', 'Noodles & Pasta', 16, 'pack', 500, '🍜', 0],
      ['Spaghetti Pasta', '', 'Noodles & Pasta', 68, '900 g', 80, '🍝', 0],
      ['Cooking Oil', 'Pure vegetable oil.', 'Cooking Essentials', 95, '1 liter', 150, '🫒', 1],
      ['White Sugar', 'Refined.', 'Cooking Essentials', 88, 'per kg', 200, '🧂', 0],
      ['Soy Sauce', '', 'Cooking Essentials', 32, '385 ml', 140, '🍶', 0],
      ['3-in-1 Coffee', 'Original blend.', 'Beverages', 96, '10 sachets', 180, '☕', 1],
      ['Powdered Milk', '', 'Beverages', 185, '320 g', 70, '🥛', 0],
      ['Crackers', 'Plain salted crackers.', 'Snacks', 58, '10 packs', 90, '🍪', 0],
      ['Fresh Eggs', 'Medium size.', 'Fresh & Wet Goods', 240, 'tray of 30', 50, '🥚', 1],
      ['Dried Fish (Tuyo)', '', 'Fresh & Wet Goods', 180, 'per kg', 25, '🐟', 0],
      ['Laundry Detergent Powder', '', 'Household', 135, '1 kg', 100, '🧼', 0],
      ['Dishwashing Liquid', '', 'Household', 65, '500 ml', 110, '🧴', 0]
    ];
    const ins = db.prepare('INSERT INTO products (name, description, category_id, price, unit, stock, emoji, featured, active, sort, created) VALUES (?,?,?,?,?,?,?,?,1,?,?)');
    P.forEach((p, i) => ins.run(p[0], p[1], ids[p[2]], p[3], p[4], p[5], p[6], p[7], i, now));
  }
  if (!db.prepare('SELECT 1 FROM payment_methods LIMIT 1').get()) {
    const ins = db.prepare('INSERT INTO payment_methods (name, type, account_name, account_number, instructions, enabled, sort) VALUES (?,?,?,?,?,?,?)');
    ins.run('Cash on Delivery / Pickup', 'cod', '', '', 'Pay in cash when you receive your order.', 1, 0);
    ins.run('GCash', 'ewallet', '', '', 'Scan the QR code or send to the number above, then enter your reference number.', 0, 1);
    ins.run('Bank Transfer', 'bank', '', '', 'Transfer to the account above, then enter your reference number.', 0, 2);
  }
  if (!db.prepare('SELECT 1 FROM qr_campaigns LIMIT 1').get()) {
    db.prepare('INSERT INTO qr_campaigns (name, slug, created) VALUES (?,?,?)').run('Store counter', 'store', now);
  }
}
seed();
require('./catalog')(db, tx);
// one-time: the store's trucking rule — free within 1 km, then 20 per km
if (!db.prepare("SELECT 1 FROM settings WHERE key = 'delivery_rule_2026_11'").get()) {
  const s = getSetting('site');
  Object.assign(s.order, { distancePricing: true, deliveryFee: 0, freeDeliveryMin: 0, freeKm: 1, feePerKm: 20 });
  setSetting('site', s);
  db.prepare("INSERT INTO settings (key, value) VALUES ('delivery_rule_2026_11', '1')").run();
}
// one-time: free delivery inside 1 km needs a purchase of 2,000
if (!db.prepare("SELECT 1 FROM settings WHERE key = 'delivery_rule_2026_11b'").get()) {
  const s = getSetting('site');
  s.order.freeKmMin = 2000;
  setSetting('site', s);
  db.prepare("INSERT INTO settings (key, value) VALUES ('delivery_rule_2026_11b', '1')").run();
}

module.exports = { db, tx, getSetting, setSetting, withDefaults, DEFAULTS, DATA_DIR, UPLOAD_DIR, PROOF_DIR };
