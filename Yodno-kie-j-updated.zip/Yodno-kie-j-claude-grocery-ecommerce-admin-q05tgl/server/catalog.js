'use strict';
// One-time import of real rice price list + selected stock products.
// Runs once per database; after that manage products in Admin → Products.
const FLAG = 'catalog_full_2026_11_v3';

const SAMPLES = [
  'Premium Jasmine Rice', 'Sinandomeng Rice', 'Dinorado Rice', 'Brown Rice',
  'Corned Beef', 'Sardines in Tomato Sauce', 'Instant Pancit Canton', 'Spaghetti Pasta',
  'Cooking Oil', 'White Sugar', 'Soy Sauce', '3-in-1 Coffee', 'Powdered Milk',
  'Crackers', 'Fresh Eggs', 'Dried Fish (Tuyo)', 'Laundry Detergent Powder', 'Dishwashing Liquid'
];

// From RICE-PRODUCTS-LIST.xlsx
// [name, retail, unit, kiloPrice, photoKey, featured]
const RICE = [
  ['Kohaku Yellow T', 1390, '25 kg sack', 55.95, 'kohaku-yellow-25kg', 1],
  ['Kohaku Blue', 1280, '25 kg sack', 53.5, '', 0],
  ['Kohaku White', 1290, '25 kg sack', 55, '', 0],
  ['Kohaku Orange', 1380, '25 kg sack', 55.5, '', 0],
  ['Princess Bea (Red)', 1380, '25 kg sack', 55.5, 'princess-bea-25kg', 1],
  ['Jasmine Rice', 1260, '24 kg sack', 55.5, 'jasmine-25kg', 1],
  ['Ellie Rice', 1280, '25 kg sack', 53.5, '', 0],
  ['Chow Pilit', 1150, '25 kg sack', 49.5, '', 0],
  ['K Pilit', 1150, '25 kg sack', 49.5, 'kohaku-malagkit-25kg', 0],
  ['Ordinary Rice', 1220, '24 kg sack', 54.5, 'ordinary', 0],
  ['Snow King Local V-160', 1240, '24 kg sack', 53, '', 0],
  ['Alpha Omega Rice', 1300, '25 kg sack', 54.5, '', 0],
  ['Masipag Rice', 1220, '24 kg sack', 54, 'masipag', 0],
  ['Kohaku Pink Japonica', 1250, '25 kg sack', 53.5, 'kohaku-pink-japonica-25kg', 0],
  ['Japonica Gold', 1250, '25 kg sack', 53.5, 'japonica-gold-25kg', 0],
  ['Idol J Rice', 1240, '24 kg sack', 55, 'idol-j', 0],
  ['Hat Rice', 1240, '24 kg sack', 55, '', 0],
  ['Idol Rice', 1220, '24 kg sack', 54.5, 'idol-25kg', 1],
  ['Humai Rice', 1290, '25 kg sack', 54, '', 0],
  ['Master Chef Hasmin', 1380, '25 kg sack', 55.5, 'master-chef-25kg', 1],
  // Smaller packs
  ['Idol Rice', 1000, '25 kg sack', 0, 'idol-25kg', 0],
  ['Idol Rice', 545, '10 kg', 0, 'idol-10kg', 0],
  ['Idol Rice', 295, '5 kg', 0, 'idol-5kg', 0],
  ['Kohaku Red', 610, '10 kg', 0, 'kohaku-red-10kg', 0],
  ['Kohaku Red', 320, '5 kg', 0, 'kohaku-red-5kg', 0],
  ['Kohaku Yellow', 610, '10 kg', 0, 'kohaku-yellow-10kg', 0],
  ['Kohaku Yellow', 320, '5 kg', 0, '', 0],
  ['Princess Bea', 610, '10 kg', 0, '', 0],
  ['Princess Bea', 320, '5 kg', 0, '', 0],
  ['Jasmine Rice', 565, '10 kg', 0, 'jasmine-10kg', 0],
  ['Jasmine Rice', 305, '5 kg', 0, 'jasmine-5kg', 0]
];

// Selected products from Stocks-2026-11-09.xls (retail prices)
// [name, description, category, price, unit, stock, emoji, featured]
const EXTRA = [
  // ===== Canned Goods =====
  ['Lucky 7 Sardines Tomato Sauce', 'Classic green label sardines.', 'Canned Goods', 19.5, '155 g can', 300, '🐟', 1],
  ['Lucky 7 Sardines Tomato Chili', 'With chili.', 'Canned Goods', 21.5, '155 g can', 250, '🐟', 0],
  ['Ligo Sardines Tomato Sauce', 'Green label.', 'Canned Goods', 25, '155 g can', 280, '🐟', 0],
  ['Ligo Sardines Tomato Chili', 'Red label.', 'Canned Goods', 25.25, '155 g can', 260, '🐟', 0],
  ['555 Tuna Flakes in Oil', 'Budget size.', 'Canned Goods', 33.25, '155 g can', 200, '🐟', 1],
  ['555 Tuna Caldereta', '', 'Canned Goods', 29.85, '155 g can', 180, '🐟', 0],
  ['Century Tuna Flakes in Oil', 'Budget size 125g.', 'Canned Goods', 33.1, '125 g can', 190, '🐟', 0],
  ['Century Tuna Afritada', '', 'Canned Goods', 36.5, '155 g can', 160, '🐟', 0],
  ['Century Tuna Lite Hot & Spicy', '', 'Canned Goods', 49, '180 g can', 120, '🐟', 0],
  ['CDO Karne Norte', 'Easy open.', 'Canned Goods', 36, '175 g can', 150, '🥫', 1],
  ['CDO Karne Norte 150g', '', 'Canned Goods', 31.5, '150 g can', 180, '🥫', 0],
  ['CDO Karne Norte 100g', '', 'Canned Goods', 22.75, '100 g can', 200, '🥫', 0],
  ['Argentina Corned Beef', '', 'Canned Goods', 29, '100 g can', 170, '🥫', 1],
  ['Argentina Beef Loaf', '', 'Canned Goods', 25, '150 g can', 160, '🥫', 0],
  ['Argentina Meat Loaf', '', 'Canned Goods', 22, '150 g can', 150, '🥫', 0],
  ['Argentina Vienna Sausage', '', 'Canned Goods', 54, '260 g can', 100, '🌭', 0],
  ['Argentina Fiesta Sausage', '', 'Canned Goods', 32, '175 g can', 110, '🌭', 0],
  ['Argentina Liver Spread', '', 'Canned Goods', 26.25, '85 g can', 140, '🥪', 1],
  ['CDO Liver Spread', '', 'Canned Goods', 26.25, '85 g can', 130, '🥪', 0],
  ['CDO Beef Loaf 150g', '', 'Canned Goods', 22.75, '150 g can', 150, '🥫', 0],
  ['Bingo Corned Beef 150g', '', 'Canned Goods', 24, '150 g can', 140, '🥫', 0],
  ['Bingo Meat Loaf 150g', '', 'Canned Goods', 22.1, '150 g can', 130, '🥫', 0],
  ['Star Corned Beef Chunky Cheese', '', 'Canned Goods', 36, '150 g can', 120, '🥫', 0],
  ['Bongga Carne Norte', '', 'Canned Goods', 21, '150 g can', 160, '🥫', 0],
  ['San Marino Corned Tuna', '', 'Canned Goods', 41, '150 g can', 100, '🐟', 0],
  ['San Marino Corned Tuna Chili', '', 'Canned Goods', 41, '150 g can', 90, '🐟', 0],

  // ===== Noodles & Pasta =====
  ['Lucky Me! Pancit Canton Original', '', 'Noodles & Pasta', 16.75, 'pack', 400, '🍜', 1],
  ['Lucky Me! Pancit Canton Extra Hot', '', 'Noodles & Pasta', 16.75, 'pack', 350, '🍜', 1],
  ['Lucky Me! Pancit Canton Sweet & Spicy', '', 'Noodles & Pasta', 12.75, 'pack', 380, '🍜', 0],
  ['Lucky Me! Beef na Beef', '', 'Noodles & Pasta', 9, 'pack', 400, '🍜', 0],
  ['Lucky Me! Spicy Labuyo Chicken', '', 'Noodles & Pasta', 10.5, 'pack', 300, '🍜', 0],
  ['Payless Pancit Canton Extra Big Calamansi', '', 'Noodles & Pasta', 18.5, '130 g', 200, '🍜', 0],
  ['Payless Pancit Canton Extra Big Hot Chili', '', 'Noodles & Pasta', 18.5, '130 g', 180, '🍜', 0],
  ['Nissin Cup Noodles Seafood', '', 'Noodles & Pasta', 23, 'cup', 150, '🍜', 1],
  ['Nissin Cup Noodles Beef', '', 'Noodles & Pasta', 23, 'cup', 140, '🍜', 0],
  ['Nissin Cup Noodles Chicken', '', 'Noodles & Pasta', 23, 'cup', 140, '🍜', 0],
  ['Nissin Cup Noodles Creamy Seafood', '', 'Noodles & Pasta', 22.25, 'cup', 130, '🍜', 0],
  ['Vermicelli (Bihon) 80g', '', 'Noodles & Pasta', 14.1, '80 g', 200, '🍜', 0],
  ['Vermicelli Premium 1kg', '', 'Noodles & Pasta', 225.5, '1 kg', 40, '🍜', 0],
  ['Macaroni Half Kilo', '', 'Noodles & Pasta', 50, '500 g', 80, '🍝', 0],

  // ===== Cooking Essentials / Condiments =====
  ['Minola Cooking Oil 485ml', '', 'Cooking Essentials', 121.5, '485 ml', 100, '🫒', 1],
  ['Minola Cooking Oil 925ml', '', 'Cooking Essentials', 238.5, '925 ml', 60, '🫒', 0],
  ['Silver Swan Soy Sauce 100ml', '', 'Cooking Essentials', 8.25, '100 ml', 300, '🍶', 1],
  ['Silver Swan Soy Sauce 200ml', '', 'Cooking Essentials', 12.1, '200 ml', 250, '🍶', 0],
  ['Silver Swan Soy Sauce 1/2 Gal', '', 'Cooking Essentials', 117.1, '1.89 L', 40, '🍶', 0],
  ['Silver Swan Patis 100ml', '', 'Cooking Essentials', 9.75, '100 ml', 200, '🐟', 1],
  ['Datu Puti Vinegar 200ml', '', 'Cooking Essentials', 8.75, '200 ml', 250, '🍶', 0],
  ['UFC Tomato Sauce 200g', '', 'Cooking Essentials', 21.95, '200 g', 180, '🍅', 1],
  ['Knorr Liquid Seasoning Chili', 'Sachet.', 'Cooking Essentials', 6.25, '12 ml', 400, '🌶️', 0],
  ['Knorr Singles Pork', 'Sachet pack.', 'Cooking Essentials', 78, 'pack', 80, '🧂', 0],
  ['Magnolia Real Mayonnaise 220ml', '', 'Cooking Essentials', 84.25, '220 ml', 90, '🥪', 1],
  ['Gloris Savers Mayo 250g', '', 'Cooking Essentials', 21, '250 g', 120, '🥪', 0],
  ['Gloris Savers Mayo 1kg', '', 'Cooking Essentials', 95, '1 kg', 50, '🥪', 0],
  ['Angel Kremdensada 410ml', '', 'Cooking Essentials', 62.95, '410 ml', 80, '🥛', 0],
  ['Aji Ginisa Mix', 'Sachet.', 'Cooking Essentials', 8.75, '20 g', 300, '🧂', 0],
  ['Ms Oyster Sauce Sachet', '', 'Cooking Essentials', 22.75, '90 g', 150, '🦪', 0],

  // ===== Beverages / Coffee =====
  ['Great Taste Granules Stick', '', 'Beverages', 3.1, 'sachet', 500, '☕', 1],
  ['Great Taste Coffee Concentrate 50g', '', 'Beverages', 51.75, '50 g', 100, '☕', 0],
  ['Great Taste Coffee Concentrate 100g', '', 'Beverages', 102.1, '100 g', 70, '☕', 0],
  ['San Mig Coffee 3-in-1 Original Tipid Pack', '', 'Beverages', 75, 'pack', 120, '☕', 1],
  ['San Mig Coffee 3-in-1 Strong', '', 'Beverages', 87, 'pack', 100, '☕', 0],
  ['Kapitan Supreme Black 3-in-1', '', 'Beverages', 4.5, 'sachet', 400, '☕', 0],
  ['Kapitan Smooth Brown Coffee', '', 'Beverages', 4.5, 'sachet', 350, '☕', 0],
  ['Nestle Coffee-Mate 150g', '', 'Beverages', 49.1, '150 g', 90, '🥛', 0],
  ['Milo RTD 180ml', '', 'Beverages', 95.5, 'pack of 4', 60, '🍫', 1],
  ['Jersey Full Cream Fresh Milk 1L', '', 'Beverages', 79.75, '1 liter', 50, '🥛', 1],
  ['Jersey Chocolate Milk 200ml', '', 'Beverages', 21, '200 ml', 120, '🥛', 0],
  ['Magnolia Fresh Milk Pure 1L', '', 'Beverages', 104, '1 liter', 40, '🥛', 0],
  ['Magnolia Fresh Milk Low Fat 1L', '', 'Beverages', 109, '1 liter', 35, '🥛', 0],
  ['Natures Spring Distilled Water 1L', '', 'Beverages', 18, '1 liter', 200, '💧', 1],
  ['Natures Spring Distilled Water 1.5L', '', 'Beverages', 22.75, '1.5 liter', 180, '💧', 0],
  ['Denver Purified Water 330ml', '', 'Beverages', 7, '330 ml', 300, '💧', 0],
  ['Denver Purified Water 500ml', '', 'Beverages', 9, '500 ml', 280, '💧', 0],
  ['Quench Orange Juice 350ml', '', 'Beverages', 25, '350 ml', 150, '🧃', 0],
  ['Quench Apple Juice 350ml', '', 'Beverages', 25, '350 ml', 140, '🧃', 0],
  ['Koolers Apple Juice 220ml', '', 'Beverages', 10, '220 ml', 200, '🧃', 0],
  ['Lipovitan XL 150ml', '', 'Beverages', 33.75, '150 ml', 100, '🥤', 0],

  // ===== Snacks =====
  ['Piattos Cheese 40g', '', 'Snacks', 16.5, '40 g', 200, '🥔', 1],
  ['Piattos Nacho Pizza 40g', '', 'Snacks', 16.5, '40 g', 180, '🥔', 0],
  ['Piattos Roadhouse BBQ 40g', '', 'Snacks', 16.5, '40 g', 170, '🥔', 0],
  ['Nova Country Cheddar 40g', '', 'Snacks', 16.5, '40 g', 160, '🌽', 1],
  ['Chippy BBQ 27g', '', 'Snacks', 7.75, '27 g', 300, '🌽', 1],
  ['Chippy Garlic Vinegar 27g', '', 'Snacks', 7.75, '27 g', 280, '🌽', 0],
  ['Magic Chips BBQ 28g', '', 'Snacks', 7.5, '28 g', 250, '🥔', 0],
  ['Magic Chips Cheese 28g', '', 'Snacks', 7.5, '28 g', 240, '🥔', 0],
  ['Chiz Curls 18g', '', 'Snacks', 7.75, '18 g', 260, '🧀', 0],
  ['Mr. Chips Nacho Cheese 26g', '', 'Snacks', 6.75, '26 g', 220, '🧀', 0],
  ['Oreo Original Vanilla', '', 'Snacks', 72.25, 'pack', 80, '🍪', 1],
  ['Oreo Chocolate', '', 'Snacks', 72.25, 'pack', 70, '🍪', 0],
  ['Cream-O Vanilla', '', 'Snacks', 72, 'pack', 90, '🍪', 0],
  ['Presto Creams Vanilla 30g', '', 'Snacks', 62.5, 'pack', 100, '🍪', 0],
  ['Rebisco Graham 200g', '', 'Snacks', 37.5, '200 g', 80, '🍪', 0],
  ['Happy Peanuts Chicken Adobo', '', 'Snacks', 6.25, '25 g', 300, '🥜', 0],
  ['Tattoos Corn Chips', '', 'Snacks', 11.25, 'pack', 150, '🌽', 0],
  ['Bread Stix 20g', '', 'Snacks', 6.25, '20 g', 250, '🥖', 0],
  ['Choco Mucho Minis', '', 'Snacks', 48.25, 'pack', 100, '🍫', 0],
  ['Snickers Classic Singles 51g', '', 'Snacks', 46.5, '51 g', 80, '🍫', 0],

  // ===== Household / Cleaning =====
  ['Axion Lemon Paste 350g Twin Pack', '', 'Household', 97.5, 'twin pack', 60, '🧴', 1],
  ['Zonrox Original 500ml', '', 'Household', 28.75, '500 ml', 100, '🧴', 1],
  ['Zonrox Original 1L', '', 'Household', 49.25, '1 liter', 80, '🧴', 0],
  ['Zonrox Lemon 500ml', '', 'Household', 30.75, '500 ml', 90, '🧴', 0],
  ['Zonrox Floral 500ml', '', 'Household', 30.75, '500 ml', 85, '🧴', 0],
  ['Surf Powder Rose Fresh Sachet Pack', '', 'Household', 43.5, 'pack', 100, '🧼', 0],
  ['Breeze Liquid Stain Action', '', 'Household', 87, 'pack', 70, '🧴', 0],
  ['Downy Sunrise Fresh Sachet Pack', '', 'Household', 41.75, 'pack', 90, '🧺', 0],
  ['Calla Powder Summer Fresh 100g', '', 'Household', 14.25, '100 g', 120, '🧼', 0],
  ['Champion Powder Easy Stain Removal', '', 'Household', 15.5, '105 g', 110, '🧼', 0],
  ['Uni Yen Yen Dishwashing Liquid 900ml', '', 'Household', 60.65, '900 ml', 60, '🧴', 1],
  ['Cleen Dish Sponge Large', '', 'Household', 33.75, 'piece', 80, '🧽', 0],
  ['ARS Mosquito Coil', '', 'Household', 20.25, 'pack', 150, '🦟', 0],

  // ===== Hygiene =====
  ['Colgate Toothbrush Classic', '', 'Household', 18.5, 'piece', 150, '🪥', 0],
  ['Colgate Peppermint Ice Blue 145ml', '', 'Household', 143.5, '145 ml', 50, '🪥', 0],
  ['Close Up Red Hot Twin Pack', '', 'Household', 158, 'twin pack', 40, '🪥', 0],
  ['Palmolive Shampoo Silky Straight 180ml', '', 'Household', 138.75, '180 ml', 40, '🧴', 0],
  ['Palmolive Shampoo Green 180ml', '', 'Household', 138.75, '180 ml', 40, '🧴', 0],
  ['Palmolive Shampoo Sachet Triple', '', 'Household', 6.5, 'sachet pack', 300, '🧴', 1],
  ['Creamsilk Treatment Sachet', '', 'Household', 6.85, 'sachet', 280, '🧴', 0],
  ['Sunsilk Shampoo Sachet', '', 'Household', 6.5, 'sachet', 300, '🧴', 0],
  ['Bio Soap Germicidal 60g', '', 'Household', 17.25, 'bar', 200, '🧼', 1],
  ['Silka Papaya Soap 90g', '', 'Household', 35.7, 'bar', 100, '🧼', 0],
  ['Safeguard Soap Pure Care 55g', '', 'Household', 17, 'bar', 180, '🧼', 0],

  // ===== Dairy / Spreads =====
  ['Magnolia Cheezee 470g', '', 'Fresh & Wet Goods', 135, '470 g', 40, '🧀', 1],
  ['Magnolia Daily Quezo 165g', '', 'Fresh & Wet Goods', 36.1, '165 g', 80, '🧀', 0],
  ['Danes Cheese Block Classic 35g', '', 'Fresh & Wet Goods', 13.5, '35 g', 120, '🧀', 0],
  ['Magnolia All Purpose Cream 250ml', '', 'Fresh & Wet Goods', 69.1, '250 ml', 60, '🥛', 0],
  ['Magnolia Creamy Chicken Spread', '', 'Fresh & Wet Goods', 90.5, '220 ml', 40, '🥪', 0],
  ['Eden Sandwich Spread 80ml', '', 'Fresh & Wet Goods', 39.5, '80 ml', 70, '🥪', 0],

  // ===== Others useful =====
  ['Quaker Instant Oatmeal 400g', '', 'Cooking Essentials', 75.95, '400 g', 50, '🥣', 0],
  ['Quaker Instant Oatmeal 200g', '', 'Cooking Essentials', 43.25, '200 g', 70, '🥣', 0],
  ['Captain Oats Instant Oatmeal 400g', '', 'Cooking Essentials', 88.75, '400 g', 40, '🥣', 0],
  ['Star Vigil Candle with Glass', '', 'Household', 51.25, 'piece', 60, '🕯️', 0],
  ['Joy White Chalk Box', '', 'Household', 115, 'box', 30, '🖍️', 0]
];

module.exports = function importCatalog(db, tx) {
  if (db.prepare('SELECT 1 FROM settings WHERE key = ?').get(FLAG)) return;
  tx(() => {
    const now = new Date().toISOString();

    // Clean old sample products without images
    const del = db.prepare('DELETE FROM products WHERE name = ? AND image IS NULL');
    SAMPLES.forEach((n) => del.run(n));

    const ensureCat = (name, emoji, sort) => {
      let row = db.prepare('SELECT id FROM categories WHERE name = ?').get(name);
      if (!row) {
        row = { id: db.prepare('INSERT INTO categories (name, emoji, sort) VALUES (?,?,?)').run(name, emoji, sort).lastInsertRowid };
      }
      return row.id;
    };

    const catIds = {
      'Rice': ensureCat('Rice', '🌾', 0),
      'Canned Goods': ensureCat('Canned Goods', '🥫', 1),
      'Noodles & Pasta': ensureCat('Noodles & Pasta', '🍜', 2),
      'Cooking Essentials': ensureCat('Cooking Essentials', '🧂', 3),
      'Beverages': ensureCat('Beverages', '☕', 4),
      'Snacks': ensureCat('Snacks', '🍪', 5),
      'Fresh & Wet Goods': ensureCat('Fresh & Wet Goods', '🐟', 6),
      'Household': ensureCat('Household', '🧼', 7)
    };

    const has = db.prepare('SELECT 1 FROM products WHERE name = ? AND unit = ?');
    const ins = db.prepare(
      'INSERT INTO products (name, description, category_id, price, unit, stock, image, emoji, featured, active, sort, created) VALUES (?,?,?,?,?,?,?,?,?,1,?,?)'
    );

    // Rice (with real photos where available)
    RICE.forEach(([name, price, unit, kilo, photo, feat], i) => {
      if (has.get(name, unit)) return;
      const desc = kilo ? 'Also sold per kilo at ₱' + Number(kilo).toFixed(2) + '.' : '';
      const image = photo ? '/assets/rice-' + photo + '.jpg' : null;
      ins.run(name, desc, catIds['Rice'], price, unit, null, image, '🌾', feat, i, now);
    });

    // Extra stock products (emoji placeholders — upload photos later in Admin)
    EXTRA.forEach(([name, desc, category, price, unit, stock, emoji, feat], i) => {
      if (has.get(name, unit)) return;
      ins.run(name, desc || '', catIds[category], price, unit, stock, null, emoji, feat, 100 + i, now);
    });

    db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)').run(FLAG, JSON.stringify({ done: now }));
  });
};
