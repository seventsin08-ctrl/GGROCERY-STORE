'use strict';
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { promisify } = require('util');
const { db, DATA_DIR } = require('./db');

const scrypt = promisify(crypto.scrypt);
const SCRYPT = { N: 32768, r: 8, p: 1, maxmem: 128 * 1024 * 1024 };
const SESSION_HOURS = 12;          // absolute lifetime
const IDLE_MINUTES = 120;          // idle timeout
const COOKIE = 'ckj_sid';
const PW_FILE = path.join(DATA_DIR, 'INITIAL_ADMIN_PASSWORD.txt');

const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const nowIso = () => new Date().toISOString();

/* ---------- passwords ---------- */
async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const hash = await scrypt(pw.normalize('NFKC'), salt, 64, SCRYPT);
  return `scrypt$${SCRYPT.N}$${salt.toString('hex')}$${hash.toString('hex')}`;
}
async function verifyPassword(pw, stored) {
  try {
    const [algo, n, saltHex, hashHex] = String(stored).split('$');
    if (algo !== 'scrypt') return false;
    const expected = Buffer.from(hashHex, 'hex');
    const got = await scrypt(String(pw).normalize('NFKC'), Buffer.from(saltHex, 'hex'), expected.length, { ...SCRYPT, N: Number(n) });
    return crypto.timingSafeEqual(got, expected);
  } catch { return false; }
}
const COMMON = ['password', '12345678', 'qwerty', 'admin', 'letmein', 'iloveyou', 'welcome', 'ckj', 'grocery'];
function passwordProblem(pw) {
  if (typeof pw !== 'string' || pw.length < 10) return 'Password must be at least 10 characters.';
  if (pw.length > 200) return 'Password is too long.';
  if (!/[a-z]/i.test(pw) || !/\d/.test(pw)) return 'Password must contain letters and numbers.';
  if (!/[A-Z]/.test(pw) && !/[^A-Za-z0-9]/.test(pw)) return 'Add an uppercase letter or a symbol.';
  const low = pw.toLowerCase();
  if (COMMON.some((c) => low === c || (low.startsWith(c) && low.length < c.length + 5))) return 'That password is too easy to guess.';
  if (/^(.)\1+$/.test(pw)) return 'That password is too easy to guess.';
  return null;
}

/* ---------- TOTP (RFC 6238) ---------- */
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function b32encode(buf) {
  let bits = 0, val = 0, out = '';
  for (const b of buf) { val = (val << 8) | b; bits += 8; while (bits >= 5) { out += B32[(val >>> (bits - 5)) & 31]; bits -= 5; } }
  if (bits > 0) out += B32[(val << (5 - bits)) & 31];
  return out;
}
function b32decode(str) {
  let bits = 0, val = 0; const out = [];
  for (const c of String(str).toUpperCase().replace(/[^A-Z2-7]/g, '')) {
    val = (val << 5) | B32.indexOf(c); bits += 5;
    if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; }
  }
  return Buffer.from(out);
}
function hotp(secret, counter) {
  const buf = Buffer.alloc(8);
  buf.writeBigUInt64BE(BigInt(counter));
  const h = crypto.createHmac('sha1', b32decode(secret)).update(buf).digest();
  const o = h[h.length - 1] & 15;
  const code = ((h[o] & 127) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3];
  return String(code % 1e6).padStart(6, '0');
}
// returns matched counter (number) or 0
function verifyTotp(secret, code, lastUsed = 0) {
  code = String(code || '').replace(/\D/g, '');
  if (code.length !== 6 || !secret) return 0;
  const c = Math.floor(Date.now() / 30000);
  for (const w of [0, -1, 1]) {
    const ctr = c + w;
    if (ctr <= lastUsed) continue; // no replay
    if (crypto.timingSafeEqual(Buffer.from(hotp(secret, ctr)), Buffer.from(code))) return ctr;
  }
  return 0;
}
const newTotpSecret = () => b32encode(crypto.randomBytes(20));

/* ---------- admin bootstrap ---------- */
async function ensureAdmin() {
  if (db.prepare('SELECT 1 FROM admin WHERE id = 1').get()) return;
  const envPw = process.env.ADMIN_PASSWORD;
  const username = String(process.env.ADMIN_USERNAME || 'Admin').trim().slice(0, 40) || 'Admin';
  const pw = envPw && envPw.length >= 8 ? envPw : 'Admin123';
  const isDefault = pw === 'Admin123' ? 1 : 0;
  db.prepare('INSERT INTO admin (id, username, pass_hash, must_change, is_default, updated) VALUES (1, ?, ?, 0, ?, ?)').run(username, await hashPassword(pw), isDefault, nowIso());
  console.log(`Admin account created (username: ${username}). Sign in at /admin` + (isDefault ? ' with the default password and change it in Security before going live.' : '.'));
}
function clearInitialPasswordFile() { try { fs.unlinkSync(PW_FILE); } catch { /* ignore */ } }

/* ---------- sessions ---------- */
function parseCookies(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function setCookie(req, res, token, maxAge) {
  const secure = req.secure || req.headers['x-forwarded-proto'] === 'https';
  res.append('Set-Cookie', `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${secure ? '; Secure' : ''}`);
}
function createSession(req, res) {
  const token = crypto.randomBytes(32).toString('base64url');
  const csrf = crypto.randomBytes(24).toString('base64url');
  const now = Date.now();
  db.prepare('INSERT INTO sessions (id, csrf, created, last_seen, expires, ip, ua) VALUES (?,?,?,?,?,?,?)')
    .run(sha256(token), csrf, new Date(now).toISOString(), new Date(now).toISOString(), new Date(now + SESSION_HOURS * 3600e3).toISOString(), req.ip || '', String(req.headers['user-agent'] || '').slice(0, 200));
  setCookie(req, res, token, SESSION_HOURS * 3600);
  return csrf;
}
function getSession(req) {
  const token = parseCookies(req)[COOKIE];
  if (!token) return null;
  const id = sha256(token);
  const s = db.prepare('SELECT * FROM sessions WHERE id = ?').get(id);
  if (!s) return null;
  const now = Date.now();
  if (new Date(s.expires).getTime() < now || new Date(s.last_seen).getTime() + IDLE_MINUTES * 60e3 < now) {
    db.prepare('DELETE FROM sessions WHERE id = ?').run(id);
    return null;
  }
  if (now - new Date(s.last_seen).getTime() > 30e3) db.prepare('UPDATE sessions SET last_seen = ? WHERE id = ?').run(new Date(now).toISOString(), id);
  return s;
}
function destroySession(req, res) {
  const token = parseCookies(req)[COOKIE];
  if (token) db.prepare('DELETE FROM sessions WHERE id = ?').run(sha256(token));
  setCookie(req, res, '', 0);
}
function safeEqual(a, b) {
  const x = Buffer.from(String(a || '')), y = Buffer.from(String(b || ''));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}
// Express middleware: valid session + CSRF token on every state-changing request
function requireAdmin(req, res, next) {
  const s = getSession(req);
  if (!s) return res.status(401).json({ error: 'Please sign in.' });
  if (!['GET', 'HEAD'].includes(req.method) && !safeEqual(req.headers['x-csrf-token'], s.csrf)) return res.status(403).json({ error: 'Security check failed. Refresh the page and try again.' });
  req.session = s;
  const admin = db.prepare('SELECT must_change FROM admin WHERE id = 1').get();
  const open = ['/me', '/password', '/logout'];
  if (admin.must_change && !open.includes(req.path)) return res.status(403).json({ error: 'Change your password first.', mustChange: true });
  next();
}
setInterval(() => { try { db.prepare('DELETE FROM sessions WHERE expires < ?').run(nowIso()); } catch { /* ignore */ } }, 15 * 60e3).unref();

/* ---------- brute-force protection ---------- */
const fails = new Map(); // ip -> { count, until, last }
function loginLock(ip) {
  const f = fails.get(ip);
  if (f && f.until > Date.now()) return Math.ceil((f.until - Date.now()) / 1000);
  return 0;
}
function loginFailed(ip) {
  const now = Date.now();
  let f = fails.get(ip);
  if (!f || now - f.last > 60 * 60e3) f = { count: 0, until: 0, last: now };
  f.count++; f.last = now;
  // 5 tries, then 15 min; doubles on every further failure, capped at 24h
  if (f.count >= 5) f.until = now + Math.min(24 * 3600e3, 15 * 60e3 * 2 ** (f.count - 5));
  fails.set(ip, f);
  return f;
}
const loginSucceeded = (ip) => fails.delete(ip);
function logLogin(ip, ok, note) {
  db.prepare('INSERT INTO login_log (ts, ip, ok, note) VALUES (?,?,?,?)').run(nowIso(), ip || '', ok ? 1 : 0, note || '');
  db.prepare('DELETE FROM login_log WHERE id NOT IN (SELECT id FROM login_log ORDER BY id DESC LIMIT 500)').run();
}

// generic fixed-window rate limiter
function rateLimit(max, windowMs, message) {
  const hits = new Map();
  setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (v.reset < now) hits.delete(k); }, windowMs).unref();
  return (req, res, next) => {
    const now = Date.now(), k = req.ip || 'x';
    let h = hits.get(k);
    if (!h || h.reset < now) { h = { n: 0, reset: now + windowMs }; hits.set(k, h); }
    if (++h.n > max) { res.set('Retry-After', String(Math.ceil((h.reset - now) / 1000))); return res.status(429).json({ error: message || 'Too many requests. Please wait a moment and try again.' }); }
    next();
  };
}

function securityHeaders(req, res, next) {
  res.set({
    'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: blob: https://tile.openstreetmap.org; connect-src 'self'; frame-src 'self' https://www.google.com; frame-ancestors 'self'; base-uri 'self'; form-action 'self'; object-src 'none'",
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'SAMEORIGIN',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=(self), payment=()',
    'Cross-Origin-Opener-Policy': 'same-origin'
  });
  if (req.secure || req.headers['x-forwarded-proto'] === 'https') res.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
}

module.exports = {
  hashPassword, verifyPassword, passwordProblem, verifyTotp, newTotpSecret, ensureAdmin, clearInitialPasswordFile,
  createSession, getSession, destroySession, requireAdmin, loginLock, loginFailed, loginSucceeded, logLogin, rateLimit, securityHeaders, sha256, COOKIE
};
