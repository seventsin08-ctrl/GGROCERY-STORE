'use strict';
// Emergency reset: sets a new temporary admin password, turns off 2FA and signs out all devices.
// Usage: npm run reset-admin
const crypto = require('crypto');
const { db } = require('../server/db');
const sec = require('../server/security');

(async () => {
  const pw = crypto.randomBytes(12).toString('base64url');
  const hash = await sec.hashPassword(pw);
  db.prepare('DELETE FROM admin').run();
  db.prepare('INSERT INTO admin (id, username, pass_hash, must_change, updated) VALUES (1, ?, ?, 1, ?)').run('Admin', hash, new Date().toISOString());
  db.prepare('DELETE FROM sessions').run();
  console.log('\nAdmin password has been reset.\nUsername: Admin\nTemporary password: ' + pw + '\nYou will be asked to choose a new one when you sign in at /admin\n');
  process.exit(0);
})();
